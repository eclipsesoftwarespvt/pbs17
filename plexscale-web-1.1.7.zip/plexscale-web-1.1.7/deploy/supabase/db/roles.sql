-- Runs once, when the database volume is first created (docker-entrypoint-initdb.d).
-- Each service gets its own password; roles PlexScale does not use cannot log in.
\set authenticator_pass `echo "$AUTHENTICATOR_PASSWORD"`
\set auth_admin_pass `echo "$AUTH_ADMIN_PASSWORD"`
\set pgpass `echo "$POSTGRES_PASSWORD"`

ALTER USER authenticator WITH PASSWORD :'authenticator_pass';
ALTER USER supabase_auth_admin WITH PASSWORD :'auth_admin_pass';
ALTER USER postgres WITH PASSWORD :'pgpass';

-- Not used by PlexScale (no pooler, edge functions or storage service in this stack).
-- Some database images do not create every one of these roles, and a missing role must not stop the
-- init script (it left the db container "unhealthy"), so each role is switched off only if it exists.
DO $$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['pgbouncer', 'supabase_functions_admin', 'supabase_storage_admin'] LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('ALTER ROLE %I NOLOGIN', r);
    END IF;
  END LOOP;
END
$$;
