-- 0009: revoking admin also removes the email grant, so the role is not re-granted on next sign-in.
-- Add-only: earlier migrations are never edited. Safe to re-run.

CREATE OR REPLACE FUNCTION public.revoke_admin_access(_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _email text;
BEGIN
  SELECT lower(email) INTO _email FROM auth.users WHERE id = _user_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'admin_user_unknown';
  END IF;
  IF _email IS NOT NULL THEN
    DELETE FROM public.admin_email_grants WHERE email = _email;
  END IF;
  DELETE FROM public.user_roles WHERE user_id = _user_id AND role = 'admin';
END;
$$;
REVOKE ALL ON FUNCTION public.revoke_admin_access(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.revoke_admin_access(uuid) TO service_role;
