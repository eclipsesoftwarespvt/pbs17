// Server-only: turns a failed panel call into an admin alert plus the one line a customer may see.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { Database } from "@/integrations/supabase/types";
import { PanelError, scrubPanelText, type PanelAction } from "./pterodactyl.server";

/** The only text a customer ever sees about a panel failure. */
function friendlyLine(code: number) {
  return `Error occurred. ${code}. Contact support.`;
}

interface AlertContext {
  action: PanelAction;
  orderId?: string | null;
  userId?: string | null;
  product?: string | null;
}

/** Normalises any thrown value into the fields an alert stores. */
function alertFields(e: unknown) {
  if (e instanceof PanelError) {
    return { code: e.code, action: e.action, httpStatus: e.httpStatus, panelCode: e.panelCode, detail: e.detail, raw: e.raw };
  }
  const detail = e instanceof Error ? e.message : String(e);
  return { code: 500, action: undefined, httpStatus: null, panelCode: null, detail: scrubPanelText(detail).slice(0, 1000), raw: null };
}

/**
 * Records (or bumps) the admin alert for this failure and returns the friendly customer line.
 * Repeat failures for the same order and action bump one open alert. Never throws.
 */
export async function reportPanelFailure(e: unknown, ctx: AlertContext): Promise<string> {
  const f = alertFields(e);
  const action = f.action ?? ctx.action;
  let email: string | null = null;
  if (ctx.userId) {
    const { data } = await supabaseAdmin.from("profiles").select("email").eq("id", ctx.userId).maybeSingle();
    email = data?.email ?? null;
  }
  // Nullable arguments: the generated types mark every SQL argument as required.
  const args = {
    _action: action, _order_id: ctx.orderId ?? null, _user_id: ctx.userId ?? null, _user_email: email,
    _product: ctx.product ?? null, _http_status: f.httpStatus, _panel_code: f.panelCode, _panel_detail: f.detail, _raw: f.raw,
  } as unknown as Database["public"]["Functions"]["record_panel_alert_v2"]["Args"];
  try {
    const { data, error } = await supabaseAdmin.rpc("record_panel_alert_v2", args);
    if (error) throw error;
    console.error(JSON.stringify({ level: "error", event: "panel.failure", action, orderId: ctx.orderId ?? null, alertId: data, code: f.code, httpStatus: f.httpStatus, panelCode: f.panelCode }));
  } catch (err) {
    const dbCode = err && typeof err === "object" && "code" in err ? String((err as { code: unknown }).code) : null;
    console.error(JSON.stringify({ level: "error", event: "panel.alert.write_failed", action, orderId: ctx.orderId ?? null, dbCode }));
  }
  return friendlyLine(f.code);
}

/** Closes open alerts for an order once the action finally succeeds. */
export async function resolvePanelAlerts(orderId: string, actions: PanelAction[]) {
  await supabaseAdmin.from("panel_alerts").update({ status: "resolved", resolved_at: new Date().toISOString() })
    .eq("order_id", orderId).eq("status", "open").in("action", actions);
}
