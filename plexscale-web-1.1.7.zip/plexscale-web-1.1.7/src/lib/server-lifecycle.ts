// Pure orchestration for deleting servers, so the claim / revert rules can be tested without a database.

export interface DeleteCandidate {
  id: string;
  user_id: string;
  product: string;
  ptero_server_id: number | null;
  /** Plexus VPS machine, for VPS orders. */
  plexus_machine_id?: string | null;
}

interface DeletePassDeps {
  listDue: () => Promise<DeleteCandidate[]>;
  /** Conditional update; true only when this run won the order (e.g. suspended → cancelled). */
  claim: (c: DeleteCandidate) => Promise<boolean>;
  /** Undoes the claim after a failed delete, so tomorrow's run retries. */
  revert: (c: DeleteCandidate) => Promise<void>;
  deleteServer: (serverId: number) => Promise<void>;
  /** Queues deletion of a Plexus VPS machine. */
  deleteMachine?: (machineId: string) => Promise<void>;
  alert: (c: DeleteCandidate, e: unknown) => Promise<void>;
  /** Clears the server ids and writes the audit entry. */
  finish: (c: DeleteCandidate) => Promise<void>;
}

export async function runDeletePass(deps: DeletePassDeps) {
  let deleted = 0;
  let failed = 0;
  let skipped = 0;
  for (const c of await deps.listDue()) {
    if (!(await deps.claim(c))) { skipped++; continue; }
    if (c.ptero_server_id || (c.plexus_machine_id && deps.deleteMachine)) {
      try {
        if (c.ptero_server_id) await deps.deleteServer(c.ptero_server_id);
        if (c.plexus_machine_id && deps.deleteMachine) await deps.deleteMachine(c.plexus_machine_id);
      } catch (e) {
        await deps.revert(c);
        await deps.alert(c, e);
        failed++;
        continue;
      }
    }
    await deps.finish(c);
    deleted++;
  }
  return { deleted, failed, skipped };
}
