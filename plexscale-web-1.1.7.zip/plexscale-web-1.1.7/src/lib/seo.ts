// Search and AI-crawler metadata: per-page head tags, JSON-LD, sitemap.xml, robots.txt and llms.txt.
// Kept free of framework imports.
//
// Absolute URLs are built only from SITE_URL (never from the Host header). Vite inlines SITE_URL at build
// time (envPrefix in vite.config.ts); the text routes prefer the runtime value from the server environment.
import { site } from "@/config/site";

/** The site origin from SITE_URL: https, or http only on a loopback host. Anything else yields null. */
function normalizeSiteUrl(raw: string | undefined | null): string | null {
  if (!raw) return null;
  let u: URL;
  try { u = new URL(raw.trim()); } catch { return null; }
  const loopback = u.hostname === "127.0.0.1" || u.hostname === "localhost";
  if (u.username || u.password) return null;
  if (u.protocol !== "https:" && !(u.protocol === "http:" && loopback)) return null;
  return u.origin;
}

/** Build-time site origin, falling back to the brand domain when SITE_URL is missing or invalid. */
const SITE_URL: string = normalizeSiteUrl(import.meta.env["SITE_URL"] as string | undefined) ?? site.url;

/** Server-side origin for sitemap.xml, robots.txt and llms.txt: runtime SITE_URL first. */
function runtimeSiteUrl(): string {
  const env = typeof process !== "undefined" ? process.env["SITE_URL"] : undefined;
  return normalizeSiteUrl(env) ?? SITE_URL;
}

export const absoluteUrl = (path: string, origin: string = SITE_URL) => `${origin}${path.startsWith("/") ? path : `/${path}`}`;

// ---------------------------------------------------------------------------------------------------------
// Public pages. The sitemap and llms.txt list exactly these. `lastmod` is the date the page content last
// changed in a meaningful way: update it by hand together with the page, never from the build or request time.

interface PublicPage { path: string; name: string; summary: string; lastmod: string; group: "Pages" | "Hosting" | "Legal" }

const PAGES_UPDATED = "2026-11-18";
const LEGAL_UPDATED = "2026-10-29"; // "Last updated" date printed on the legal pages

const publicPages: PublicPage[] = [
  { path: "/", name: "Home", summary: "Game servers, VPS and Discord bot hosting on AMD EPYC 9V74, 7763 and 7V12 with DDR5 or DDR4 memory and NVMe Gen 4 storage.", lastmod: PAGES_UPDATED, group: "Pages" },
  { path: "/minecraft", name: "Minecraft server hosting", summary: "PaperMC, Fabric, Forge, SpigotMC, NeoForge and Vanilla servers on AMD EPYC.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/hytale", name: "Hytale server hosting", summary: "Hytale dedicated servers with mods and plugins.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/counter-strike-2", name: "Counter Strike 2 server hosting", summary: "CS2 servers for competitive, retakes, deathmatch and workshop maps.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/rust", name: "Rust server hosting", summary: "Rust dedicated servers with Oxide or Carbon plugins and procedural maps.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/palworld", name: "Palworld server hosting", summary: "Palworld dedicated servers with custom world settings and save transfers.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/ark-survival", name: "ARK: Survival server hosting", summary: "ARK: Survival Ascended and Evolved servers with official maps and mods.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/garrys-mod", name: "Garry's Mod server hosting", summary: "Garry's Mod servers for Sandbox, TTT and Workshop collections.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/vps", name: "VPS hosting", summary: "KVM VPS with full root access, NVMe Gen 4 storage and DDoS protection.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/bot-hosting", name: "Discord bot hosting", summary: "Always-online Node.js and Python Discord bot hosting.", lastmod: PAGES_UPDATED, group: "Hosting" },
  { path: "/about", name: "About PlexScale", summary: "Who runs PlexScale, our values and our hardware.", lastmod: PAGES_UPDATED, group: "Pages" },
  { path: "/queries", name: "Queries (FAQ)", summary: "Answers about setup, hardware, billing, renewals, refunds and support.", lastmod: PAGES_UPDATED, group: "Pages" },
  { path: "/contact", name: "Contact", summary: "Support tickets, Discord and email.", lastmod: PAGES_UPDATED, group: "Pages" },
  { path: "/legal/tos", name: "Terms of Service", summary: "Rules for using PlexScale services.", lastmod: LEGAL_UPDATED, group: "Legal" },
  { path: "/legal/privacy", name: "Privacy Policy", summary: "What data PlexScale collects and why.", lastmod: LEGAL_UPDATED, group: "Legal" },
  { path: "/legal/refund", name: "Refund Policy", summary: "Which services can be refunded and how.", lastmod: LEGAL_UPDATED, group: "Legal" },
  { path: "/legal/acceptable-use", name: "Acceptable Use Policy", summary: "What may and may not run on PlexScale services.", lastmod: LEGAL_UPDATED, group: "Legal" },
  { path: "/legal/sla", name: "Service Level Agreement", summary: "Uptime commitment and service credits.", lastmod: LEGAL_UPDATED, group: "Legal" },
];

/** Paths that are never indexed: they get noindex headers and are disallowed in robots.txt. */
const privatePathPrefixes = ["/administrator", "/auth", "/account", "/billing", "/deploy", "/support", "/api/", "/_px/"] as const;

export function isPrivatePath(pathname: string): boolean {
  return privatePathPrefixes.some((p) => p.endsWith("/") ? pathname.startsWith(p) || pathname === p.slice(0, -1) : pathname === p || pathname.startsWith(`${p}/`));
}

// ---------------------------------------------------------------------------------------------------------
// Head tags

type Json = Record<string, unknown>;
type MetaTag = { title: string } | { name: string; content: string } | { property: string; content: string };
interface HeadResult { meta: MetaTag[]; links: { rel: string; href: string }[]; scripts: { type: string; children: string }[] }

interface PageSeo {
  path: string;
  title: string;
  description: string;
  /** Share image under /public, for example /og/vps.jpg (1200x630). */
  image?: string;
  imageAlt?: string;
  type?: "website" | "article";
  jsonLd?: Json[];
}

const DEFAULT_OG_IMAGE = "/og/home.jpg";
/** Bump when the share images change so Discord, WhatsApp and X fetch the new files instead of their cached copies. */
const OG_IMAGE_VERSION = "2";
export const ORG_ID = `${SITE_URL}/#organization`;
const WEBSITE_ID = `${SITE_URL}/#website`;

/** Title, description, canonical, Open Graph, Twitter card and JSON-LD for one public page. */
export function pageHead(p: PageSeo): HeadResult {
  const url = absoluteUrl(p.path);
  const image = `${absoluteUrl(p.image ?? DEFAULT_OG_IMAGE)}?v=${OG_IMAGE_VERSION}`;
  const alt = p.imageAlt ?? `${site.name}: ${p.title}`;
  const meta: MetaTag[] = [
    { title: p.title },
    { name: "description", content: p.description },
    { name: "robots", content: "index, follow, max-image-preview:large" },
    { property: "og:type", content: p.type ?? "website" },
    { property: "og:site_name", content: site.name },
    { property: "og:locale", content: "en_IN" },
    { property: "og:url", content: url },
    { property: "og:title", content: p.title },
    { property: "og:description", content: p.description },
    { property: "og:image", content: image },
    { property: "og:image:width", content: "1200" },
    { property: "og:image:height", content: "630" },
    { property: "og:image:alt", content: alt },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:title", content: p.title },
    { name: "twitter:description", content: p.description },
    { name: "twitter:image", content: image },
    { name: "twitter:image:alt", content: alt },
  ];
  const scripts = (p.jsonLd ?? []).map((d) => ({ type: "application/ld+json", children: safeJson({ "@context": "https://schema.org", ...d }) }));
  return { meta, links: [{ rel: "canonical", href: url }], scripts };
}

/** JSON for an inline <script> data block: "<" is escaped so the text can never close the tag. */
function safeJson(v: unknown): string {
  return JSON.stringify(v).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}

// ---------------------------------------------------------------------------------------------------------
// JSON-LD builders

export function organizationLd(): Json {
  return {
    "@type": "Organization",
    "@id": ORG_ID,
    name: site.name,
    legalName: site.legalName,
    url: `${SITE_URL}/`,
    logo: { "@type": "ImageObject", url: absoluteUrl("/icon-512.png"), width: 512, height: 512 },
    description: site.blurb,
    address: { "@type": "PostalAddress", addressLocality: "Mumbai", postalCode: "400001", addressCountry: "IN" },
    areaServed: "IN",
    sameAs: [site.trustpilotUrl],
  };
}

export function websiteLd(): Json {
  return { "@type": "WebSite", "@id": WEBSITE_ID, name: site.name, url: `${SITE_URL}/`, inLanguage: "en-IN", publisher: { "@id": ORG_ID } };
}

export function breadcrumbLd(trail: { name: string; path: string }[]): Json {
  return {
    "@type": "BreadcrumbList",
    itemListElement: [{ name: "Home", path: "/" }, ...trail].map((t, i) => ({ "@type": "ListItem", position: i + 1, name: t.name, item: absoluteUrl(t.path) })),
  };
}

interface OfferPlan { name: string; monthly: number }

/** A hosting product with its monthly price range in INR (GST included), as Service and Product nodes. */
export function hostingLd(o: { path: string; name: string; serviceType: string; description: string; image: string; plans: OfferPlan[] }): Json[] {
  const prices = o.plans.map((p) => p.monthly).filter((n) => Number.isFinite(n) && n > 0);
  const offers = prices.length ? {
    "@type": "AggregateOffer",
    priceCurrency: "INR",
    lowPrice: Math.min(...prices),
    highPrice: Math.max(...prices),
    offerCount: prices.length,
    availability: "https://schema.org/InStock",
    url: absoluteUrl(o.path),
    priceSpecification: { "@type": "UnitPriceSpecification", priceCurrency: "INR", price: Math.min(...prices), unitText: "MONTH", valueAddedTaxIncluded: true },
  } : undefined;
  const url = absoluteUrl(o.path);
  return [
    {
      "@type": "Service",
      "@id": `${url}#service`,
      name: o.name,
      serviceType: o.serviceType,
      description: o.description,
      url,
      provider: { "@id": ORG_ID },
      ...(offers ? { offers } : {}),
    },
    {
      "@type": "Product",
      "@id": `${url}#product`,
      name: o.name,
      description: o.description,
      image: absoluteUrl(o.image),
      brand: { "@type": "Brand", name: site.name },
      category: o.serviceType,
      ...(offers ? { offers } : {}),
    },
  ];
}

export function faqLd(items: { q: string; a: string }[]): Json {
  return {
    "@type": "FAQPage",
    mainEntity: items.map((it) => ({ "@type": "Question", name: it.q, acceptedAnswer: { "@type": "Answer", text: it.a } })),
  };
}

// ---------------------------------------------------------------------------------------------------------
// Text files

const xmlEscape = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

export function sitemapXml(origin: string = runtimeSiteUrl()): string {
  const urls = publicPages.map((p) => `  <url>\n    <loc>${xmlEscape(absoluteUrl(p.path, origin))}</loc>\n    <lastmod>${p.lastmod}</lastmod>\n  </url>`);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>\n`;
}

/**
 * Crawler groups. A crawler that matches a named group ignores the "*" group, so every group repeats the
 * private-path rules. AI tokens marked "not documented" are names reported by crawler registries; the
 * vendor publishes no official user agent, so the group is a best effort.
 */
const crawlerGroups: { label: string; agents: string[] }[] = [
  { label: "Google Search", agents: ["Googlebot"] },
  { label: "Bing", agents: ["Bingbot"] },
  { label: "X (Twitter) link previews", agents: ["Twitterbot"] },
  { label: "Facebook, Instagram and WhatsApp link previews", agents: ["facebookexternalhit"] },
  { label: "OpenAI (documented: developers.openai.com/api/docs/bots)", agents: ["GPTBot", "OAI-SearchBot", "ChatGPT-User"] },
  { label: "Anthropic (documented: Claude Help Center, article 8896518)", agents: ["ClaudeBot", "Claude-SearchBot", "Claude-User"] },
  { label: "Google Gemini and Vertex AI (documented robots.txt token Google-Extended)", agents: ["Google-Extended"] },
  { label: "xAI Grok (not documented by xAI; names reported by crawler registries)", agents: ["GrokBot", "xAI-SearchBot"] },
  { label: "DeepSeek (not documented by DeepSeek; name reported by crawler registries)", agents: ["DeepSeekBot"] },
];

export function robotsTxt(origin: string = runtimeSiteUrl()): string {
  const rules = ["Allow: /", ...privatePathPrefixes.map((p) => `Disallow: ${p}`)];
  const group = (label: string, agents: string[]) => [`# ${label}`, ...agents.map((a) => `User-agent: ${a}`), ...rules, ""].join("\n");
  return [
    `# robots.txt for ${site.name}. Public pages are open to search engines and AI assistants;`,
    "# sign-in, account, checkout, administrator and API paths are not.",
    "",
    ...crawlerGroups.map((g) => group(g.label, g.agents)),
    group("Everyone else", ["*"]),
    `Sitemap: ${absoluteUrl("/sitemap.xml", origin)}`,
    "",
  ].join("\n");
}

export function llmsTxt(origin: string = runtimeSiteUrl()): string {
  const section = (g: PublicPage["group"]) => [`## ${g}`, "", ...publicPages.filter((p) => p.group === g).map((p) => `- [${p.name}](${absoluteUrl(p.path, origin)}): ${p.summary}`), ""];
  return [
    `# ${site.name}`,
    "",
    `> ${site.blurb} Minecraft, Hytale, Counter Strike 2 and Rust servers, KVM VPS and Discord bot hosting on enterprise AMD EPYC 7000 and 9000 series processors (EPYC 9V74 up to 3.70 GHz with DDR5 4800 MHz, EPYC 7763 up to 3.50 GHz and EPYC 7V12 up to 3.35 GHz with DDR4 3200 MHz) and NVMe Gen 4 storage. Servers are placed on the best node available in each location; every plan gets at least an AMD EPYC at 3.35 GHz with DDR4 3200 MHz memory. Prices in INR with GST included.`,
    "",
    "Locations: Mumbai and Hyderabad (India), Dubai (UAE), Frankfurt (Germany) and Virginia (United States). Support through on-site tickets, Discord and email.",
    "",
    ...section("Hosting"),
    ...section("Pages"),
    ...section("Legal"),
  ].join("\n");
}
