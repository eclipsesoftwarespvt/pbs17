// Browser-only helper for the Razorpay checkout window.
type RazorpayInstance = { open: () => void; on: (e: string, cb: (r: { error?: { description?: string; reason?: string } }) => void) => void };
declare global { interface Window { Razorpay?: new (o: Record<string, unknown>) => RazorpayInstance } }

let loading: Promise<void> | null = null;
function loadRazorpay() {
  if (window.Razorpay) return Promise.resolve();
  loading ??= new Promise<void>((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => { loading = null; s.remove(); reject(new Error("Could not load the payment window. Check your connection and try again.")); };
    document.body.appendChild(s);
  });
  return loading;
}

export interface RazorpayResult { razorpay_payment_id: string; razorpay_order_id: string; razorpay_signature: string }
type RazorpayOutcome =
  | { status: "paid"; result: RazorpayResult }
  | { status: "cancelled" }
  | { status: "failed"; reason: string };

/** Opens Razorpay and resolves once: paid (signed result), cancelled (closed without paying) or failed (last failure reason). */
export async function openRazorpay(o: { keyId: string; amount: number; orderId: string; description: string; email?: string | undefined; onOpen?: () => void }): Promise<RazorpayOutcome> {
  await loadRazorpay();
  const Razorpay = window.Razorpay;
  if (!Razorpay) throw new Error("The payment window is unavailable. Please try again.");
  return new Promise<RazorpayOutcome>((resolve) => {
    let lastFailure: string | null = null;
    let settled = false;
    const done = (v: RazorpayOutcome) => { if (!settled) { settled = true; resolve(v); } };
    const rzp = new Razorpay({
      key: o.keyId,
      amount: o.amount * 100,
      currency: "INR",
      name: "PlexScale",
      description: o.description,
      order_id: o.orderId,
      prefill: o.email ? { email: o.email } : {},
      theme: { color: "#4d8dff", backdrop_color: "#070b1a" },
      retry: { enabled: true, max_count: 3 },
      handler: (r: RazorpayResult) => done({ status: "paid", result: r }),
      modal: { ondismiss: () => done(lastFailure ? { status: "failed", reason: lastFailure } : { status: "cancelled" }), confirm_close: true, escape: false },
    });
    rzp.on("payment.failed", (r) => {
      const d = r?.error?.description ?? "";
      // Only short, plain provider text is shown to the customer.
      lastFailure = /^[\w\s.,'’:()-]{3,160}$/.test(d) ? d : "The bank or payment method declined the payment.";
    });
    rzp.open();
    o.onOpen?.();
  });
}
