// Razorpay webhook logic with its storage passed in, so replays, bad signatures and amounts can be tested.
import { hmacHexPure, safeEqualPure } from "./crypto-utils";

interface WebhookDeps {
  secret: string | undefined;
  /** Inserts the event id; "duplicate" when it was already processed (replay). */
  recordEvent: (eventId: string, event: string) => Promise<"new" | "duplicate">;
  /** Removes the event id again after a processing failure so Razorpay's retry is accepted. */
  forgetEvent: (eventId: string) => Promise<void>;
  findOrder: (razorpayOrderId: string) => Promise<{ id: string; amount: number; status: string; razorpay_payment_id: string | null } | null>;
  markPaid: (orderId: string, paymentId: string) => Promise<void>;
  log?: (level: "info" | "warn" | "error", event: string, fields: Record<string, unknown>) => void;
}

type Payment = { id?: string; order_id?: string; amount?: number; currency?: string; status?: string };

export async function handleRazorpayWebhook(request: Request, deps: WebhookDeps): Promise<Response> {
  if (!deps.secret) return new Response("Not configured", { status: 503 });
  const signature = request.headers.get("x-razorpay-signature") ?? "";
  const body = await request.text();
  if (body.length > 100_000) return new Response("Too large", { status: 413 });
  const expected = await hmacHexPure(deps.secret, body);
  if (!signature || !safeEqualPure(expected, signature)) return new Response("Invalid signature", { status: 401 });

  let event: { event?: string; payload?: { payment?: { entity?: Payment } } };
  try { event = JSON.parse(body); } catch { return new Response("Bad payload", { status: 400 }); }
  if (event.event !== "payment.captured" && event.event !== "order.paid") return new Response("ignored");
  const p = event.payload?.payment?.entity;
  if (!p?.id || !p.order_id || p.currency !== "INR") return new Response("ignored");

  // Replay protection: each Razorpay event id is processed once. Falls back to event+payment when the header is missing.
  const eventId = (request.headers.get("x-razorpay-event-id") ?? `${event.event}:${p.id}`).slice(0, 100);
  if ((await deps.recordEvent(eventId, event.event)) === "duplicate") return new Response("ok");

  try {
    const order = await deps.findOrder(p.order_id);
    if (!order || (order.status !== "pending" && !(order.status === "failed" && !order.razorpay_payment_id))) return new Response("ok");
    if (Number(p.amount) !== order.amount * 100) {
      deps.log?.("error", "webhook.amount_mismatch", { orderId: order.id });
      return new Response("ok");
    }
    await deps.markPaid(order.id, p.id);
    deps.log?.("info", "webhook.paid", { orderId: order.id });
    return new Response("ok");
  } catch (e) {
    await deps.forgetEvent(eventId);
    deps.log?.("error", "webhook.failed", { message: e instanceof Error ? e.message : String(e) });
    return new Response("Retry later", { status: 500 });
  }
}
