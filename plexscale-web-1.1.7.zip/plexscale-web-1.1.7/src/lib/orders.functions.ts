import { PublicError } from "@/lib/public-error";
import type { Json } from "@/integrations/supabase/types";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { deployLimits, effectivePlans, findEffectivePlan, isBilling, periodTotal } from "@/config/plans";
import { canUpgradeProduct, upgradeQuote } from "@/config/upgrade-rules";
import { checkoutInput, deploymentError, MAX_PENDING_PER_HOUR } from "@/config/order-rules";
import { isOrderRefundEligible } from "@/config/refund-rules";
import { pickGameOptions } from "@/config/game-options";
import { couponCodeInput, couponDiscount, couponErrorMessage, couponErrors, couponProblem } from "@/config/coupon-rules";

const uuid = z.string().uuid();

const payOptions = z.object({ useCredits: z.boolean().default(false) });

export const createCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => {
    const raw = (d && typeof d === "object" ? d : {}) as Record<string, unknown>;
    const { useCredits } = payOptions.parse({ useCredits: raw["useCredits"] });
    const rest = { ...raw };
    delete rest["useCredits"];
    return { ...checkoutInput.parse(rest), useCredits };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { loadSiteSettings, razorpayKeys, startOrderPayment, assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("checkout", { userId: context.userId, perUser: 10, perIp: 30, windowSeconds: 600, failClosed: true });
    await assertNotMaintenance(context.userId);
    const coupon = data.coupon ? couponCodeInput.safeParse(data.coupon) : null;
    if (coupon && !coupon.success) throw new PublicError(couponErrors.coupon_invalid);
    const settings = await loadSiteSettings();
    if (!settings.ordering.enabled) throw new PublicError(settings.ordering.pausedMessage || "New orders are paused.");
    if (settings.ordering.comingSoon.includes(data.product)) throw new PublicError("This product is coming soon. Orders open shortly.");
    if (settings.ordering.disabledProducts.includes(data.product)) throw new PublicError("This product is out of stock right now.");
    const availabilityError = deploymentError(data, settings);
    if (availabilityError) throw new PublicError(availabilityError);
    const plan = findEffectivePlan(data.product, data.plan, settings.plans);
    if (!plan || !isBilling(data.billing)) throw new PublicError("That plan is not available.");
    if (!data.useCredits) razorpayKeys();

    const since = new Date(Date.now() - 3600_000).toISOString();
    const { count } = await supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("user_id", context.userId).eq("status", "pending").gte("created_at", since);
    if ((count ?? 0) >= MAX_PENDING_PER_HOUR) throw new PublicError("Too many unpaid checkouts. Please finish one or wait an hour.");

    const amount = periodTotal(plan.monthly, data.billing);
    const { data: order, error } = await supabaseAdmin.from("orders").insert({
      user_id: context.userId, kind: "new", product: data.product, plan_id: plan.id, plan_name: plan.name, billing: data.billing,
      location: data.location, amount, server_name: data.serverName, description: data.description, software: data.software,
      version: data.product === "minecraft" ? data.version : null, config: { eula: data.eula, deploy: JSON.parse(JSON.stringify(plan.deploy ?? {})) as Json, game: JSON.parse(JSON.stringify(pickGameOptions(data.product, data.game))) as Json },
      cpu_percent: deployLimits(plan).cpu, ram_mb: deployLimits(plan).memoryMib, disk_mb: deployLimits(plan).diskMib,
    }).select("id").single();
    if (error || !order) throw new PublicError("Could not create your order.");

    // The coupon is checked, counted and applied in one locked database transaction.
    let total = amount;
    let discount = 0;
    if (coupon?.success) {
      const { data: applied, error: couponError } = await supabaseAdmin.rpc("apply_coupon", { _order_id: order.id, _code: coupon.data });
      const row = Array.isArray(applied) ? applied[0] : null;
      if (couponError || !row) {
        await supabaseAdmin.from("orders").update({ status: "failed" }).eq("id", order.id).eq("status", "pending");
        throw new PublicError(couponErrorMessage(couponError?.message));
      }
      total = row.new_amount;
      discount = row.discount;
    }

    const started = await startOrderPayment({ id: order.id, amount: total }, { useCredits: data.useCredits, notes: { kind: "new" } });
    return { ...started, discount };
  });

/** Read-only coupon check for the deploy page. The real discount is applied again inside createCheckout. */
export const previewCoupon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { code: string; product: string; plan: string; billing: string }) => z.object({
    code: z.string().max(40), product: z.string().max(20), plan: z.string().min(1).max(40), billing: z.string().max(20),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { loadSiteSettings } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("coupon", { userId: context.userId, perUser: 10, perIp: 30, windowSeconds: 60, message: "Too many coupon tries. Please wait a minute." });
    const code = couponCodeInput.safeParse(data.code);
    if (!code.success) return { ok: false as const, message: couponErrors.coupon_invalid };
    const settings = await loadSiteSettings();
    const plan = findEffectivePlan(data.product, data.plan, settings.plans);
    if (!plan || !isBilling(data.billing)) return { ok: false as const, message: "That plan is not available." };
    const amount = periodTotal(plan.monthly, data.billing);
    const { data: c } = await supabaseAdmin.from("coupons").select("id, kind, value, max_discount, active, starts_at, expires_at, products, min_amount, max_uses, per_user_limit").eq("code", code.data).maybeSingle();
    if (!c) return { ok: false as const, message: couponErrors.coupon_invalid };
    const [{ count: uses }, { count: userUses }] = await Promise.all([
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("coupon_id", c.id).neq("status", "failed"),
      supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("coupon_id", c.id).eq("user_id", context.userId).neq("status", "failed"),
    ]);
    const problem = couponProblem({ ...c, kind: c.kind as "percent" | "fixed" }, { product: data.product, amount, uses: uses ?? 0, userUses: userUses ?? 0 });
    if (problem) return { ok: false as const, message: couponErrors[problem] };
    const discount = couponDiscount({ ...c, kind: c.kind as "percent" | "fixed" }, amount);
    return { ok: true as const, code: code.data, discount, total: amount - discount };
  });

export const createRenewal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string; useCredits?: boolean }) => z.object({ orderId: uuid, useCredits: z.boolean().default(false) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { loadSiteSettings, razorpayKeys, startOrderPayment, assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("checkout", { userId: context.userId, perUser: 10, perIp: 30, windowSeconds: 600, failClosed: true });
    await assertNotMaintenance(context.userId);
    const { data: parent } = await supabaseAdmin.from("orders").select("*").eq("id", data.orderId).maybeSingle();
    if (!parent || parent.user_id !== context.userId || parent.kind !== "new" || !["active", "suspended"].includes(parent.status) || !isBilling(parent.billing)) throw new PublicError("This service cannot be renewed.");
    const since = new Date(Date.now() - 3600_000).toISOString();
    const { count } = await supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("user_id", context.userId).eq("kind", "renewal").eq("status", "pending").gte("created_at", since);
    if ((count ?? 0) >= MAX_PENDING_PER_HOUR) throw new PublicError("Please complete a pending renewal before starting another.");
    const settings = await loadSiteSettings();
    const plan = findEffectivePlan(parent.product, parent.plan_id, settings.plans);
    if (!plan) throw new PublicError("This plan is no longer offered, so it can't be renewed online. Please open a support ticket.");
    const amount = periodTotal(plan.monthly, parent.billing);
    if (!data.useCredits) razorpayKeys();
    const { data: order, error } = await supabaseAdmin.from("orders").insert({
      user_id: context.userId, kind: "renewal", parent_order_id: parent.id, product: parent.product, plan_id: parent.plan_id, plan_name: parent.plan_name,
      billing: parent.billing, location: parent.location, amount, server_name: parent.server_name,
    }).select("id").single();
    if (error || !order) throw new PublicError("Could not start the renewal.");
    const started = await startOrderPayment({ id: order.id, amount }, { useCredits: data.useCredits, notes: { kind: "renewal" } });
    return { ...started, parentId: parent.id };
  });

export const verifyPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string; razorpayOrderId: string; paymentId: string; signature: string }) => z.object({
    orderId: uuid, razorpayOrderId: z.string().regex(/^order_[A-Za-z0-9]{6,40}$/), paymentId: z.string().regex(/^pay_[A-Za-z0-9]{6,40}$/), signature: z.string().regex(/^[a-f0-9]{64}$/),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { razorpayKeys, hmacHex, safeEqual, confirmRazorpayPayment, markPaid } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("verify", { userId: context.userId, perUser: 20, perIp: 60, windowSeconds: 600, failClosed: true });
    const { keySecret } = razorpayKeys();
    const expected = await hmacHex(keySecret, `${data.razorpayOrderId}|${data.paymentId}`);
    if (!safeEqual(expected, data.signature)) throw new PublicError("Payment could not be verified.");
    const { data: order } = await supabaseAdmin.from("orders").select("id, user_id, amount, razorpay_order_id, status, razorpay_payment_id").eq("id", data.orderId).maybeSingle();
    if (!order || order.user_id !== context.userId || order.razorpay_order_id !== data.razorpayOrderId) throw new PublicError("Order not found.");
    if (order.status === "pending" || (order.status === "failed" && !order.razorpay_payment_id)) {
      await confirmRazorpayPayment(data.paymentId, data.razorpayOrderId, order.amount);
      await markPaid(order.id, data.paymentId);
      if (order.status === "failed") {
        const { data: refreshed } = await supabaseAdmin.from("orders").select("razorpay_payment_id").eq("id", order.id).maybeSingle();
        if (!refreshed?.razorpay_payment_id) throw new PublicError("Payment received and is being reconciled. Please contact support if setup does not begin shortly.");
      }
    } else if (order.razorpay_payment_id !== data.paymentId) {
      throw new PublicError("Payment could not be verified.");
    }
    return { ok: true };
  });

export const requestRefund = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string; reason: string }) => z.object({ orderId: uuid, reason: z.string().trim().min(5).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("refund", { userId: context.userId, perUser: 5, perIp: 20, windowSeconds: 3600, failClosed: true });
    await assertNotMaintenance(context.userId);
    const { data: order } = await supabaseAdmin.from("orders").select("id, user_id, paid_at, product, kind, status").eq("id", data.orderId).maybeSingle();
    if (!order || order.user_id !== context.userId || !isOrderRefundEligible(order.kind, order.product, order.paid_at)) throw new PublicError("This purchase is outside the eligible refund window.");
    if (order.kind !== "new" || ["refunded", "cancelled", "failed"].includes(order.status)) throw new PublicError("This order cannot be refunded.");
    const { error } = await supabaseAdmin.from("refunds").insert({ order_id: order.id, user_id: context.userId, reason: data.reason, created_at: new Date().toISOString() });
    if (error) throw new PublicError(error.code === "23505" ? "You already asked for a refund on this order." : "Could not send your refund request.");
    return { ok: true };
  });

async function loadUpgrade(userId: string, orderId: string, toPlanId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { loadSiteSettings } = await import("@/lib/billing.server");
  const { data: parent } = await supabaseAdmin.from("orders").select("*").eq("id", orderId).maybeSingle();
  if (!parent || parent.user_id !== userId || parent.kind !== "new" || !isBilling(parent.billing)) throw new PublicError("This service cannot be upgraded.");
  if (!canUpgradeProduct(parent.product)) throw new PublicError("VPS plans cannot be upgraded online. Please contact support.");
  if (parent.status !== "active") throw new PublicError("Only active services can be upgraded.");
  const settings = await loadSiteSettings();
  if (!settings.ordering.enabled || settings.ordering.disabledProducts.includes(parent.product)) throw new PublicError("Upgrades for this product are paused right now.");
  const from = effectivePlans(parent.product, settings.plans, true).find((p) => p.id === parent.plan_id);
  const to = findEffectivePlan(parent.product, toPlanId, settings.plans);
  if (!from || !to) throw new PublicError("That plan is not available.");
  const quote = upgradeQuote(from, to, parent.billing, parent.renews_at);
  if (!quote.ok) throw new PublicError(quote.reason);
  return { parent, from, to, quote, billing: parent.billing };
}

const upgradeInput = (d: { orderId: string; toPlanId: string; useCredits?: boolean }) => z.object({ orderId: uuid, toPlanId: z.string().trim().min(1).max(40).regex(/^[a-z0-9-]+$/), useCredits: z.boolean().default(false) }).parse(d);

/** Read-only price check for an upgrade. The charged amount is always recalculated in createUpgrade. */
export const quoteUpgrade = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(upgradeInput)
  .handler(async ({ data, context }) => {
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("quote", { userId: context.userId, perUser: 60, perIp: 120, windowSeconds: 600 });
    const u = await loadUpgrade(context.userId, data.orderId, data.toPlanId);
    return { amount: u.quote.amount, remainingDays: u.quote.remainingDays, periodDays: u.quote.periodDays, difference: u.quote.difference, fromPlan: u.from.name, toPlan: u.to.name, renewsAt: u.parent.renews_at };
  });

export const createUpgrade = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(upgradeInput)
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { razorpayKeys, startOrderPayment, assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("checkout", { userId: context.userId, perUser: 10, perIp: 30, windowSeconds: 600, failClosed: true });
    await assertNotMaintenance(context.userId);
    const u = await loadUpgrade(context.userId, data.orderId, data.toPlanId);
    const since = new Date(Date.now() - 3600_000).toISOString();
    const { count } = await supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("user_id", context.userId).eq("kind", "upgrade").eq("status", "pending").gte("created_at", since);
    if ((count ?? 0) >= MAX_PENDING_PER_HOUR) throw new PublicError("Please finish a pending upgrade before starting another.");
    if (!data.useCredits) razorpayKeys();
    const limits = deployLimits(u.to);
    const { data: order, error } = await supabaseAdmin.from("orders").insert({
      user_id: context.userId, kind: "upgrade", parent_order_id: u.parent.id, product: u.parent.product, plan_id: u.to.id, plan_name: u.to.name,
      billing: u.billing, location: u.parent.location, amount: u.quote.amount, server_name: u.parent.server_name,
      cpu_percent: limits.cpu, ram_mb: limits.memoryMib, disk_mb: limits.diskMib,
      config: { fromPlanId: u.from.id, fromPlanName: u.from.name, parentRenewsAt: u.parent.renews_at, remainingDays: u.quote.remainingDays, cpu: limits.cpu, memoryMib: limits.memoryMib, diskMib: limits.diskMib, deploy: JSON.parse(JSON.stringify(u.to.deploy ?? {})) as Json },
    }).select("id").single();
    if (error || !order) throw new PublicError("Could not start the upgrade.");
    const started = await startOrderPayment({ id: order.id, amount: u.quote.amount }, { useCredits: data.useCredits, notes: { kind: "upgrade" } });
    return { ...started, parentId: u.parent.id, toPlan: u.to.name };
  });

/** Customer download of their own invoice as a PDF (base64). */
export const getInvoicePdf = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string }) => ({ orderId: uuid.parse(d.orderId) }))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("invoice", { userId: context.userId, perUser: 30, perIp: 60, windowSeconds: 600, message: "Too many downloads. Please wait a few minutes." });
    const { data: order } = await supabaseAdmin.from("orders").select("id, user_id, paid_at, razorpay_payment_id").eq("id", data.orderId).maybeSingle();
    let allowed = order?.user_id === context.userId;
    if (!allowed && order) {
      const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
      allowed = isAdmin === true;
    }
    if (!order || !allowed || !order.paid_at || !order.razorpay_payment_id) throw new PublicError("Invoice not available.");
    const { ensureInvoice } = await import("@/lib/notify.server");
    const { renderInvoicePdf } = await import("@/lib/invoice.server");
    const inv = await ensureInvoice(order.id);
    if (!inv) throw new PublicError("Invoice not available.");
    const pdf = await renderInvoicePdf(inv.data);
    let bin = "";
    for (let i = 0; i < pdf.length; i += 0x8000) bin += String.fromCharCode(...pdf.subarray(i, i + 0x8000));
    return { filename: `PlexScale-Invoice-${inv.number}.pdf`, base64: btoa(bin) };
  });

/** Sends the welcome email once, right after the first sign-in. */
export const ensureWelcome = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { hitRateLimit } = await import("@/lib/rate-limit.server");
    if (!(await hitRateLimit(`welcome:u:${context.userId}`, 3, 3600))) return { ok: true };
    const { sendWelcome } = await import("@/lib/notify.server");
    await sendWelcome(context.userId);
    return { ok: true };
  });

/**
 * Generates fresh panel credentials for one of the customer's services and returns them once.
 * Game and bot services reset the Pterodactyl user; VPS services reset the Plexus account. The login email is the billing email.
 */
export const generatePanelAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string }) => ({ orderId: uuid.parse(d.orderId) }))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    const { audit, loadSiteSettings, ensurePlexusAccount } = await import("@/lib/billing.server");
    const { reportPanelFailure } = await import("@/lib/panel-errors.server");
    const { strongPassword, setAccountPassword, plexusConfigured } = await import("@/lib/plexus.server");
    const { resetUserPassword, panelConfigured } = await import("@/lib/pterodactyl.server");
    await assertRateLimit("panel_access", { userId: context.userId, perUser: 5, perIp: 15, windowSeconds: 900, message: "Too many password resets. Please wait a few minutes." });
    const { data: order } = await supabaseAdmin.from("orders").select("id, user_id, kind, product, status").eq("id", data.orderId).maybeSingle();
    if (!order || order.user_id !== context.userId || order.kind !== "new" || !["active", "suspended", "provisioning"].includes(order.status)) throw new PublicError("This service is not available.");
    const { data: u } = await supabaseAdmin.auth.admin.getUserById(context.userId);
    const email = u.user?.email;
    if (!email) throw new PublicError("Your account has no email address.");
    const settings = await loadSiteSettings();
    const isVps = order.product === "vps";
    const password = strongPassword(20);
    try {
      if (isVps) {
        if (!plexusConfigured()) throw new PublicError("not configured");
        await setAccountPassword(await ensurePlexusAccount(context.userId), password);
      } else {
        if (!panelConfigured()) throw new PublicError("not configured");
        const { data: profile } = await supabaseAdmin.from("profiles").select("display_name").eq("id", context.userId).maybeSingle();
        await resetUserPassword(email, profile?.display_name ?? "", context.userId, password);
      }
    } catch (e) {
      await reportPanelFailure(e, { action: "provision", orderId: order.id, userId: context.userId, product: order.product });
      throw new PublicError("We couldn’t generate new credentials right now. Please try again or contact support.");
    }
    await audit(context.userId, "panel.access_reset", order.id, { panel: isVps ? "plexus" : "pterodactyl" });
    return { panel: isVps ? ("vps" as const) : ("game" as const), email, password, panelUrl: isVps ? settings.vpsPanelUrl : settings.gamePanelUrl };
  });
