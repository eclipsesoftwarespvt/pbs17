import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/** Public Turnstile site key for the widget, or null when the check is not configured (sign-in is then refused). */
export const getTurnstileConfig = createServerFn({ method: "GET" }).handler(async () => {
  const { turnstileSiteKey } = await import("@/lib/turnstile.server");
  return { siteKey: turnstileSiteKey() };
});

/** Confirms a sign-in Turnstile token with Cloudflare. Rate limited per visitor IP. */
export const verifyHuman = createServerFn({ method: "POST" })
  .validator((d: { token: string }) => z.object({ token: z.string().min(10).max(2048) }).parse(d))
  .handler(async ({ data }) => {
    const { hitRateLimit } = await import("@/lib/rate-limit.server");
    const { clientIp } = await import("@/lib/client-ip.server");
    const ip = clientIp();
    if (ip && !(await hitRateLimit(`signin:ip:${ip}`, 20, 600))) return { ok: false };
    const { verifyTurnstileToken } = await import("@/lib/turnstile.server");
    return { ok: await verifyTurnstileToken(data.token, "login") };
  });
