// Errors that are safe to show to the person using the site. Anything else is replaced with a generic line.
export class PublicError extends Error {
  readonly expose = true;
}

const GENERIC_ERROR = "Something went wrong. Please try again.";
const INPUT_ERROR = "Please check the details and try again.";

type Issue = { code?: string; message?: string };

/** The message a visitor may see for this error. */
export function publicMessage(e: unknown): string {
  if (e instanceof PublicError && e.message) return e.message.slice(0, 300);
  if (e instanceof Error && e.message.startsWith("Unauthorized")) return "Please sign in again.";
  if (e && typeof e === "object" && "issues" in e && Array.isArray((e as { issues: unknown }).issues)) {
    const first = (e as { issues: Issue[] }).issues[0];
    return first?.code === "custom" && first.message ? first.message.slice(0, 200) : INPUT_ERROR;
  }
  return GENERIC_ERROR;
}

const TECHNICAL = /fetch|network|json|undefined|null|syntax|token|typeerror|referenceerror|cannot read|is not a function|stack|postgres|supabase|sql|tanstack|react|vite|node|worker|server fn|serverfn|http|status \d|[{}<>]/i;

/** Browser side: the error's message when it reads like a friendly sentence, otherwise the fallback. */
export function shownError(e: unknown, fallback: string): string {
  const m = e instanceof Error ? e.message.trim() : "";
  return m && m.length <= 200 && !TECHNICAL.test(m) ? m : fallback;
}
