// Shared administrator check for server functions. Every admin action calls this on the server,
// whatever the browser shows. The role is read through the caller's own token (row level security applies).
import { PublicError } from "./public-error";

type Ctx = { supabase: { rpc: (fn: "has_role", args: { _user_id: string; _role: "admin" | "user" }) => PromiseLike<{ data: boolean | null; error?: unknown }> }; userId: string };

class ForbiddenError extends PublicError {
  constructor() { super("You don't have access to this."); }
}

/** Throws unless the caller is an administrator. Changes (`mutate`) are also rate limited per admin. */
export async function assertAdmin(context: Ctx, opts: { mutate?: boolean } = {}) {
  const { data, error } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (error || data !== true) throw new ForbiddenError();
  if (opts.mutate) {
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("admin_write", { userId: context.userId, perUser: 120, windowSeconds: 60, failClosed: true, message: "Too many changes in a short time. Please wait a moment." });
  }
}
