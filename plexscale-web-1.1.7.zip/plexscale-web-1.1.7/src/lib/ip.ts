const V4 = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
const V6 = /^[0-9a-f:]{2,39}$/i;

/** Returns a clean IPv4 (or IPv6 when no IPv4 exists), or null. Never returns raw header text. */
function normalizeIp(raw: string | null | undefined): string | null {
  const v = (raw ?? "").trim();
  if (!v) return null;
  const mapped = v.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i)?.[1];
  if (mapped && V4.test(mapped)) return mapped;
  if (V4.test(v)) return v;
  if (V6.test(v) && v.includes(":")) return v.toLowerCase();
  return null;
}

/**
 * The visitor IP from Cloudflare's CF-Connecting-IP header. The site is only reachable through the
 * Cloudflare tunnel, which always sets it. X-Forwarded-For, X-Real-IP, True-Client-IP and similar
 * headers are never read because a client can send any value in them.
 */
export function cloudflareIp(headers: Pick<Headers, "get">): string | null {
  return normalizeIp(headers.get("cf-connecting-ip"));
}
