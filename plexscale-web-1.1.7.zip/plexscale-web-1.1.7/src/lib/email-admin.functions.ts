import { PublicError } from "@/lib/public-error";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { emailSettingsInput, templateKeys, type TemplateKey } from "@/config/email";

import { assertAdmin } from "@/lib/admin-guard";

/** Settings for the admin form. Stored secrets are never returned, only whether they are set. */
export const getEmailSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { loadEmailConfig, smtpReady } = await import("@/lib/notify.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const cfg = await loadEmailConfig();
    const { data: log } = await supabaseAdmin.from("email_events").select("id, kind, recipient, status, error, created_at").order("created_at", { ascending: false }).limit(50);
    return {
      settings: cfg.settings,
      smtpPasswordSet: Boolean(cfg.smtpPassword),
      discordWebhookSet: Boolean(cfg.discordWebhook),
      ready: smtpReady(cfg),
      encryption: Boolean(process.env["SETTINGS_ENCRYPTION_KEY"]),
      log: (log ?? []).map((l) => ({ ...l, error: l.error ? (l.error.length > 120 || /[{}<>]|error:|at /i.test(l.error) ? "Sending failed. Check the SMTP settings." : l.error) : null, recipient: l.recipient ? l.recipient.replace(/^(.{2}).*(@.*)$/, "$1***$2") : null })),
    };
  });

export const saveEmailSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => emailSettingsInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const { sealSecret } = await import("@/lib/secret-box.server");
    const { data: row } = await supabaseAdmin.from("email_settings").select("data").eq("id", 1).maybeSingle();
    const prev = (row?.data && typeof row.data === "object" ? row.data : {}) as Record<string, unknown>;
    const { smtpPassword, clearSmtpPassword, discordWebhookUrl, clearDiscordWebhook, ...settings } = data;
    let smtpPasswordEnc = prev["smtpPasswordEnc"] ?? null;
    let discordWebhookEnc = prev["discordWebhookEnc"] ?? null;
    if (clearSmtpPassword) smtpPasswordEnc = null; else if (smtpPassword) smtpPasswordEnc = await sealSecret(smtpPassword);
    if (clearDiscordWebhook) discordWebhookEnc = null; else if (discordWebhookUrl) discordWebhookEnc = await sealSecret(discordWebhookUrl);
    const next = { ...settings, smtpPasswordEnc, discordWebhookEnc };
    const { data: saved, error } = await supabaseAdmin.from("email_settings").update({ data: next as never, updated_at: new Date().toISOString() }).eq("id", 1).select("id").maybeSingle();
    if (error || !saved) throw new PublicError("Could not save email settings.");
    await adminAudit(context.userId, "settings.email.update", null, { smtpPasswordChanged: Boolean(smtpPassword || clearSmtpPassword), discordChanged: Boolean(discordWebhookUrl || clearDiscordWebhook) });
    return { ok: true };
  });

/** Sends a chosen template with sample values to the signed-in admin's own address. */
export const sendTestEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { template: string }) => z.object({ template: z.enum(templateKeys as unknown as [TemplateKey, ...TemplateKey[]]) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { loadEmailConfig, smtpReady } = await import("@/lib/notify.server");
    const { sendSmtp } = await import("@/lib/smtp.server");
    const { renderHtml, renderSubject, renderText, sampleVars, templateMeta } = await import("@/config/email");
    const { renderInvoicePdf } = await import("@/lib/invoice.server");
    const cfg = await loadEmailConfig();
    if (!smtpReady(cfg)) return { ok: false as const, message: "Turn on SMTP and fill in the server, sender address and password first, then save." };
    const { data: u } = await supabaseAdmin.auth.admin.getUserById(context.userId);
    const to = u?.user?.email;
    if (!to) return { ok: false as const, message: "Your account has no email address." };
    const { adminAudit } = await import("@/lib/billing.server");
    await adminAudit(context.userId, "email.test", data.template);
    const tpl = cfg.settings.templates[data.template];
    const subject = `[Test] ${renderSubject(tpl.subject, sampleVars)}`;
    const attachments = templateMeta[data.template].invoice ? [{
      filename: "PlexScale-Invoice-PX-1001.pdf", contentType: "application/pdf",
      content: await renderInvoicePdf({ number: "PX-1001", issuedAt: new Date().toISOString(), kind: "new", seller: { name: cfg.settings.invoice.businessName, address: cfg.settings.invoice.address, gstin: cfg.settings.invoice.gstin, email: cfg.settings.invoice.email }, buyer: { name: "Aarav Sharma", email: to, address: "Mumbai, Maharashtra", phone: "", gstin: "" }, items: [{ description: "Minecraft Mark 3", detail: "Billing: monthly. Service: Survival SMP. Location: mumbai.", amount: 279 }], total: 279, paymentId: "pay_TEST123456", orderId: crypto.randomUUID(), note: cfg.settings.invoice.note }),
    }] : undefined;
    try {
      await sendSmtp(
        { host: cfg.settings.smtp.host, port: cfg.settings.smtp.port, security: cfg.settings.smtp.security, username: cfg.settings.smtp.username, password: cfg.smtpPassword ?? "" },
        { fromName: cfg.settings.smtp.fromName || "PlexScale", fromEmail: cfg.settings.smtp.fromEmail, to, replyTo: cfg.settings.smtp.replyTo || undefined, subject, text: renderText(tpl.body, sampleVars), html: renderHtml(tpl.body, sampleVars, { preheader: subject }), attachments },
      );
      return { ok: true as const, message: `Test email sent to ${to}.` };
    } catch (e) {
      const { smtpFailureReason } = await import("@/lib/notify.server");
      const { logEvent } = await import("@/lib/log");
      logEvent("warn", "email.test_failed", { detail: e instanceof Error ? e.message.slice(0, 300) : "unknown" });
      return { ok: false as const, message: smtpFailureReason(e instanceof Error ? e.message : "") };
    }
  });

export const testDiscordWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context, { mutate: true });
    const { loadEmailConfig, postDiscord } = await import("@/lib/notify.server");
    const cfg = await loadEmailConfig();
    if (!cfg.discordWebhook) return { ok: false as const, message: "Save a Discord webhook address first." };
    const { adminAudit } = await import("@/lib/billing.server");
    await adminAudit(context.userId, "discord.test", null);
    try {
      await postDiscord(cfg.discordWebhook, { username: "PlexScale Support", allowed_mentions: { parse: [] }, embeds: [{ title: "Test alert", description: "Ticket alerts from PlexScale will appear in this channel.", color: 0x4d8dff, timestamp: new Date().toISOString() }] });
      return { ok: true as const, message: "Test alert sent to Discord." };
    } catch (e) {
      return { ok: false as const, message: "Discord did not accept the alert. Check the webhook address." };
    }
  });
