import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/ark-survival")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "ark");
    const from = fromLabel(plans);
    const title = "ARK: Survival Server Hosting on AMD EPYC | PlexScale";
    const description = `ARK: Survival Ascended and Evolved servers from ${from} a month on AMD EPYC 9V74 and 7763 with NVMe storage, mods and DDoS protection. GST included.`;
    return pageHead({
      path: "/ark-survival", title, description, image: "/og/ark.jpg", imageAlt: "ARK: Survival Evolved server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/ark-survival", name: "PlexScale ARK: Survival Evolved server hosting", serviceType: "Game server hosting", description, image: "/og/ark.jpg", plans }), breadcrumbLd([{ name: "ARK: Survival Evolved server hosting", path: "/ark-survival" }])],
    });
  },
  component: () => (
    <GamePage game="ark" name="ARK: Survival" image={img.ark} sub="Tame, build and survive on Ascended or Evolved. Official maps and mods ready, set up for you in minutes." software={["ARK: Survival Ascended", "ARK: Survival Evolved", "Official maps", "Mods"]} faq={homeFaq} />
  ),
});
