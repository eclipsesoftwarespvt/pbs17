import { createFileRoute, Link } from "@tanstack/react-router";
import { BadgeCheck, Gauge, Globe2, HeartHandshake, Lock, ShieldCheck, Sparkles, Timer } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { ClosingBanner, FeatureCard, PageHero, SectionHead } from "@/components/sections/common";
import { CpuLineup, HardwareFloor } from "@/components/sections/hardware";
import { flagFor, img } from "@/config/images";
import { publicLocations } from "@/config/settings";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";
import { absoluteUrl, breadcrumbLd, ORG_ID, pageHead } from "@/lib/seo";

const title = "About PlexScale | AMD EPYC Game & VPS Hosting";
const desc = "PlexScale runs game servers, VPS and Discord bots on enterprise AMD EPYC 7000 and 9000 series hardware, with its own Plexus VPS panel and real human support.";

export const Route = createFileRoute("/about")({
  head: () => pageHead({ path: "/about", title, description: desc, image: "/og/about.jpg", imageAlt: "Server racks behind the PlexScale team", jsonLd: [{ "@type": "AboutPage", name: title, url: absoluteUrl("/about"), about: { "@id": ORG_ID } }, breadcrumbLd([{ name: "About", path: "/about" }])] }),
  component: About,
});

const values = [
  { icon: <Lock />, t: "No overselling", b: "Every plan gets the memory it pays for. We would rather tell you a node is full than squeeze in one more server and slow everyone down." },
  { icon: <BadgeCheck />, t: "Honest pricing", b: "The price you see is the price you pay, tax included. Nothing renews behind your back, and reminders land well before anything expires." },
  { icon: <HeartHandshake />, t: "People, not scripts", b: "Tickets, Discord and email are answered by a team that runs game servers too. No copy-paste replies, no bots pretending to be people." },
  { icon: <Sparkles />, t: "Built in-house", b: "Our Plexus VPS panel is designed and built by the PlexScale team, with a live console, OS rebuilds and firewalls right in your browser." },
];

const milestones = [
  { when: "February 2026", t: "PlexScale opens", b: "Our first Minecraft servers go live on tuned AMD EPYC nodes." },
  { when: "2026", t: "More games, more places", b: "Hytale, Counter Strike 2, Rust, VPS and bot hosting join, across five locations in four countries." },
  { when: "Today", t: "EPYC 9000 series and Plexus", b: "Newer AMD EPYC 9V74 nodes with DDR5 memory join the fleet, alongside our own VPS panel and a built-in ticket system." },
];

const leaders = [
  { name: "Prateek J.", role: "Founder & CEO", b: "Sets the direction and keeps the infrastructure honest." },
  { name: "Shashank M.", role: "Co-Founder & Director", b: "Runs operations, partners and the day-to-day of the company." },
  { name: "Ayaan R.", role: "Marketing Lead", b: "Looks after the community and how people hear about us." },
];

const initials = (n: string) => n.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

function About() {
  const s = useSettings();
  const locations = publicLocations(s.locations);
  const countries = new Set(locations.map((l) => l.region)).size;
  const stats = [
    { icon: Timer, k: "99.95%*", v: "uptime target" },
    { icon: Globe2, k: String(locations.length), v: "locations" },
    { icon: Gauge, k: "3.70 GHz", v: "AMD EPYC 9V74" },
    { icon: ShieldCheck, k: "480 Gbps", v: "DDoS mitigation" },
  ];
  const glance: [string, string][] = [
    ["Company", site.legalName],
    ["Founded", "February 2026"],
    ["Hardware", "AMD EPYC 7000 and 9000 series"],
    ["Network", `${locations.length} locations in ${countries} countries`],
    ["Support", "Tickets, Discord and email"],
    ["Email", s.supportEmail],
  ];
  return (
    <>
      <PageHero title="Hosting made by players, for players" sub="We started PlexScale because good servers should not cost a fortune. So we put enterprise AMD EPYC hardware behind every plan, kept prices fair and made sure a real person always replies." image={img.racks} imageAlt="Server racks in a PlexScale data centre">
        <Link to="/" hash="locations" className={btn({ size: "lg" })}>See our locations</Link>
        <Link to="/contact" className={btn({ size: "lg", variant: "glass" })}>Talk to us</Link>
      </PageHero>

      <section className="container-px pt-10 md:pt-14">
        <ul className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-steel bg-steel md:grid-cols-4">
          {stats.map(({ icon: Icon, k, v }) => (
            <li key={v} className="flex flex-col items-start gap-3 bg-graphite p-5 sm:flex-row sm:items-center sm:gap-4 md:p-6">
              <span className="icon-well shrink-0"><Icon /></span>
              <div><p className="font-display text-xl font-bold">{k}</p><p className="text-sm text-muted-foreground">{v}</p></div>
            </li>
          ))}
        </ul>
      </section>

      <section className="section container-px grid gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-7">
          <SectionHead eyebrow="Our story" title="Fast servers should not be a luxury" />
          <div className="mt-6 space-y-5 text-muted-foreground md:text-lg md:leading-relaxed">
            <p>Too many hosts sell old hardware at premium prices, then leave you waiting days for a reply. We wanted the opposite, so we built it ourselves.</p>
            <p>Every PlexScale server runs on AMD EPYC, the processors big cloud platforms trust, with NVMe Gen 4 storage. Game servers are set up the moment you pay, and VPS customers get Plexus, a panel we built from scratch.</p>
            <p>And if something breaks, you talk to a real person through a ticket on the site, Discord or email.</p>
          </div>
        </div>
        <aside className="lg:col-span-5">
          <div className="panel p-7 md:p-8">
            <h3 className="text-lg font-semibold">PlexScale at a glance</h3>
            <dl className="mt-4 divide-y divide-steel text-sm">
              {glance.map(([k, v]) => (
                <div key={k} className="grid grid-cols-5 gap-3 py-3.5"><dt className="col-span-2 text-muted-foreground">{k}</dt><dd className="col-span-3 break-words font-medium">{v}</dd></div>
              ))}
            </dl>
          </div>
        </aside>
      </section>

      <section className="band section">
        <div className="container-px">
          <SectionHead eyebrow="Hardware" title="The hardware behind every plan" sub="Three generations of server-grade AMD EPYC, from the proven 7000 series to the new EPYC 9V74 with DDR5 memory." />
          <CpuLineup className="mt-10" />
          <HardwareFloor className="mt-6" />
        </div>
      </section>

      <section className="section container-px">
        <SectionHead eyebrow="Values" title="Four promises we keep" sub="Simple rules we run the company by. If we ever break one, tell us." />
        <div className="mt-10 grid gap-5 sm:grid-cols-2">
          {values.map((v) => <FeatureCard key={v.t} icon={v.icon} title={v.t} body={v.b} className="p-8" />)}
        </div>
      </section>

      <section className="section container-px">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <SectionHead eyebrow="Timeline" title="How we got here" sub="Young, focused and growing with the communities that host with us." />
          </div>
          <ol className="relative border-l border-steel pl-8 lg:col-span-7">
            {milestones.map((m) => (
              <li key={m.t} className="relative pb-12 last:pb-0">
                <span className="absolute -left-[41px] top-1 size-4 rounded-full border-[3px] border-azure bg-ink" />
                <p className="text-sm font-semibold text-azure">{m.when}</p>
                <h3 className="mt-1 text-xl font-semibold">{m.t}</h3>
                <p className="mt-2 text-muted-foreground">{m.b}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="band section">
        <div className="container-px">
        <SectionHead eyebrow="Locations" title="Close to your players" sub="Pick the location nearest your community when you deploy." />
        <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {locations.map((l) => (
            <li key={l.id} className="panel flex items-center gap-3 p-5">
              {flagFor(l.country) && <img src={flagFor(l.country)} alt="" referrerPolicy="no-referrer" width={32} height={16} loading="lazy" className="h-4 w-8 shrink-0 rounded-sm object-cover ring-1 ring-steel" />}
              <div><p className="font-semibold">{l.city}</p><p className="text-xs text-muted-foreground">{l.region}</p></div>
            </li>
          ))}
        </ul>
        </div>
      </section>

      <section className="section container-px">
        <SectionHead eyebrow="Team" title="The people behind PlexScale" />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {leaders.map((p) => (
            <article key={p.name} className="panel flex flex-col p-8">
              <span className="grid size-14 place-items-center rounded-full bg-azure-deep font-display text-base font-bold text-azure">{initials(p.name)}</span>
              <h3 className="mt-6 text-xl font-semibold">{p.name}</h3>
              <p className="mt-1 text-sm text-azure">{p.role}</p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.b}</p>
            </article>
          ))}
        </div>
      </section>

      <ClosingBanner title="Got a question for the team?" sub={`${site.responseTime}. Open a ticket on the site or find us on Discord, we are happy to talk.`} />
    </>
  );
}
