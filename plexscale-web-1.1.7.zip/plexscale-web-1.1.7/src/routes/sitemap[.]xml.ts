import { createFileRoute } from "@tanstack/react-router";
import { sitemapXml } from "@/lib/seo";

// Canonical public pages only (src/lib/seo.ts). Absolute URLs come from SITE_URL, never the Host header.
export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: () => new Response(sitemapXml(), { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=3600" } }),
    },
  },
});
