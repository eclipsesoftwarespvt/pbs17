import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BadgeCheck, Check, HeartHandshake, Lock, Rocket, Server, Settings2, ShieldCheck } from "lucide-react";
import type { PointerEvent } from "react";
import { btn } from "@/components/ui-px/btn";
import { ClosingBanner, FaqSection, FeatureCard, SectionHead, SupportCards } from "@/components/sections/common";
import { Hardware } from "@/components/sections/hardware";
import { LocationsSection } from "@/components/sections/locations";
import { ServerStack } from "@/components/sections/ServerStack";
import { homeFaq } from "@/config/faq";
import { PanelSlider } from "@/components/sections/PanelSlider";
import { LandingPreloader } from "@/components/layout/LandingPreloader";
import { TrustpilotLink, TrustpilotStars } from "@/components/layout/Trustpilot";
import { img, partnerLogoSize, partners } from "@/config/images";
import { products } from "@/config/products";
import { isComingSoon } from "@/config/settings";
import { SoonTag } from "@/components/ui-px/ComingSoon";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";
import { effectivePlans, formatINR, fromPrice } from "@/config/plans";
import { organizationLd, pageHead, websiteLd } from "@/lib/seo";

export const Route = createFileRoute("/")({
  head: () => pageHead({
    path: "/",
    title: "PlexScale: AMD EPYC Game Servers, VPS & Bot Hosting",
    description: "Minecraft, Rust, CS2 and Hytale servers, VPS and Discord bot hosting on AMD EPYC 9V74 and 7763 with DDR5 memory and NVMe Gen 4 storage.",
    image: "/og/home.jpg",
    imageAlt: "PlexScale game servers, VPS and bot hosting on AMD EPYC",
    jsonLd: [organizationLd(), websiteLd()],
  }),
  component: Home,
});

function Hero() {
  const s = useSettings();
  return (
    <section className="relative overflow-hidden border-b border-steel">
      <div className="container-px grid items-center gap-8 pb-10 pt-10 md:pt-14 lg:grid-cols-12 lg:gap-6 lg:pb-12">
        <div className="animate-rise lg:col-span-7">
          <TrustpilotLink className="inline-flex items-center gap-2.5 rounded-full border border-steel bg-graphite py-1.5 pl-2 pr-3.5 text-sm transition-colors hover:border-trustpilot/60">
            <TrustpilotStars size="sm" />
            <span className="font-semibold text-foreground">Great</span>
            <span className="text-muted-foreground">{site.trustpilotScore}/5 on Trustpilot</span>
          </TrustpilotLink>
          <h1 className="mt-6 text-[38px] leading-[1.06] md:text-[52px] xl:text-[58px]">Game servers, VPS and bots on <span className="text-azure-bright">AMD EPYC</span>.</h1>
          <p className="measure mt-5 text-lg text-muted-foreground md:leading-relaxed">DDR5 memory and NVMe Gen 4 SSDs, the hardware big companies keep to themselves, priced for everyone else.</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/deploy" className={btn({ size: "lg" })}>Deploy a server</Link>
            <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg", variant: "glass" })}>Join our Discord</a>
          </div>
          <ul className="mt-7 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            {["Live in about a minute", "DDoS protection up to 480 Gbps", "Replies in about 60 seconds"].map((t) => (
              <li key={t} className="flex items-center gap-2"><Check className="size-4 text-azure-bright" />{t}</li>
            ))}
          </ul>
        </div>
        <div className="animate-rise [animation-delay:80ms] lg:col-span-5">
          <ServerStack priority />
        </div>
      </div>
      <Partners />
    </section>
  );
}

function Partners() {
  return (
    <div className="border-t border-steel">
      <div className="container-px py-8">
        <p className="text-center text-sm text-muted-foreground">Runs on and is protected by technology the industry trusts</p>
        <ul className="mx-auto mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-6 xl:gap-x-14">
          {partners.map((p) => {
            const size = partnerLogoSize(p.ratio, 2400, 30);
            return (
              <li key={p.name} className="flex h-9 shrink-0 items-center justify-center">
                <img src={p.src} alt={p.name} loading="lazy" width={size.width} height={size.height} style={size} className="partner-logo" />
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

/** Tracks the pointer so the card's blue edge light follows it. */
function trackGlint(e: PointerEvent<HTMLElement>) {
  const r = e.currentTarget.getBoundingClientRect();
  e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
  e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
  const body = e.currentTarget.querySelector<HTMLElement>(".glint-body");
  if (body) e.currentTarget.style.setProperty("--body-top", `${body.offsetTop}px`);
}

function Games() {
  const s = useSettings();
  return (
    <section className="section container-px">
      <SectionHead title="Pick your game" sub="Minecraft, Hytale, Counter Strike 2, Rust, Palworld, ARK, Garry's Mod, VPS and Discord bots. Every plan runs on AMD EPYC with NVMe storage and DDoS protection." />
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <Link key={p.key} to={p.to} onPointerMove={trackGlint} className="glint-card group flex flex-col">
            <div className="relative aspect-[16/7] overflow-hidden border-b border-steel bg-surface">
              <img src={p.image} alt={`${p.name} artwork`} loading="lazy" width={1280} height={720} className="h-full w-full object-cover" />
              {isComingSoon(s, p.key) && <SoonTag className="absolute left-3 top-3 bg-ink/90" />}
            </div>
            <div className="glint-body flex flex-1 flex-col p-5">
              <h3 className="text-lg font-bold">{p.name}</h3>
              <p className="mt-1 flex-1 text-sm leading-relaxed text-muted-foreground">{p.blurb}</p>
              <div className="mt-4 flex items-end justify-between gap-3">
                {isComingSoon(s, p.key)
                  ? <p className="text-sm text-muted-foreground">Launching soon</p>
                  : <p className="text-sm text-muted-foreground">from <span className="font-display text-xl font-bold text-foreground">{formatINR(fromPrice(effectivePlans(p.key, s.plans)))}</span>/mo</p>}
                <span className="inline-flex items-center gap-1 font-display text-sm font-semibold text-azure-bright">{isComingSoon(s, p.key) ? "Take a look" : "View plans"} <ArrowRight className="glint-arrow size-4" /></span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}

function Steps() {
  const steps = [
    { n: "01", icon: <Server />, t: "Choose a plan", b: "Pick your game, the memory you need and the location closest to your players. Prices are upfront, tax included." },
    { n: "02", icon: <Settings2 />, t: "Pick your setup", b: "Choose your software or modpack and we install it for you. Nothing to configure by hand." },
    { n: "03", icon: <Rocket />, t: "Start playing", b: "Your server is online in about a minute. Share the IP and jump in with your friends." },
  ];
  return (
    <section className="container-px pb-12 md:pb-[72px]">
      <div className="panel grid overflow-hidden md:grid-cols-[1.1fr_repeat(3,1fr)]">
        <div className="border-b border-steel p-5 md:border-b-0 md:border-r">
          <h2 className="text-2xl md:text-[26px]">Online in about a minute</h2>
          <p className="mt-2 text-sm text-muted-foreground">No setup calls and no waiting on emails. Three steps and you are in.</p>
        </div>
        {steps.map((s, i) => (
          <div key={s.n} className={`p-5 ${i < steps.length - 1 ? "border-b border-steel md:border-b-0 md:border-r" : ""}`}>
            <div className="flex items-center justify-between"><span className="icon-well">{s.icon}</span><span className="font-display text-sm font-semibold tabular-nums text-muted-foreground">{s.n}</span></div>
            <h3 className="mt-4 text-base font-semibold">{s.t}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{s.b}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function WhyPlexScale() {
  const items = [
    { icon: <ShieldCheck />, t: "Online when it counts", b: "A filtered network and redundant power keep you reachable on raid night or ranked finals. Our SLA puts it in writing." },
    { icon: <Lock />, t: "No noisy neighbours", b: "The memory in your plan is reserved for you. We never cram extra servers onto a node." },
    { icon: <HeartHandshake />, t: "Humans who play", b: "Crashing modpack or plugin conflict? Talk to someone who knows what a tick rate is, by ticket, Discord or email. Replies average about a minute." },
    { icon: <BadgeCheck />, t: "Fair, clear pricing", b: "Enterprise hardware without the enterprise budget. Prices are upfront and nothing renews behind your back." },
  ];
  return (
    <section className="band section">
      <div className="container-px">
        <SectionHead title="Why people stick with us" sub="Running servers since February 2026. These are the things we never cut corners on." />
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((it) => <FeatureCard key={it.t} icon={it.icon} title={it.t} body={it.b} />)}
        </div>
      </div>
    </section>
  );
}

function TrustStats() {
  const stats = [
    { value: "80+", label: "Active clients" },
    { value: "250+", label: "Servers hosted" },
    { value: `${site.trustpilotScore}/5`, label: "Rated on Trustpilot", stars: true },
    { value: "60s", label: "Average reply time" },
  ];
  return (
    <section className="section container-px">
      <div className="panel relative isolate grid items-center gap-6 overflow-hidden p-6 md:grid-cols-[auto_1fr] md:gap-10 md:p-8">
        <img src={img.trustShield} alt="Blue shield with a check mark wrapped in a ribbon" width={474} height={560} loading="lazy" className="mx-auto h-[120px] w-auto md:h-[168px]" />
        <div>
          <h2 className="text-2xl md:text-[30px]">Players stay, and the numbers show it</h2>
          <p className="mt-2 text-sm text-muted-foreground md:text-base">Running servers since February 2026, with every review public on Trustpilot.</p>
          <dl className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-steel bg-steel lg:grid-cols-4">
            {stats.map((st) => (
              <div key={st.label} className="flex flex-col-reverse justify-end bg-graphite p-4">
                <dt className="mt-1 text-xs text-muted-foreground md:text-sm">{st.label}</dt>
                <dd className="flex flex-wrap items-center gap-x-3 gap-y-1.5 font-display text-2xl font-bold tabular-nums md:text-3xl">{st.value}{st.stars && <TrustpilotStars size="sm" className="origin-left scale-[.82] sm:scale-100" />}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}

function Home() {
  return (
    <>
      <LandingPreloader />
      <Hero />
      <Games />
      <Steps />
      <Hardware />
      <TrustStats />
      <WhyPlexScale />
      <LocationsSection />
      <div className="band"><PanelSlider /></div>
      <SupportCards />
      <FaqSection items={homeFaq} />
      <ClosingBanner title="Try AMD EPYC for yourself" sub="Pick a plan, choose your game and you are playing in about a minute. If anything feels off, we are one message away." />
    </>
  );
}
