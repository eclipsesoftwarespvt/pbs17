import { createFileRoute } from "@tanstack/react-router";
import { robotsTxt } from "@/lib/seo";

// Served from code (not public/robots.txt) so the Sitemap line is built from SITE_URL.
export const Route = createFileRoute("/robots.txt")({
  server: {
    handlers: {
      GET: () => new Response(robotsTxt(), { headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "public, max-age=3600" } }),
    },
  },
});
