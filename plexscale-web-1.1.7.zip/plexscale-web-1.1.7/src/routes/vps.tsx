import { createFileRoute } from "@tanstack/react-router";
import { Boxes, Database, Globe, KeyRound, ServerCog, Workflow } from "lucide-react";
import { ClosingBanner, FaqSection, PageHero, SectionHead } from "@/components/sections/common";
import { DeployCta, SoonBadge } from "@/components/ui-px/ComingSoon";
import { PlanGrid } from "@/components/sections/pricing";
import { Hardware } from "@/components/sections/hardware";
import { img } from "@/config/images";
import { useSettings } from "@/hooks/use-settings";
import { locationsForProduct, publicLocations, visibleVpsOs } from "@/config/settings";
import { vpsPlans } from "@/config/plans";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/vps")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "vps");
    const from = fromLabel(plans);
    const title = `AMD EPYC VPS Hosting from ${from}/mo | PlexScale`;
    const description = `KVM VPS from ${from} a month with full root access, AMD EPYC 9V74 and 7763 CPUs, NVMe Gen 4 storage and DDoS protection. GST included.`;
    return pageHead({
      path: "/vps", title, description, image: "/og/vps.jpg", imageAlt: "PlexScale VPS hosting on AMD EPYC",
      jsonLd: [...hostingLd({ path: "/vps", name: "PlexScale VPS hosting", serviceType: "VPS hosting", description, image: "/og/vps.jpg", plans }), breadcrumbLd([{ name: "VPS hosting", path: "/vps" }])],
    });
  },
  component: Vps,
});

const uses = [
  { icon: <Globe />, t: "Websites and APIs", b: "Host apps, dashboards and APIs close to your users." },
  { icon: <ServerCog />, t: "Custom game servers", b: "Run any game or tool that needs full root control." },
  { icon: <Database />, t: "Databases", b: "Postgres, MySQL or Redis on fast NVMe storage." },
  { icon: <Workflow />, t: "CI and automation", b: "Build runners, cron jobs and background workers." },
  { icon: <Boxes />, t: "Docker stacks", b: "Spin up containers with Compose in minutes." },
  { icon: <KeyRound />, t: "Private VPN", b: "Your own WireGuard tunnel with a dedicated IP." },
];

const osMarks = {
  ubuntu: (
    <svg viewBox="0 0 48 48" className="size-14" aria-hidden><circle cx="24" cy="24" r="22" className="fill-azure/15 stroke-azure" strokeWidth="2" /><circle cx="24" cy="24" r="9" fill="none" className="stroke-azure" strokeWidth="4" /><circle cx="35" cy="24" r="4" className="fill-azure" /><circle cx="18.5" cy="14.5" r="4" className="fill-azure" /><circle cx="18.5" cy="33.5" r="4" className="fill-azure" /></svg>
  ),
  debian: (
    <svg viewBox="0 0 48 48" className="size-14" aria-hidden><circle cx="24" cy="24" r="22" className="fill-azure/15 stroke-azure" strokeWidth="2" /><path d="M30 33a11 11 0 1 1 4-12c1 4-1 8-5 9s-7-2-6-5 4-3 5-1" fill="none" className="stroke-azure" strokeWidth="3.5" strokeLinecap="round" /></svg>
  ),
};

function OsSupport() {
  const all = visibleVpsOs(useSettings());
  const groups = [...new Set(all.map((o) => `${o.family}|${o.name}`))].map((g) => {
    const [family, name] = g.split("|") as [keyof typeof osMarks | "other", string];
    return { name, mark: family === "other" ? osMarks.ubuntu : osMarks[family], versions: all.filter((o) => `${o.family}|${o.name}` === g).map((o) => o.version) };
  });
  const osList = groups;
  return (
    <section className="section container-px pt-0">
      <SectionHead eyebrow="Operating systems" title="Ubuntu and Debian, ready to install" />
      <div className="mt-10 grid gap-5 sm:grid-cols-2">
        {osList.map((o) => (
          <div key={o.name} className="panel flex items-center gap-6 p-6">
            {o.mark}
            <div>
              <h3 className="text-xl font-semibold">{o.name}</h3>
              <div className="mt-3 flex flex-wrap gap-2">{o.versions.map((v) => <span key={v} className="rounded-md border border-steel bg-surface px-2 py-0.5 text-xs font-medium text-muted-foreground">{v}</span>)}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Vps() {
  const locations = publicLocations(locationsForProduct(useSettings(), "vps"));
  return (
    <>
      <PageHero badge={<SoonBadge product="vps" />} eyebrow="VPS hosting" title="Root access on real EPYC power" sub="KVM virtual servers with dedicated memory, NVMe Gen 4 storage and a 10 Gbps+ uplink." image={img.vps} imageAlt="PlexScale VPS hosting">
        <DeployCta product="vps" />
      </PageHero>
      <PlanGrid plans={vpsPlans} kind="vps" title="VPS plans" features={["Full root access", "DDoS protection, up to 480 Gbps"]} />
      <OsSupport />
      <Hardware />
      <section className="section container-px">
        <SectionHead eyebrow="Use cases" title="Built for whatever you run" />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {uses.map((u) => (
            <div key={u.t} className="panel p-6"><span className="icon-well">{u.icon}</span><h3 className="mt-5 text-lg font-semibold">{u.t}</h3><p className="mt-1.5 text-[15px] text-muted-foreground">{u.b}</p></div>
          ))}
        </div>
      </section>
      <FaqSection items={[
        { q: "Do I get root access?", a: "Yes. Every VPS comes with full root access." },
        { q: "Can I get a refund on a VPS?", a: "No. Refunds are available only for eligible new game-hosting orders, within 24 hours of payment. Renewals are not refundable." },
        { q: "Do plans renew automatically?", a: "No. We send reminder emails before your VPS is due." },
        { q: "Which locations offer VPS?", a: locations.map((l) => `${l.city}, ${l.region}`).join(" · ") },
      ]} />
      <ClosingBanner />
    </>
  );
}
