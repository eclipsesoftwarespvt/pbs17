import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/counter-strike-2")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "cs2");
    const from = fromLabel(plans);
    const title = "Counter Strike 2 Server Hosting on AMD EPYC | PlexScale";
    const description = `CS2 servers from ${from} a month on AMD EPYC 9V74 and 7763 in Mumbai, Hyderabad, Dubai, Frankfurt and Virginia. Competitive, Wingman, Deathmatch and Arms Race with SourceTV. GST included.`;
    return pageHead({
      path: "/counter-strike-2", title, description, image: "/og/counter-strike-2.jpg", imageAlt: "Counter Strike 2 server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/counter-strike-2", name: "PlexScale Counter Strike 2 server hosting", serviceType: "Game server hosting", description, image: "/og/counter-strike-2.jpg", plans }), breadcrumbLd([{ name: "Counter Strike 2 server hosting", path: "/counter-strike-2" }])],
    });
  },
  component: () => (
    <GamePage game="cs2" name="Counter Strike 2" image={img.cs2} sub="Low latency CS2 servers for scrims, practice and community nights, with SourceTV for demos and casting." software={["Competitive","Wingman","Deathmatch","Arms Race","CounterStrikeSharp"]} faq={homeFaq} />
  ),
});
