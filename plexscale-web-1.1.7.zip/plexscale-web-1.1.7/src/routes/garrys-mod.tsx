import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/garrys-mod")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "gmod");
    const from = fromLabel(plans);
    const title = "Garry's Mod Server Hosting on AMD EPYC | PlexScale";
    const description = `Garry's Mod servers from ${from} a month on AMD EPYC 9V74 and 7763 with Sandbox, TTT, Workshop collections and DDoS protection. GST included.`;
    return pageHead({
      path: "/garrys-mod", title, description, image: "/og/gmod.jpg", imageAlt: "Garry's Mod server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/garrys-mod", name: "PlexScale Garry's Mod server hosting", serviceType: "Game server hosting", description, image: "/og/gmod.jpg", plans }), breadcrumbLd([{ name: "Garry's Mod server hosting", path: "/garrys-mod" }])],
    });
  },
  component: () => (
    <GamePage game="gmod" name="Garry's Mod" image={img.gmod} sub="Sandbox and TTT built in. Add DarkRP or any addon through a Workshop collection on fast EPYC hardware." software={["Garry's Mod server", "Sandbox and TTT", "Workshop collections"]} faq={homeFaq} />
  ),
});
