import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/rust")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "rust");
    const from = fromLabel(plans);
    const title = "Rust Server Hosting on AMD EPYC | PlexScale";
    const description = `Rust servers from ${from} a month on AMD EPYC 9V74 and 7763 with NVMe storage, Oxide or Carbon plugins and DDoS protection. GST included.`;
    return pageHead({
      path: "/rust", title, description, image: "/og/rust.jpg", imageAlt: "Rust server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/rust", name: "PlexScale Rust server hosting", serviceType: "Game server hosting", description, image: "/og/rust.jpg", plans }), breadcrumbLd([{ name: "Rust server hosting", path: "/rust" }])],
    });
  },
  component: () => (
    <GamePage game="rust" name="Rust" image={img.rust} sub="Survive, build and raid with your clan. Vanilla, Oxide or Carbon, updated on every restart." software={["Rust dedicated server", "Oxide and Carbon", "Procedural maps"]} faq={homeFaq} />
  ),
});
