import { createFileRoute } from "@tanstack/react-router";
import { ClosingBanner, FaqSection, PageHero, SectionHead } from "@/components/sections/common";
import { DeployCta, SoonBadge } from "@/components/ui-px/ComingSoon";
import { PlanGrid } from "@/components/sections/pricing";
import { img } from "@/config/images";
import { botPlans } from "@/config/plans";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/bot-hosting")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "bot");
    const from = fromLabel(plans);
    const title = `Discord Bot Hosting from ${from}/mo | PlexScale`;
    const description = `Host Node.js and Python Discord bots from ${from} a month on AMD EPYC with NVMe storage. Always online, live console, GST included.`;
    return pageHead({
      path: "/bot-hosting", title, description, image: "/og/bot-hosting.jpg", imageAlt: "PlexScale Discord bot hosting",
      jsonLd: [...hostingLd({ path: "/bot-hosting", name: "PlexScale Discord bot hosting", serviceType: "Discord bot hosting", description, image: "/og/bot-hosting.jpg", plans }), breadcrumbLd([{ name: "Discord bot hosting", path: "/bot-hosting" }])],
    });
  },
  component: Bot,
});

const runtimes = [
  { t: "Node.js", b: "discord.js, Eris and friends. Install packages from package.json, set your start file and go." },
  { t: "Python", b: "discord.py, nextcord, py-cord. Dependencies install from requirements.txt on start." },
];

function Bot() {
  return (
    <>
      <PageHero badge={<SoonBadge product="bot" />} eyebrow="Discord bot hosting" title="Your bot, online around the clock" sub="Upload your code, set your token and let it run. Node.js and Python supported out of the box." image={img.bot} imageAlt="Discord bot hosting artwork">
        <DeployCta product="bot" />
      </PageHero>
      <PlanGrid plans={botPlans} kind="bot" title="Bot plans" features={["Node.js and Python", "Live console and file manager", "DDoS protection, up to 480 Gbps"]} />
      <section className="section container-px">
        <SectionHead eyebrow="Runtimes" title="Node.js and Python, ready" />
        <div className="mt-10 grid gap-5 md:grid-cols-2">
          {runtimes.map((r) => (
            <div key={r.t} className="panel p-7 md:p-8">
              <h3 className="text-xl font-semibold">{r.t}</h3>
              <p className="mt-2 text-muted-foreground">{r.b}</p>
            </div>
          ))}
        </div>
      </section>
      <FaqSection items={[
        { q: "Where do I put my bot token?", a: "Add it as an environment variable in the panel so it never sits in your code." },
        { q: "Can I get a refund on bot hosting?", a: "No. Refunds are available only for eligible new game-hosting orders, within 24 hours of payment. Renewals are not refundable." },
        { q: "Will my bot restart if it crashes?", a: "Yes. The panel can restart it automatically." },
        { q: "Do plans renew automatically?", a: "No. We send reminder emails before your plan is due." },
      ]} />
      <ClosingBanner />
    </>
  );
}
