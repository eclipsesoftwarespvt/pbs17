import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Button } from "@/components/ui/button";

import "@fontsource-variable/sora";
import "@fontsource-variable/figtree";
import appCss from "../styles.css?url";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ConfirmHost } from "@/components/ui-px/ConfirmHost";
import { NotFound } from "@/components/layout/NotFound";
import { StatusPage } from "@/components/layout/StatusPage";
import { btn } from "@/components/ui-px/btn";
import { Toaster } from "@/components/ui/sonner";
import { Announcement } from "@/components/layout/Announcement";
import { supabase } from "@/integrations/supabase/client";
import { settingsQuery } from "@/lib/settings.functions";
import { ensureWelcome } from "@/lib/orders.functions";
import { MaintenanceScreen } from "@/components/layout/Maintenance";
import { useSettings } from "@/hooks/use-settings";
import { useIsAdmin, useUser } from "@/hooks/use-session";
import { installClientGuard } from "@/lib/client-guard";

function ErrorComponent({ reset }: ErrorComponentProps) {
  const router = useRouter();

  return (
    <StatusPage
      code="500"
      chip="Something went wrong"
      tone="bad"
      title="This page didn’t load"
      body="We hit a problem loading this page. Your account and services are unchanged. Please try again in a moment."
      showLinks={false}
      fullscreen
      actions={<>
        <Button size="lg" onClick={() => { router.invalidate(); reset(); }}>Try again</Button>
        <Link to="/" className={btn({ size: "lg", variant: "glass" })}>Return home</Link>
      </>}
    />
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "PlexScale: AMD EPYC Game Servers, VPS & Bot Hosting" },
      { name: "description", content: "Game servers, VPS and Discord bot hosting on AMD EPYC 9V74 and 7763 with DDR5 memory and NVMe Gen 4 storage." },
      { property: "og:title", content: "PlexScale: AMD EPYC Game Servers, VPS & Bot Hosting" },
      { property: "og:description", content: "Enterprise AMD EPYC hardware, NVMe storage and a team that replies in minutes." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "PlexScale" },
      { property: "og:locale", content: "en_IN" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "theme-color", content: "#0a0b0f" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", type: "image/png", sizes: "32x32", href: "/favicon-32.png" },
      { rel: "icon", type: "image/png", sizes: "192x192", href: "/favicon.png" },
      { rel: "apple-touch-icon", sizes: "180x180", href: "/apple-touch-icon.png" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(settingsQuery),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFound,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const path = useRouterState({ select: (st) => st.location.pathname });
  const onAuth = path === "/auth" || path.startsWith("/auth/");
  const hideFooter = onAuth || path.startsWith("/administrator");
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  useEffect(() => { installClientGuard(); }, []);
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    try {
      const { data } = supabase.auth.onAuthStateChange((event, session) => {
        if (event === "SIGNED_IN" && session?.user) {
          // Welcome email: the server sends it at most once, only for brand new accounts.
          const key = `px-welcome-${session.user.id}`;
          if (!sessionStorage.getItem(key)) {
            sessionStorage.setItem(key, "1");
            void ensureWelcome().catch(() => sessionStorage.removeItem(key));
          }
        }
        if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
        router.invalidate();
        if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
      });
      unsubscribe = () => data.subscription.unsubscribe();
    } catch {
      // Public pages remain available if authentication is not configured.
    }
    return () => unsubscribe?.();
  }, [router, queryClient]);
  return (
    <QueryClientProvider client={queryClient}>
      <MaintenanceGate>
        <div className="flex min-h-screen flex-col">
          <Announcement />
          {!onAuth && <Navbar />}
          <main className="flex-1">
            {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
            <Outlet />
          </main>
          {hideFooter ? <p className="py-6 text-center text-xs text-muted-foreground">© PlexScale. All Rights Reserved.</p> : <Footer />}
        </div>
      </MaintenanceGate>
      <Toaster />
      <ConfirmHost />
    </QueryClientProvider>
  );
}

/** Locks every page for visitors and customers while maintenance is on. Only administrators get through. */
function MaintenanceGate({ children }: { children: ReactNode }) {
  const s = useSettings();
  const path = useRouterState({ select: (st) => st.location.pathname });
  const { user, ready } = useUser();
  const isAdmin = useIsAdmin(user?.id);
  if (!s.maintenance.enabled) return <>{children}</>;
  if (path === "/auth" || path.startsWith("/auth/")) return <>{children}</>;
  if (isAdmin) return <>{children}</>;
  return <MaintenanceScreen checking={!ready} />;
}
