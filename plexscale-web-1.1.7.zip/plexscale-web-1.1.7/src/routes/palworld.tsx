import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/palworld")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "palworld");
    const from = fromLabel(plans);
    const title = "Palworld Server Hosting on AMD EPYC | PlexScale";
    const description = `Palworld servers from ${from} a month on AMD EPYC 9V74 and 7763 with NVMe storage, Steam, Xbox, PS5 and Mac crossplay and DDoS protection. GST included.`;
    return pageHead({
      path: "/palworld", title, description, image: "/og/palworld.jpg", imageAlt: "Palworld server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/palworld", name: "PlexScale Palworld server hosting", serviceType: "Game server hosting", description, image: "/og/palworld.jpg", plans }), breadcrumbLd([{ name: "Palworld server hosting", path: "/palworld" }])],
    });
  },
  component: () => (
    <GamePage game="palworld" name="Palworld" image={img.palworld} sub="Catch, build and battle with up to 32 friends on a world that stays online when you log off." software={["Palworld dedicated server", "Crossplay", "World settings", "Save transfers"]} faq={homeFaq} />
  ),
});
