import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { LogOut, ReceiptText, UserRound } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { btn } from "@/components/ui-px/btn";
import { inputCls } from "@/components/ui-px/form";
import { PageHeader, SectionTitle } from "@/components/ui-px/page";
import { useSignOut } from "@/hooks/use-session";
import { PageLoader } from "@/components/ui-px/Spinner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({ meta: [
    { title: "Account | PlexScale" },
    { name: "description", content: "Your PlexScale profile, billing details and connected logins." },
    { property: "og:title", content: "Account | PlexScale" },
    { property: "og:description", content: "Profile, billing details and connected logins." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Account,
});

const fields = [
  ["display_name", "Display name"],
  ["billing_name", "Billing name"],
  ["billing_phone", "Phone"],
  ["billing_address", "Billing address"],
  ["gstin", "GSTIN (optional)"],
] as const;
type Form = Record<(typeof fields)[number][0], string>;

function Account() {
  const qc = useQueryClient();
  const signOut = useSignOut();
  const { data } = useQuery({
    queryKey: ["account"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return { user: null, profile: null };
      const { data: p } = await supabase.from("profiles").select("id, avatar_url, display_name, billing_name, billing_phone, billing_address, gstin, created_at").eq("id", u.user.id).maybeSingle();
      return { user: u.user, profile: p };
    },
  });
  const [form, setForm] = useState<Form>({ display_name: "", billing_name: "", billing_phone: "", billing_address: "", gstin: "" });
  useEffect(() => {
    if (data?.profile) setForm({ display_name: data.profile.display_name ?? "", billing_name: data.profile.billing_name ?? "", billing_phone: data.profile.billing_phone ?? "", billing_address: data.profile.billing_address ?? "", gstin: data.profile.gstin ?? "" });
  }, [data?.profile]);

  if (!data) return <PageLoader text="Loading your account" />;
  if (!data.user) return <section className="section container-px"><p className="text-muted-foreground">Sign in to view your account.</p></section>;
  const { user } = data;
  const avatar = data.profile?.avatar_url ?? (user.user_metadata?.['avatar_url'] as string | undefined);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const clean = Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v.trim() || null])) as Record<keyof Form, string | null>;
    const { error } = await supabase.from("profiles").update({ ...clean, updated_at: new Date().toISOString() }).eq("id", user.id);
    if (error) toast.error("Could not save your details."); else { toast.success("Your details are saved"); qc.invalidateQueries({ queryKey: ["account"] }); }
  }

  return (
    <section className="section container-px max-w-3xl">
      <PageHeader title="Your account" description="Your profile, billing details and the logins you sign in with." actions={<Link to="/billing" className={btn({ variant: "secondary" })}><ReceiptText />Billing</Link>} />

      <div className="panel mt-8 flex flex-wrap items-center gap-5 p-6">
        {avatar ? <img src={avatar} alt="" className="size-14 rounded-full ring-2 ring-azure/40" referrerPolicy="no-referrer" /> : <div className="icon-well size-14 rounded-full"><UserRound /></div>}
        <div className="flex-1">
          <p className="font-display text-lg">{form.display_name || user.email}</p>
          <p className="text-sm text-muted-foreground">{user.email} · member since {new Date(user.created_at).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}</p>
        </div>
        <button type="button" onClick={signOut} className={btn({ variant: "secondary" })}><LogOut />Sign out</button>
      </div>

      <form onSubmit={save} className="panel mt-6 grid gap-4 p-6">
        <SectionTitle title="Profile and billing details" description="Used on your invoices. GSTIN is only needed for business purchases." />
        <div className="grid gap-4 sm:grid-cols-2">
          {fields.map(([k, label]) => (
            <label key={k} className={`grid gap-1.5 text-sm ${k === "billing_address" ? "sm:col-span-2" : ""}`}>
              <span className="font-semibold">{label}</span>
              <input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} maxLength={k === "billing_address" ? 300 : 100} className={`${inputCls} h-11`} />
            </label>
          ))}
        </div>
        <button type="submit" className={`${btn()} w-fit`}>Save changes</button>
      </form>

      <div className="panel mt-6 p-6">
        <SectionTitle title="Connected logins" description="You sign in with these. There is no password on your account." />
        <ul className="mt-4 space-y-2">
          {(user.identities ?? []).map((i) => (
            <li key={i.identity_id} className="panel-inset flex items-center justify-between px-4 py-3 text-sm">
              <span className="flex items-center gap-2 font-semibold capitalize"><span className="status-dot status-dot-ok" aria-hidden />{i.provider}</span>
              <span className="text-muted-foreground">{(i.identity_data?.['email'] as string | undefined) ?? "Connected"}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
