import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LifeBuoy, MessageCircle, Plus } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { PageLoader } from "@/components/ui-px/Spinner";
import { EmptyState, PageHeader } from "@/components/ui-px/page";
import { ticketCategories, ticketStatusLabel, ticketStatusTone as statusTone, type TicketStatus } from "@/config/support";
import { useSettings } from "@/hooks/use-settings";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/support/")({
  head: () => ({ meta: [
    { title: "Support tickets | PlexScale" },
    { name: "description", content: "Open and track PlexScale support tickets. Our team replies by email and right here." },
    { property: "og:title", content: "Support tickets | PlexScale" },
    { property: "og:description", content: "Open and track support tickets." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: SupportList,
});

const when = (s: string) => new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

function SupportList() {
  const s = useSettings();
  const { data, isLoading } = useQuery({
    queryKey: ["my-tickets"],
    queryFn: async () => (await supabase.from("support_tickets").select("id, number, subject, category, priority, status, last_message_at, user_last_read_at, created_at").order("last_message_at", { ascending: false }).limit(200)).data ?? [],
    refetchInterval: 30_000,
  });
  return (
    <section className="section container-px max-w-5xl">
      <PageHeader title="Support tickets" description="Private help from our team. You get an email the moment we reply." actions={<>
        <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ variant: "secondary" })}><MessageCircle />Discord</a>
        <Link to="/support/new" className={btn()}><Plus />New ticket</Link>
      </>} />
      {isLoading ? <PageLoader text="Loading your tickets" className="min-h-[30vh]" /> : !data?.length ? (
        <div className="mt-8"><EmptyState icon={LifeBuoy} title="No tickets yet" body="Questions about billing, a server that won’t start or anything else, open a ticket and a real person will help." action={<Link to="/support/new" className={btn({ size: "lg" })}><Plus />Open a ticket</Link>} /></div>
      ) : (
        <ul className="mt-8 space-y-3">
          {data.map((t) => {
            const unread = t.status === "answered" && t.last_message_at > t.user_last_read_at;
            return (
              <li key={t.id}>
                <Link to="/support/$ticketId" params={{ ticketId: t.id }} className="panel card-link group flex flex-wrap items-center justify-between gap-4 p-5">
                  <div className="min-w-0">
                    <p className="flex items-center gap-2 font-display text-lg">
                      {unread && <span className="size-2 shrink-0 rounded-full bg-azure animate-ping-dot" aria-label="New reply" />}
                      <span className="truncate">{t.subject}</span>
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">#{t.number} · {ticketCategories.find((c) => c.key === t.category)?.label ?? t.category} · Updated {when(t.last_message_at)}</p>
                  </div>
                  <span className={cn("rounded-full border px-3 py-1 text-xs font-semibold", statusTone[t.status as TicketStatus])}>{unread ? "New reply" : ticketStatusLabel[t.status as TicketStatus] ?? t.status}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
