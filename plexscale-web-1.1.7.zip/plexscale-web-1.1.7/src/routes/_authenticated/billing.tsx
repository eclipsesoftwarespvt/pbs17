import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowUpCircle, CalendarClock, Download, ExternalLink, Gamepad2, IndianRupee, KeyRound, LifeBuoy, RefreshCw, RotateCcw, Server, TrendingUp, UserRound } from "lucide-react";
import { AccessDialog } from "@/components/billing/AccessDialog";
import { CreditsPanel } from "@/components/billing/CreditsPanel";
import { PayChoice } from "@/components/billing/PayChoice";
import { Badge, EmptyState, PageHeader, SectionTitle, StatCard, type BadgeTone } from "@/components/ui-px/page";
import { textareaCls, tdCls, thCls } from "@/components/ui-px/form";
import { Button } from "@/components/ui/button";
import { useCredits } from "@/hooks/use-credits";
import { useState } from "react";
import { toast } from "sonner";
import { btn } from "@/components/ui-px/btn";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { usePaymentFlow } from "@/components/payment/PaymentFlow";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { billingLabel, effectivePlans, findEffectivePlan, formatINR, isBilling, isGame, periodTotal, productNames, type ProductKey } from "@/config/plans";
import { canUpgradeProduct, isUpgradePath } from "@/config/upgrade-rules";
import { useSettings } from "@/hooks/use-settings";
import { createRenewal, createUpgrade, getInvoicePdf, quoteUpgrade, requestRefund, verifyPayment } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";
import { isOrderRefundEligible } from "@/config/refund-rules";
import { cn } from "@/lib/utils";
import { shownError } from "@/lib/public-error";

export const Route = createFileRoute("/_authenticated/billing")({
  head: () => ({ meta: [
    { title: "Billing | PlexScale" },
    { name: "description", content: "Manage your PlexScale services, renewals, upgrades, invoices and refunds." },
    { property: "og:title", content: "Billing | PlexScale" },
    { property: "og:description", content: "Services, renewals, upgrades and invoices." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Billing,
});

const date = (s: string | null) => (s ? new Date(s).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "-");
const statusLabel: Record<string, string> = { pending: "Awaiting payment", provisioning: "Setting up", active: "Active", suspended: "Suspended", cancelled: "Cancelled", refunded: "Refunded", failed: "Not paid", renewed: "Renewal paid", upgraded: "Upgrade paid", credited: "Credits added" };
const statusTone: Record<string, BadgeTone> = { active: "ok", provisioning: "info", suspended: "bad", pending: "warn" };

type Order = { id: string; kind: string; product: string; plan_id: string; plan_name: string; billing: string; amount: number; paid_at: string | null; status: string; location: string; server_name: string; renews_at: string | null; razorpay_payment_id: string | null; paid_with: string };
type RenewTarget = { order: Order; amount: number | null };

function Billing() {
  const qc = useQueryClient();
  const s = useSettings();
  const locations = s.locations;
  const renew = useServerFn(createRenewal);
  const verify = useServerFn(verifyPayment);
  const refund = useServerFn(requestRefund);
  const invoice = useServerFn(getInvoicePdf);
  const upgrade = useServerFn(createUpgrade);
  const payment = usePaymentFlow();
  const credits = useCredits();
  const { data, isLoading } = useQuery({
    queryKey: ["billing"],
    queryFn: async () => {
      // Always scope to the signed-in customer. Administrators can read every order through RLS,
      // so without this filter an admin's billing page listed other customers' services (and their upgrades failed).
      const { data: auth } = await supabase.auth.getSession();
      const uid = auth.session?.user.id;
      if (!uid) return { orders: [] as Order[], refunds: [] };
      const [o, r] = await Promise.all([
        supabase.from("orders").select("id, kind, product, plan_id, plan_name, billing, amount, paid_at, status, location, server_name, renews_at, razorpay_payment_id, paid_with").eq("user_id", uid).order("created_at", { ascending: false }).limit(500),
        supabase.from("refunds").select("id, order_id, status, created_at").eq("user_id", uid).order("created_at", { ascending: false }),
      ]);
      return { orders: (o.data ?? []) as Order[], refunds: r.data ?? [] };
    },
  });
  const [refundFor, setRefundFor] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [sending, setSending] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [upgradeFor, setUpgradeFor] = useState<Order | null>(null);
  const [accessFor, setAccessFor] = useState<Order | null>(null);
  const [renewFor, setRenewFor] = useState<RenewTarget | null>(null);

  if (isLoading || !data) return <PageLoader text="Loading billing" />;

  const paid = data.orders.filter((o) => o.paid_at);
  const services = data.orders.filter((o) => o.kind === "new" && o.paid_at && !["cancelled", "refunded"].includes(o.status));
  // Spending counts services only; credit top-ups are a balance, so they are not counted twice.
  const spent = paid.filter((o) => o.status !== "refunded" && o.kind !== "credits");
  const totalSpent = spent.reduce((sum, o) => sum + o.amount, 0);
  const yearAgo = Date.now() - 365 * 864e5;
  const yearSpent = spent.filter((o) => o.paid_at && new Date(o.paid_at).getTime() > yearAgo).reduce((sum, o) => sum + o.amount, 0);
  const nextDue = services.filter((o) => o.renews_at).sort((a, b) => (a.renews_at ?? "").localeCompare(b.renews_at ?? ""))[0];
  const refresh = () => { void qc.invalidateQueries({ queryKey: ["billing"] }); void qc.invalidateQueries({ queryKey: ["credits"] }); };

  /** Renewal price shown before paying. The server always recalculates it from the live plan. */
  function renewalEstimate(o: Order): number | null {
    if (!isBilling(o.billing)) return null;
    // Same rule as the server: the live plan price, or the original price when the plan is no longer sold.
    const plan = findEffectivePlan(o.product, o.plan_id, s.plans);
    return plan ? periodTotal(plan.monthly, o.billing) : o.amount;
  }

  async function doRenew(o: Order, useCredits: boolean) {
    const label = o.server_name || o.plan_name;
    setRenewFor(null);
    const { data: u } = await supabase.auth.getUser();
    await payment.run({
      create: () => renew({ data: { orderId: o.id, useCredits } }),
      description: `Renew ${label}`,
      email: u.user?.email,
      verify: (co, r) => verify({ data: { orderId: co.orderId, razorpayOrderId: r.razorpay_order_id, paymentId: r.razorpay_payment_id, signature: r.razorpay_signature } }),
      success: () => { refresh(); return { title: "Renewal confirmed", body: `${label} has been renewed. Thank you for staying with PlexScale.` }; },
    });
  }

  async function sendRefund(e: React.FormEvent) {
    e.preventDefault();
    if (!refundFor) return;
    setSending(true);
    try {
      await refund({ data: { orderId: refundFor, reason } });
      toast.success("Refund request sent"); setRefundFor(null); setReason("");
      refresh();
    } catch { toast.error("Refund request couldn’t be sent. Check that this purchase is eligible and try again."); }
    setSending(false);
  }

  async function download(orderId: string) {
    setDownloading(orderId);
    try {
      const r = await invoice({ data: { orderId } });
      const bytes = Uint8Array.from(atob(r.base64), (c) => c.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
      const a = document.createElement("a");
      a.href = url; a.download = r.filename; a.rel = "noopener";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10_000);
    } catch { toast.error("The invoice couldn’t be downloaded. Please try again."); }
    setDownloading(null);
  }

  return (
    <section className="section container-px">
      <PageHeader
        eyebrow="Billing"
        title="Services and payments"
        description="Renew, upgrade and manage every service, top up credits and download invoices."
        actions={<>
          <a href={s.gamePanelUrl} target="_blank" rel="noopener noreferrer" className={btn({ variant: "secondary" })}><Gamepad2 />Game Panel</a>
          <a href={s.vpsPanelUrl} target="_blank" rel="noopener noreferrer" className={btn({ variant: "secondary" })}><Server />VPS Panel</a>
          <Link to="/support" className={btn({ variant: "secondary" })}><LifeBuoy />Support</Link>
          <Link to="/account" className={btn({ variant: "ghost" })}><UserRound />Profile</Link>
        </>}
      />

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Active services" value={services.filter((o) => o.status === "active").length} icon={Server} />
        <StatCard label="Spent, last 12 months" value={formatINR(yearSpent)} icon={TrendingUp} />
        <StatCard label="Spent, all time" value={formatINR(totalSpent)} icon={IndianRupee} />
        <StatCard label="Next due" value={nextDue ? date(nextDue.renews_at) : "-"} icon={CalendarClock} hint={nextDue ? nextDue.server_name || nextDue.plan_name : undefined} />
      </div>

      <div className="mt-8"><CreditsPanel /></div>

      <SectionTitle className="mt-14" title="Your services" description="Everything you have running with PlexScale." actions={<Link to="/" className={btn({ variant: "secondary", size: "sm" })}>Browse plans</Link>} />
      {services.length === 0 ? (
        <div className="mt-4"><EmptyState icon={Server} title="No services yet" body="Pick a game, VPS or bot plan and it is online in about a minute." action={<Link to="/" className={btn({ size: "lg" })}>Browse plans</Link>} /></div>
      ) : (
        <div className="mt-4 space-y-3">
          {services.map((o) => {
            const overdue = o.renews_at && new Date(o.renews_at).getTime() < Date.now();
            const hasBigger = canUpgradeProduct(o.product) && (() => { const plans = effectivePlans(o.product, s.plans, true); const cur = plans.find((p) => p.id === o.plan_id); return Boolean(cur && effectivePlans(o.product, s.plans).some((p) => isUpgradePath(cur, p))); })();
            return (
              <div key={o.id} className="panel flex flex-wrap items-center justify-between gap-4 p-5 transition-colors hover:border-azure/40">
                <div className="min-w-0">
                  <p className="flex flex-wrap items-center gap-2 font-display text-lg">
                    <span className="truncate">{o.server_name || o.plan_name}</span>
                    <Badge tone={statusTone[o.status] ?? "muted"} dot>{statusLabel[o.status] ?? o.status}</Badge>
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {o.plan_name} · {productNames[o.product as ProductKey] ?? o.product} · {locations.find((l) => l.id === o.location)?.city ?? o.location} · {billingLabel(o.billing)} · <span className={overdue ? "text-destructive" : undefined}>{overdue ? "expired" : "paid until"} {date(o.renews_at)}</span>
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {["active", "suspended"].includes(o.status) && <Button disabled={payment.busy} onClick={() => setRenewFor({ order: o, amount: renewalEstimate(o) })}><RefreshCw />Renew</Button>}
                  {o.status === "active" && (canUpgradeProduct(o.product)
                    ? s.ordering.disabledProducts.includes(o.product) ? <Badge tone="bad" className="rounded-md">Upgrades out of stock</Badge>
                    : hasBigger && <Button variant="secondary" disabled={payment.busy} onClick={() => setUpgradeFor(o)}><ArrowUpCircle />Upgrade</Button>
                    : <Link to="/support/new" search={{ category: "sales", orderId: o.id }} className={btn({ variant: "text" })} title="VPS plans can be changed by our team">Upgrade via support</Link>)}
                  {o.status === "provisioning" && <Link to="/deploy/status/$orderId" params={{ orderId: o.id }} className={btn({ variant: "secondary" })}>Setup status</Link>}
                  {o.status === "active" && <a href={o.product === "vps" ? s.vpsPanelUrl : s.gamePanelUrl} target="_blank" rel="noopener noreferrer" className={btn({ variant: "secondary" })}><ExternalLink />Manage</a>}
                  {["active", "suspended"].includes(o.status) && <Button variant="secondary" onClick={() => setAccessFor(o)}><KeyRound />Access</Button>}
                  <Button variant="text" onClick={() => { setReason(""); setRefundFor(o.id); }}><RotateCcw />Refund</Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <SectionTitle className="mt-14" title="Payment history" description="Invoices are emailed after every payment and can be downloaded here." />
      <div className="panel mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr><th className={thCls}>Date</th><th className={thCls}>Item</th><th className={thCls}>Period</th><th className={thCls}>Amount</th><th className={thCls}>Paid with</th><th className={thCls}>Invoice</th></tr></thead>
          <tbody>
            {paid.length === 0 && <tr><td colSpan={6} className={cn(tdCls, "py-8 text-center text-muted-foreground")}>No payments yet.</td></tr>}
            {paid.map((o) => (
              <tr key={o.id} className="transition-colors hover:bg-accent/40">
                <td className={cn(tdCls, "whitespace-nowrap")}>{date(o.paid_at)}</td>
                <td className={tdCls}>{o.kind === "credits" ? "Credits top-up" : <>{o.kind === "renewal" ? "Renewal · " : o.kind === "upgrade" ? "Upgrade to " : ""}{o.plan_name}</>}{o.status === "refunded" ? <span className="text-muted-foreground"> (refunded)</span> : ""}</td>
                <td className={tdCls}>{o.kind === "credits" ? "One-time" : o.kind === "upgrade" ? "Prorated" : billingLabel(o.billing)}</td>
                <td className={cn(tdCls, "whitespace-nowrap font-medium tabular-nums")}>{formatINR(o.amount)}</td>
                <td className={tdCls}>{o.paid_with === "credits" ? <Badge tone="info">Credits</Badge> : <span className="font-mono text-xs text-muted-foreground">{o.razorpay_payment_id}</span>}</td>
                <td className={tdCls}>{o.razorpay_payment_id && <Button variant="text" size="sm" disabled={downloading === o.id} onClick={() => void download(o.id)}>{downloading === o.id ? <Spinner size="xs" /> : <Download />}PDF</Button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {renewFor && (
        <Dialog open onOpenChange={(v) => !v && setRenewFor(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="font-display text-2xl">Renew {renewFor.order.server_name || renewFor.order.plan_name}</DialogTitle>
              <DialogDescription>{renewFor.order.plan_name} · {billingLabel(renewFor.order.billing)}. The new period starts when the current one ends, so no paid time is lost.</DialogDescription>
            </DialogHeader>
            <div className="panel-inset flex items-center justify-between p-4 text-sm">
              <span className="text-muted-foreground">Renewal price</span>
              <span className="font-display text-xl tabular-nums">{renewFor.amount !== null ? formatINR(renewFor.amount) : "-"}</span>
            </div>
            <PayChoice amount={renewFor.amount} balance={credits.data?.balance} product={renewFor.order.product} disabled={payment.busy} onPay={(useCredits) => void doRenew(renewFor.order, useCredits)} />
          </DialogContent>
        </Dialog>
      )}

      {upgradeFor && <UpgradeDialog order={upgradeFor} balance={credits.data?.balance} onClose={() => setUpgradeFor(null)} onPay={async (toPlanId, toName, useCredits) => {
        const o = upgradeFor;
        setUpgradeFor(null);
        const { data: u } = await supabase.auth.getUser();
        await payment.run({
          create: () => upgrade({ data: { orderId: o.id, toPlanId, useCredits } }),
          description: `Upgrade ${o.server_name || o.plan_name} to ${toName}`,
          email: u.user?.email,
          verify: (co, r) => verify({ data: { orderId: co.orderId, razorpayOrderId: r.razorpay_order_id, paymentId: r.razorpay_payment_id, signature: r.razorpay_signature } }),
          success: () => { refresh(); return { title: "Upgrade complete", body: `${o.server_name || o.plan_name} is now on ${toName}. Restart your server from the panel to use the new resources.` }; },
        });
      }} />}
      {refundFor && (() => {
        const o = data.orders.find((x) => x.id === refundFor);
        if (!o) return null;
        const rf = data.refunds.find((r) => r.order_id === o.id);
        const gameProduct = isGame(o.product);
        const eligible = isOrderRefundEligible(o.kind, o.product, o.paid_at);
        return (
          <Dialog open onOpenChange={(v) => !v && setRefundFor(null)}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="font-display text-2xl">Refund</DialogTitle>
                <DialogDescription>{o.server_name || o.plan_name} · {o.plan_name}</DialogDescription>
              </DialogHeader>
              {rf ? (
                <div className="panel-inset p-4 text-sm">
                  <p className="text-muted-foreground">Refund status</p>
                  <p className="mt-1 font-display text-lg capitalize">{rf.status}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Requested {date(rf.created_at)}. We email you when it changes.</p>
                </div>
              ) : !gameProduct ? (
                <div className="panel-inset p-4 text-sm">
                  <p className="font-display text-lg">Refund not applicable</p>
                  <p className="mt-1 text-muted-foreground">VPS and bot hosting services are not refundable.</p>
                </div>
              ) : !eligible ? (
                <div className="panel-inset p-4 text-sm">
                  <p className="font-display text-lg">Refund window closed</p>
                  <p className="mt-1 text-muted-foreground">Game servers can be refunded within 24 hours of purchase.</p>
                </div>
              ) : (
                <form onSubmit={sendRefund} className="grid gap-3">
                  <label className="text-sm text-muted-foreground" htmlFor="refund-reason">Reason for refund</label>
                  <textarea id="refund-reason" required minLength={5} maxLength={500} rows={4} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Tell us why you need a refund" className={textareaCls} />
                  <Button type="submit" size="lg" className="w-full" disabled={sending}>{sending ? <Spinner size="xs" /> : null}Submit request</Button>
                </form>
              )}
            </DialogContent>
          </Dialog>
        );
      })()}
      {accessFor && <AccessDialog order={accessFor} onClose={() => setAccessFor(null)} />}
      {payment.overlay}
    </section>
  );
}

function UpgradeDialog({ order, balance, onClose, onPay }: { order: Order; balance: number | undefined; onClose: () => void; onPay: (toPlanId: string, toName: string, useCredits: boolean) => void }) {
  const s = useSettings();
  const quote = useServerFn(quoteUpgrade);
  const all = effectivePlans(order.product, s.plans, true);
  const current = all.find((p) => p.id === order.plan_id);
  const options = current ? effectivePlans(order.product, s.plans).filter((p) => isUpgradePath(current, p)) : [];
  const [pick, setPick] = useState(options[0]?.id ?? "");
  const q = useQuery({
    queryKey: ["upgrade-quote", order.id, pick],
    enabled: Boolean(pick),
    queryFn: () => quote({ data: { orderId: order.id, toPlanId: pick } }),
    retry: false,
    staleTime: 30_000,
  });
  const chosen = options.find((p) => p.id === pick);
  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Upgrade {order.server_name || order.plan_name}</DialogTitle>
          <DialogDescription>Pay only the difference for the time left on your current period. Your expiry date stays the same and your files are kept.</DialogDescription>
        </DialogHeader>
        {!current || options.length === 0 ? <p className="text-sm text-muted-foreground">You are already on the biggest plan. Need more? <Link to="/support/new" search={{ category: "sales", orderId: order.id }} className="text-azure hover:underline">Contact support</Link>.</p> : (
          <>
            <p className="text-sm text-muted-foreground">Current plan: <span className="text-foreground">{current.name}</span> · {current.ramLabel} RAM · {current.storage} NVMe</p>
            <div className="mt-2 grid max-h-72 gap-2 overflow-y-auto pr-1">
              {options.map((p) => (
                <button key={p.id} type="button" onClick={() => setPick(p.id)} aria-pressed={pick === p.id} className={cn("flex items-center justify-between rounded-md border p-3 text-left text-sm text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", pick === p.id ? "border-azure bg-azure/10" : "border-steel hover:border-azure/60 hover:bg-accent")}>
                  <span><span className="font-display font-semibold">{p.name}</span><span className="block text-xs text-muted-foreground">{p.ramLabel} RAM · {p.storage} NVMe · {p.cpuPercent}% CPU</span></span>
                  <span className="font-display text-azure">{formatINR(p.monthly)}<span className="text-xs text-muted-foreground">/mo</span></span>
                </button>
              ))}
            </div>
            <div className="panel-inset mt-2 p-4 text-sm">
              {q.isFetching ? <div className="flex items-center gap-3 text-muted-foreground"><Spinner size="sm" />Calculating your price</div>
                : q.error ? <p className="text-destructive">{shownError(q.error, "Price could not be calculated.")}</p>
                : q.data ? (
                  <dl className="space-y-1.5">
                    <div className="flex justify-between"><dt className="text-muted-foreground">Days left on this period</dt><dd>{q.data.remainingDays} of {q.data.periodDays}</dd></div>
                    <div className="flex justify-between"><dt className="text-muted-foreground">Expiry date</dt><dd>{date(q.data.renewsAt)}</dd></div>
                    <div className="flex justify-between border-t border-steel pt-2 font-display text-lg"><dt>Pay now</dt><dd>{formatINR(q.data.amount)}</dd></div>
                    <p className="text-xs text-muted-foreground">Future renewals use the {q.data.toPlan} price. Upgrades are not refundable.</p>
                  </dl>
                ) : null}
            </div>
            <PayChoice className="mt-2" amount={q.data && !q.isFetching ? q.data.amount : null} balance={balance} product={order.product} disabled={!q.data || q.isFetching || !chosen || !isBilling(order.billing)} onPay={(useCredits) => chosen && onPay(chosen.id, chosen.name, useCredits)} />
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
