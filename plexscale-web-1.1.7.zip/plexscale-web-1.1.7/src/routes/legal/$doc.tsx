import { createFileRoute, notFound, redirect } from "@tanstack/react-router";
import { useSettings } from "@/hooks/use-settings";
import { absoluteUrl, breadcrumbLd, ORG_ID, pageHead } from "@/lib/seo";

const legalSummaries: Record<string, string> = {
  tos: "Terms of Service for PlexScale game servers, VPS and Discord bot hosting: account use, payments, suspensions and your responsibilities.",
  privacy: "How PlexScale collects, uses and protects your personal data for game server, VPS and bot hosting, and the choices you have.",
  refund: "PlexScale refund policy: eligible game hosting can be refunded within 24 hours. VPS, bot hosting, renewals and credits are non-refundable.",
  "acceptable-use": "What you may and may not run on PlexScale game servers, VPS and bot hosting, and how we handle abuse reports.",
  sla: "PlexScale Service Level Agreement: our uptime commitment, what counts as downtime and how to claim service credits.",
};

interface Doc { title: string; intro?: string; sections: { h: string; p?: string; items?: string[] }[]; outro?: string }

/** Old addresses that moved, kept working with a permanent redirect. */
const movedDocs: Record<string, string> = { terms: "tos", refunds: "refund" };

const docs: Record<string, Doc> = {
  tos: { title: "Terms of Service",
    intro: "By accessing or using PlexScale services, you agree to comply with the following Terms of Service. These terms are designed to ensure fair usage, platform stability, and a safe environment for all users.",
    sections: [
    { h: "General terms", items: [
      "By purchasing or using PlexScale services, you agree to follow all policies and terms listed here.",
      "Services are delivered after successful payment confirmation. Access details will be provided once the service is activated.",
      "Users are responsible for all activities performed on their account, servers, or services.",
      "PlexScale reserves the right to suspend or terminate services that violate these terms or disrupt platform stability.",
      "Users must ensure their usage complies with all applicable local and international laws. Illegal activities are strictly prohibited.",
      "Abuse of system resources, including excessive CPU usage, network abuse, or attempts to bypass system limitations, is not allowed.",
    ] },
    { h: "Prohibited activities", items: [
      "Cryptocurrency mining or similar resource-intensive workloads.",
      "Hosting malware, phishing content, or malicious software.",
      "Distribution of illegal or copyrighted content without proper authorization.",
      "Running attacks such as DDoS, network scanning, or exploitation of vulnerabilities.",
      "Attempting to access other users' services, accounts, or data without authorization.",
    ] },
    { h: "Maintenance and liability", items: [
      "PlexScale may perform maintenance or upgrades that may temporarily affect service availability. We will attempt to minimize downtime whenever possible.",
      "PlexScale is not responsible for user-generated content, configurations, or any damages caused by misconfiguration or improper usage.",
    ] },
    { h: "Billing", p: "Prices are in INR with GST included. Plans do not renew automatically. We send reminder emails before a service is due." },
    { h: "Account conduct", items: [
      "Users must provide accurate information when creating an account.",
      "Sharing or selling accounts without permission is not allowed.",
      "Harassment, abuse, or disrespect toward staff or other users may result in account suspension or permanent bans.",
    ] },
    { h: "Service termination", items: [
      "PlexScale may suspend or terminate services without prior notice if severe violations occur.",
      "Accounts involved in abuse, illegal activities, or security threats may be permanently banned.",
      "Services are suspended when their paid period ends. A service still unrenewed 7 days after expiry is permanently deleted with all its files, and refunded services are deleted 24 hours after the refund. Deleted data cannot be recovered.",
    ] },
    { h: "Changes to these terms", items: [
      "PlexScale reserves the right to update or modify these Terms of Service at any time to improve security, stability, or compliance.",
      "Continued use of PlexScale services after changes to these terms indicates acceptance of the updated policies.",
    ] },
  ], outro: "Thank you for choosing PlexScale. Our mission is to provide a secure, stable, and high-performance hosting platform for all users." },
  privacy: { title: "Privacy Policy",
    intro: "By using PlexScale services, you agree to the terms outlined below. Please read them carefully before purchasing or using our platform.",
    sections: [
    { h: "Activation and responsibility", items: [
      "Services are automatically activated once payment has been successfully completed and verified.",
      "Users are fully responsible for managing and maintaining their servers, applications, and hosted content.",
      "Support is provided through our on-site ticket system (Support tickets, available to signed-in customers), Discord and email. While support is not guaranteed to be 24/7, we aim to respond as quickly as possible.",
    ] },
    { h: "Your data", items: [
      "PlexScale respects your privacy. We do not access, monitor, or inspect your private files or data unless required for security, abuse investigation, or legal compliance.",
      "We collect your name, email, billing details and service usage data needed to run your services, and share it only with payment processors and as required by Indian law.",
    ] },
    { h: "Fair usage and abuse", items: [
      "All hosting plans operate under a fair usage policy for CPU, RAM, network, and storage resources to ensure stable performance for all users.",
      "Any form of abuse or prohibited activity (including but not limited to crypto mining, illegal content, excessive resource abuse, malicious activity, or content violating our Terms of Service) may result in immediate suspension or termination without refund.",
      "Users must maintain respectful communication with staff and community members across all support channels.",
    ] },
    { h: "Refunds", items: [
      "Refund requests must be submitted within 24 hours (1 day) of payment.",
      "Refunds are available only for eligible new game-hosting orders. Renewals, VPS and bot hosting are not refundable.",
      "A valid reason must be provided, such as a confirmed technical issue that our team was unable to resolve.",
      "Refunds will not be issued if more than 24 hours have passed since payment, or if the service has been abused or violated our acceptable use policies.",
      "Abuse toward staff members, use of offensive language, harassment, or repeated disrespectful behavior will not be tolerated and may result in account termination and permanent bans without refund.",
    ] },
    { h: "Contact", p: `Email {{email}} with any privacy request.` },
  ], outro: "Note: Those who do not read the Terms of Service are fully responsible for any consequences. Thank you for choosing PlexScale." },
  refund: { title: "Refund Policy", sections: [
    { h: "Game hosting", p: "Eligible game hosting purchases can be refunded within 24 hours of payment, with a valid reason such as a technical issue our team could not resolve. Renewals are not refundable." },
    { h: "VPS and bot hosting", p: "VPS and Discord bot hosting are not refundable." },
    { h: "When refunds are refused", items: ["More than 24 hours have passed since payment.", "The purchase is a renewal.", "The service was abused or broke the Acceptable Use Policy.", "Abuse or harassment toward staff."] },
    { h: "How to ask", p: `Open a ticket or email {{email}} with your invoice number.` },
  ] },
  "acceptable-use": { title: "Acceptable Use Policy",
    intro: "This policy describes what you may and may not do with PlexScale services. It applies to every game server, VPS and bot hosting plan.",
    sections: [
    { h: "Prohibited content and activity", items: [
      "Cryptocurrency mining or similar resource-intensive workloads.",
      "Hosting malware, phishing pages, or malicious software.",
      "Illegal content, or copyrighted content without proper authorization.",
      "DDoS attacks, network scanning, port scanning, or exploiting vulnerabilities.",
      "Spam, bulk unsolicited email, or open proxies and relays used for abuse.",
      "Accessing other users' services, accounts, or data without authorization.",
    ] },
    { h: "Fair usage", items: [
      "CPU, RAM, network, and storage are shared fairly so every customer gets stable performance.",
      "Sustained activity that degrades the node for other customers may be limited.",
      "Attempts to bypass plan limits are not allowed.",
    ] },
    { h: "Conduct", items: [
      "Treat staff and community members with respect in tickets, Discord and email.",
      "Harassment, offensive language, or repeated disrespect may lead to termination without refund.",
    ] },
    { h: "Enforcement", items: [
      "Violations may result in immediate suspension or termination without refund.",
      "Severe or illegal activity may be reported to the relevant authorities.",
    ] },
    { h: "Reporting abuse", p: `Report abuse to {{email}} with as much detail as you can.` },
  ] },
  sla: { title: "Service Level Agreement",
    intro: "This standard SLA describes the availability PlexScale commits to and what you receive if we fall short.",
    sections: [
    { h: "Uptime commitment", p: "We commit to 99.95% monthly uptime for the network and host nodes in every location. *Excludes scheduled maintenance and the exclusions listed below." },
    { h: "How uptime is measured", p: "Uptime is measured from our external monitoring for each location, in one-minute intervals, across a calendar month." },
    { h: "Service credits", items: [
      "99.0% to below 99.95%: 10% of the monthly fee for the affected service.",
      "95.0% to below 99.0%: 25% of the monthly fee.",
      "Below 95.0%: 50% of the monthly fee.",
      "Credits are applied to your next renewal and are not paid as cash.",
    ] },
    { h: "Exclusions", items: [
      "Scheduled maintenance announced in advance.",
      "Issues caused by your software, configuration, or content.",
      "Suspensions under the Terms of Service or Acceptable Use Policy.",
      "Events outside our reasonable control, such as upstream provider outages or natural disasters.",
    ] },
    { h: "How to claim", p: `Open a ticket or email {{email}} within 7 days of the incident with your service ID and the time of the outage.` },
  ] },
};

export const Route = createFileRoute("/legal/$doc")({
  loader: ({ params }) => {
    const moved = movedDocs[params.doc];
    if (moved) throw redirect({ to: "/legal/$doc", params: { doc: moved }, statusCode: 301 });
    const d = docs[params.doc];
    if (!d) throw notFound();
    return d;
  },
  head: ({ loaderData, params }) => {
    const name = loaderData?.title ?? "Legal";
    const path = `/legal/${params.doc}`;
    const title = `${name} | PlexScale`;
    const description = legalSummaries[params.doc] ?? `${name} for PlexScale game server, VPS and Discord bot hosting.`;
    return pageHead({
      path, title, description, type: "article", image: "/og/home.jpg", imageAlt: "PlexScale game servers, VPS and bot hosting on AMD EPYC",
      jsonLd: [{ "@type": "WebPage", name, url: absoluteUrl(path), dateModified: "2026-10-29", publisher: { "@id": ORG_ID } }, breadcrumbLd([{ name, path }])],
    });
  },
  component: Legal,
});

function Legal() {
  const d = Route.useLoaderData();
  const { supportEmail } = useSettings();
  const fill = (t: string) => t.replaceAll("{{email}}", supportEmail);
  const id = (s: string) => s.toLowerCase().replace(/[^a-z]+/g, "-");
  return (
    <section className="section container-px grid gap-12 lg:grid-cols-12">
      <aside className="lg:col-span-3">
        <nav aria-label="Contents" className="sticky top-24">
          <p className="eyebrow">Contents</p>
          <ul className="mt-4 space-y-2 text-sm">
            {d.sections.map((s) => <li key={s.h}><a href={`#${id(s.h)}`} className="text-muted-foreground hover:text-foreground">{s.h}</a></li>)}
          </ul>
        </nav>
      </aside>
      <article className="measure lg:col-span-9">
        <h1 className="text-4xl md:text-5xl">{d.title}</h1>
        <p className="mt-3 text-sm text-muted-foreground">Last updated: 29 October 2026</p>
        {d.intro && <p className="mt-6 text-muted-foreground">{d.intro}</p>}
        {d.sections.map((s) => (
          <section key={s.h} id={id(s.h)} className="mt-10 scroll-mt-24">
            <h2 className="text-2xl">{s.h}</h2>
            {s.p && <p className="mt-3 text-muted-foreground">{fill(s.p)}</p>}
            {s.items && <ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">{s.items.map((i) => <li key={i}>{i}</li>)}</ul>}
          </section>
        ))}
        {d.outro && <p className="mt-12 border-t border-border pt-6 text-sm text-muted-foreground">{d.outro}</p>}
      </article>
    </section>
  );
}
