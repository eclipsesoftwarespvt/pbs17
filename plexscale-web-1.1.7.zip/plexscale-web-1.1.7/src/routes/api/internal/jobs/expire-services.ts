import { createFileRoute } from "@tanstack/react-router";

// Internal only (see src/lib/internal-jobs.server.ts). Daily: expiry reminders, suspends services whose paid period ended, deletes servers still unrenewed
// 7 days after expiry and refunded servers 24 hours after the refund, then tidies old rows. Idempotent.
export const Route = createFileRoute("/api/internal/jobs/expire-services")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { authenticateInternalJob } = await import("@/lib/internal-jobs.server");
        const authFailure = await authenticateInternalJob(request);
        if (authFailure) return authFailure;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { audit, suspendOnPanel, resumeOnPanel, deleteExpiredServices, deleteRefundedServices, deleteOrphanPlexusAccounts } = await import("@/lib/billing.server");
        const { sendExpiryReminders } = await import("@/lib/notify.server");
        const { logEvent } = await import("@/lib/log");
        let reminders = 0;
        try { reminders = (await sendExpiryReminders()).sent; } catch (e) { logEvent("error", "job.reminders_failed", { message: e instanceof Error ? e.message : String(e) }); }

        // Suspend as soon as the paid period ends (no grace days).
        const cutoff = new Date().toISOString();
        const { data: due } = await supabaseAdmin.from("orders").select("id, user_id, product, ptero_server_id, plexus_machine_id").eq("kind", "new").eq("status", "active").lt("renews_at", cutoff).limit(200);
        let suspended = 0;
        for (const o of due ?? []) {
          const { data: current } = await supabaseAdmin.from("orders").select("id, status, renews_at").eq("id", o.id).maybeSingle();
          if (!current || current.status !== "active" || !current.renews_at || new Date(current.renews_at).getTime() >= Date.parse(cutoff)) continue;
          if (!(await suspendOnPanel(o))) continue;
          const { data: claimed, error } = await supabaseAdmin.from("orders").update({ status: "suspended" }).eq("id", o.id).eq("status", "active").lt("renews_at", cutoff).select("id").maybeSingle();
          if (error || !claimed) {
            // Renewed while we were suspending: give the server back.
            const { data: now } = await supabaseAdmin.from("orders").select("status, renews_at").eq("id", o.id).maybeSingle();
            if (now?.status === "active" && now.renews_at && Date.parse(now.renews_at) > Date.now()) await resumeOnPanel(o);
            continue;
          }
          await audit(null, "order.expire", o.id);
          suspended++;
        }

        const expired = await deleteExpiredServices();
        const refunded = await deleteRefundedServices();
        const plexusAccounts = await deleteOrphanPlexusAccounts();

        // Unpaid checkouts older than a day are closed so they do not clutter billing.
        // Credit-paid orders are excluded: their balance is already taken and the reconcile job completes them.
        await supabaseAdmin.from("orders").update({ status: "failed" }).eq("status", "pending").eq("paid_with", "razorpay").is("razorpay_payment_id", null).lt("created_at", new Date(Date.now() - 864e5).toISOString());
        await supabaseAdmin.from("rate_limits").delete().lt("window_start", new Date(Date.now() - 864e5).toISOString());
        await supabaseAdmin.from("webhook_events").delete().lt("received_at", new Date(Date.now() - 30 * 864e5).toISOString());
        logEvent("info", "job.expire_services", { suspended, reminders, expired, refunded, plexusAccounts });
        return Response.json({ suspended, reminders, deletedExpired: expired.deleted, deleteFailures: expired.failed + refunded.failed, deletedRefunded: refunded.deleted, plexusAccountsDeleted: plexusAccounts.deleted, plexusAccountsWaiting: plexusAccounts.waiting });
      },
    },
  },
});
