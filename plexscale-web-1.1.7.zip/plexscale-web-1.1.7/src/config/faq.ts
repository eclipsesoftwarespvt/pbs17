export interface QA { q: string; a: string }

const setupFaq: QA = { q: "How fast is setup?", a: "Most servers are live in about a minute after payment. You get panel access by email right away." };
const renewalFaq: QA = { q: "Do plans renew automatically?", a: "No. Nothing renews on its own. We send reminder emails before your server is due, and you choose when to renew." };
const refundFaq: QA = { q: "What is your refund policy?", a: "Eligible game hosting can be refunded within 24 hours of payment. VPS, bot hosting, renewals and PlexScale Credits are not refundable." };
const creditsRefundFaq: QA = { q: "Can I get a refund on PlexScale Credits?", a: "No. Like VPS and bot hosting, PlexScale Credits are not refundable once added to your account. Credits can be used for new servers, renewals and upgrades." };
const protectionFaq: QA = { q: "Am I protected from DDoS attacks?", a: "Every server includes standard L3/L4/L7 mitigation with capacity of up to 480 Gbps, at no extra cost." };
const migrationFaq: QA = { q: "Can you move my server from another host?", a: "Yes. Open a support ticket on the website (Support tickets in your account menu), message us on Discord or email help@plexscale.com, and our team will help you move your files and worlds." };
const networkingFaq: QA = {
  q: "Why does PlexScale feel smoother?",
  a: "Tuned AMD EPYC hardware and NVMe storage do most of the work, and our network keeps traffic moving efficiently. Accelerated Networking (SR-IOV) cuts virtualization overhead and can lower latency. BGP Anycast Routing advertises the same IP prefix from several locations, with routing policies and network topology picking the endpoint. Layer 4 Load Balancing spreads TCP and UDP traffic across healthy instances. Actual latency still depends on your distance from the server, your connection and the game workload.",
};

export const homeFaq: QA[] = [
  setupFaq,
  { q: "Can I upgrade my plan later?", a: "Game servers and bot hosting plans can move to a bigger plan from your billing page while at least one day is left on the current period, paying only the difference for the days left. VPS upgrades are handled by our team, so open a support ticket." },
  renewalFaq,
  refundFaq,
  creditsRefundFaq,
  protectionFaq,
  migrationFaq,
  networkingFaq,
];

export const faqTabs: { key: string; label: string; items: QA[] }[] = [
  {
    key: "start",
    label: "Getting started",
    items: [
      setupFaq,
      { q: "Which Minecraft software can I run?", a: "PaperMC, Fabric, Forge, SpigotMC, NeoForge and Vanilla. Switch between them from the panel." },
      { q: "Which location should I pick?", a: "Pick the location closest to most of your players. Use the ping test in the locations section on the home page to compare." },
      migrationFaq,
    ],
  },
  {
    key: "hardware",
    label: "Hardware",
    items: [
      { q: "What CPU do you use?", a: "AMD EPYC 7000 and 9000 series processors: the EPYC 9V74 at up to 3.70 GHz, the EPYC 7763 at up to 3.50 GHz and the EPYC 7V12 at up to 3.35 GHz. Your server is placed on the best node available in your location, and every plan gets at least an AMD EPYC at 3.35 GHz." },
      { q: "What storage and memory?", a: "NVMe Gen 4 SSD storage on every plan. EPYC 9V74 nodes use DDR5 4800 MHz memory, and every other node uses DDR4 3200 MHz." },
      protectionFaq,
      networkingFaq,
      { q: "What uptime do you target?", a: "We target 99.95% uptime. The SLA page explains how it is measured." },
    ],
  },
  {
    key: "billing",
    label: "Billing and support",
    items: [
      { q: "Which currency and taxes?", a: "All prices are in INR with GST included. What you see is what you pay." },
      { q: "How can I pay?", a: "UPI, cards and netbanking." },
      renewalFaq,
      { q: "What happens if I don't renew?", a: "Your server is suspended when its paid period ends. If it is still unrenewed 7 days after expiry, the server and all its files are permanently deleted and cannot be recovered. Renew any time before then to keep everything." },
      refundFaq,
      creditsRefundFaq,
      { q: "How do I reach support?", a: "Join discord.gg/plexscale for quick help, or email help@plexscale.com for billing and private issues." },
    ],
  },
];
