import { arkMapName, cs2Modes, gmodGamemodes, MAX_SEED, type Cs2Mode, type GameOptions, type GmodGamemode } from "./game-options";

/**
 * Turns a panel egg's default variables into the values a real server needs.
 * Pure on purpose: the server passes in the egg defaults, the order and a random source.
 * Only variables the egg actually defines are ever set.
 */
interface EggEnvContext {
  product: string;
  serverName: string;
  description: string;
  ramMb: number;
  options: GameOptions;
  /** Extra ports given to this server, in the order `extraPortVariables` lists the variables. */
  ports: number[];
  /** Admin-set fixed values for this software; they win over everything except customer choices. */
  adminEnv?: Record<string, string>;
  random: { password: () => string; seed: () => number };
}

/** Port variables each game may need, in reservation order. Minecraft, Garry's Mod and bots need none. */
export const PORT_VARIABLES: Record<string, readonly string[]> = {
  cs2: ["TV_PORT"],
  rust: ["RCON_PORT", "APP_PORT", "QUERY_PORT"],
  hytale: ["QUERY_PORT"],
  palworld: ["RCON_PORT"],
  ark: ["QUERY_PORT", "RCON_PORT"],
};

/** ARK: Survival Evolved also listens on game port + 1; this placeholder (no egg defines it) reserves it. */
export const ARK_PEER_PORT = "ARK_PEER_PORT";

/** Startup values the site fills for each game, shown beside the egg mapping in Administrator. */
export const EGG_FILLS: Record<string, readonly string[]> = {
  cs2: ["SERVER_NAME", "GAME_TYPE", "GAME_MODE", "MAX_PLAYERS", "SRCDS_MAP", "SERVER_PASSWORD", "RCON_PASSWORD", "STEAM_GSLT"],
  rust: ["HOSTNAME", "DESCRIPTION", "FRAMEWORK", "WORLD_SIZE", "WORLD_SEED", "MAX_PLAYERS", "RCON_PASS", "SAVEINTERVAL"],
  hytale: ["HYTALE_PATCHLINE", "HYTALE_AUTH_MODE"],
  palworld: ["SERVER_NAME", "SERVER_DESCRIPTION", "SERVER_PASSWORD", "ADMIN_PASSWORD", "MAX_PLAYERS", "RCON_ENABLE"],
  ark: ["SESSION_NAME", "SERVER_MAP", "MAX_PLAYERS", "ARK_ADMIN_PASSWORD", "ARK_PASSWORD or SERVER_PASSWORD"],
  gmod: ["GAMEMODE", "SRCDS_MAP", "MAX_PLAYERS", "WORKSHOP_ID", "STEAM_TOKEN"],
};

/** The ARK: Survival Evolved egg (Steam app 376030); the Ascended egg uses app 2430930. */
const isArkEvolved = (defaults: Record<string, string>) => defaults["SRCDS_APPID"] === "376030" || "ARK_PASSWORD" in defaults;

/**
 * Names of the extra port variables this egg defines, in order. Only variables the egg actually
 * has are listed, plus the ARK: Survival Evolved peer port. Hytale skips its query port when the query plugin variable is "0".
 */
export function extraPortVariables(product: string, defaults: Record<string, string>): string[] {
  if (product === "hytale" && defaults["INSTALL_SOURCEQUERY_PLUGIN"] === "0") return [];
  const vars = (PORT_VARIABLES[product] ?? []).filter((name) => name in defaults);
  return product === "ark" && isArkEvolved(defaults) ? [ARK_PEER_PORT, ...vars] : vars;
}

/** Parses admin port ranges such as "25565-25665" or "27015". Bad entries are ignored. */
export function parsePortRanges(ranges: readonly string[] | undefined): { from: number; to: number }[] {
  const out: { from: number; to: number }[] = [];
  for (const r of ranges ?? []) {
    const m = /^(\d{1,5})(?:-(\d{1,5}))?$/.exec(r.trim());
    if (!m) continue;
    const from = Number(m[1]);
    const to = Number(m[2] ?? m[1]);
    if (from >= 1 && to <= 65535 && from <= to) out.push({ from, to });
  }
  return out;
}

/** Lowest port the eggs accept for a game port (the CS2 egg requires 1025 or higher). */
export const MIN_GAME_PORT = 1025;

/** True when the port is usable and, if ranges are set, falls inside one of them. */
export function portAllowed(port: number, ranges: readonly { from: number; to: number }[]): boolean {
  return port >= MIN_GAME_PORT && port <= 65535 && (ranges.length === 0 || ranges.some((r) => port >= r.from && port <= r.to));
}

/** Strips characters that could break out of the quoted values in a startup command. */
// eslint-disable-next-line no-control-regex -- strips control characters on purpose
const safeText = (s: string, max: number) => s.replace(/[\u0000-\u001f"'`$\\{}<>|;&]/g, "").replace(/\s+/g, " ").trim().slice(0, max);

/** Rust player slots scale with memory. */
function rustMaxPlayers(ramMb: number): number {
  const gb = ramMb / 1024;
  if (gb >= 32) return 300;
  if (gb >= 24) return 200;
  if (gb >= 16) return 150;
  if (gb >= 12) return 100;
  return 50;
}

/** ARK player slots scale with memory (each survivor and their dinos cost RAM). */
function arkMaxPlayers(ramMb: number): number {
  const gb = ramMb / 1024;
  if (gb >= 24) return 70;
  if (gb >= 16) return 50;
  if (gb >= 12) return 30;
  if (gb >= 8) return 20;
  return 10;
}

/** Garry's Mod player slots (the egg allows up to 128). */
function gmodMaxPlayers(ramMb: number): number {
  const gb = ramMb / 1024;
  if (gb >= 16) return 128;
  if (gb >= 6) return 64;
  return 32;
}

export function buildEggEnvironment(defaults: Record<string, string>, ctx: EggEnvContext): Record<string, string> {
  const env = { ...defaults };
  const set = (key: string, value: string | number | undefined) => {
    if (value !== undefined && key in env) env[key] = String(value);
  };
  const name = safeText(ctx.serverName, 40) || "PlexScale server";
  const about = safeText(ctx.description, 120);
  const o = ctx.options;

  if (ctx.product === "cs2") {
    const mode = cs2Modes[(o.mode as Cs2Mode | undefined) ?? "competitive"];
    set("SERVER_NAME", name);
    set("RCON_PASSWORD", ctx.random.password());
    set("GAME_TYPE", mode.type);
    set("GAME_MODE", mode.mode);
    set("MAX_PLAYERS", mode.players);
    set("SRCDS_MAP", o.map ?? "de_dust2");
    set("SERVER_PASSWORD", o.password ?? "");
  } else if (ctx.product === "rust") {
    set("HOSTNAME", name);
    set("DESCRIPTION", about || "Hosted by PlexScale");
    set("SERVER_URL", "");
    set("SERVER_IMG", "");
    set("SERVER_LOGO", "");
    set("WORLD_SIZE", o.worldSize ?? 3500);
    set("WORLD_SEED", o.seed ?? ctx.random.seed());
    set("MAX_PLAYERS", rustMaxPlayers(ctx.ramMb));
    set("RCON_PASS", ctx.random.password());
    set("SAVEINTERVAL", 300);
    set("FRAMEWORK", o.framework ?? "vanilla");
  } else if (ctx.product === "hytale") {
    set("HYTALE_PATCHLINE", o.patchline ?? "release");
    set("HYTALE_AUTH_MODE", "authenticated");
  } else if (ctx.product === "palworld") {
    set("SERVER_NAME", name);
    set("SERVER_DESCRIPTION", about);
    set("SERVER_PASSWORD", o.password ?? "");
    // Required by the egg and used by its RCON console bridge; never shown to anyone.
    set("ADMIN_PASSWORD", ctx.random.password());
    set("MAX_PLAYERS", 32);
    set("RCON_ENABLE", "True");
  } else if (ctx.product === "ark") {
    const evolved = isArkEvolved(env);
    // "?" and "=" would split ARK's ?key=value launch string.
    set("SESSION_NAME", name.replace(/[?=]/g, "").trim() || "PlexScale server");
    set("SERVER_MAP", arkMapName(o.map, evolved ? "evolved" : "ascended"));
    set("MAX_PLAYERS", arkMaxPlayers(ctx.ramMb));
    // RCON and the console use this, so it is always random.
    set("ARK_ADMIN_PASSWORD", ctx.random.password());
    set(evolved ? "ARK_PASSWORD" : "SERVER_PASSWORD", o.password ?? "");
  } else if (ctx.product === "gmod") {
    set("GAMEMODE", (o.mode && Object.hasOwn(gmodGamemodes, o.mode) ? o.mode : "sandbox") as GmodGamemode);
    set("SRCDS_MAP", o.map ?? "gm_construct");
    set("MAX_PLAYERS", gmodMaxPlayers(ctx.ramMb));
    set("WORKSHOP_ID", o.workshop ?? "");
  }

  for (const [k, v] of Object.entries(ctx.adminEnv ?? {})) set(k, v);
  // Reserved ports go in by variable name, after admin values, so they always match the server's allocations.
  extraPortVariables(ctx.product, env).forEach((name, i) => set(name, ctx.ports[i]));
  // The customer's own Steam token is applied last so an admin default can never replace it.
  if (ctx.product === "cs2") set("STEAM_GSLT", o.gslt);
  if (ctx.product === "gmod" && o.gslt) set("STEAM_TOKEN", o.gslt);
  return env;
}

/** Egg defaults with the admin's fixed values applied (only for variables the egg defines). */
export function withAdminEnv(defaults: Record<string, string>, adminEnv: Record<string, string> | undefined): Record<string, string> {
  const out = { ...defaults };
  for (const [k, v] of Object.entries(adminEnv ?? {})) if (k in out) out[k] = v;
  return out;
}

/** Random values for secrets in the server's startup settings. */
export function cryptoRandom() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  return {
    password: () => {
      const bytes = crypto.getRandomValues(new Uint8Array(24));
      return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
    },
    seed: () => 1 + ((crypto.getRandomValues(new Uint32Array(1))[0] ?? 1) % MAX_SEED),
  };
}

export interface FreeAllocation { id: number; ip: string; port: number }

/**
 * Picks a main port plus `extra` more on the same IP, preferring a run of
 * consecutive ports (e.g. 25000, 25001, 25002) so they are easy to read.
 * With `peerPort`, the first extra port must be main port + 1 (ARK).
 */
export function pickAllocations(free: FreeAllocation[], extra: number, peerPort = false): { primary: FreeAllocation; additional: FreeAllocation[] } | null {
  const byIp = new Map<string, FreeAllocation[]>();
  for (const a of free) byIp.set(a.ip, [...(byIp.get(a.ip) ?? []), a]);
  let fallback: { primary: FreeAllocation; additional: FreeAllocation[] } | null = null;
  for (const list of byIp.values()) {
    if (list.length < extra + 1) continue;
    const sorted = [...list].sort((a, b) => a.port - b.port);
    const byPort = new Map(sorted.map((a) => [a.port, a]));
    for (const a of sorted) {
      const run = Array.from({ length: extra }, (_, i) => byPort.get(a.port + i + 1));
      if (run.every(Boolean)) return { primary: a, additional: run as FreeAllocation[] };
    }
    if (peerPort) {
      const a = sorted.find((x) => byPort.has(x.port + 1));
      const peer = a && byPort.get(a.port + 1);
      if (a && peer) {
        const rest = sorted.filter((x) => x !== a && x !== peer).slice(0, extra - 1);
        if (rest.length === extra - 1) fallback ??= { primary: a, additional: [peer, ...rest] };
      }
      continue;
    }
    fallback ??= { primary: sorted[0]!, additional: sorted.slice(1, extra + 1) };
  }
  return fallback;
}
