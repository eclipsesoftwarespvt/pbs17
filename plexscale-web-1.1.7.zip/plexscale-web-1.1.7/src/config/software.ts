import papermc from "@/assets/mc/papermc.png";
import fabric from "@/assets/mc/fabric.png";
import forge from "@/assets/mc/forge.png";
import spigot from "@/assets/mc/spigot.png";
import neoforge from "@/assets/mc/neoforge.png";
import vanilla from "@/assets/mc/vanilla.png";
import type { ProductKey } from "./plans";

/** Logos for supported server software, keyed by display name. */
export const softwareLogos: Record<string, string> = {
  PaperMC: papermc,
  Fabric: fabric,
  Forge: forge,
  SpigotMC: spigot,
  NeoForge: neoforge,
  Vanilla: vanilla,
};

export interface SoftwareOption {
  key: string;
  label: string;
  logo?: string;
  hint: string;
}

const softwareCatalog: Record<ProductKey, SoftwareOption[]> = {
  minecraft: [
    { key: "paper", label: "PaperMC", logo: papermc, hint: "Fast, plugin friendly. Best for most servers." },
    { key: "fabric", label: "Fabric", logo: fabric, hint: "Lightweight mod loader." },
    { key: "forge", label: "Forge", logo: forge, hint: "Classic mod loader for big modpacks." },
    { key: "neoforge", label: "NeoForge", logo: neoforge, hint: "Modern Forge fork for new mods." },
    { key: "spigot", label: "SpigotMC", logo: spigot, hint: "Plugin server, Bukkit compatible." },
    { key: "vanilla", label: "Vanilla", logo: vanilla, hint: "The official Mojang server." },
  ],
  hytale: [{ key: "default", label: "Hytale server", hint: "Official dedicated server." }],
  cs2: [{ key: "default", label: "CS2 dedicated server", hint: "Steam dedicated server." }],
  rust: [{ key: "default", label: "Rust dedicated server", hint: "Official Facepunch server." }],
  palworld: [{ key: "default", label: "Palworld dedicated server", hint: "Official Pocketpair server." }],
  ark: [
    { key: "ascended", label: "ARK: Survival Ascended", hint: "The Unreal Engine 5 remaster." },
    { key: "evolved", label: "ARK: Survival Evolved", hint: "The original, with a huge mod library." },
  ],
  gmod: [{ key: "default", label: "Garry's Mod server", hint: "Source dedicated server." }],
  bot: [
    { key: "nodejs", label: "Node.js", hint: "discord.js, Eris and other JavaScript bots." },
    { key: "python", label: "Python", hint: "discord.py, Pycord, nextcord bots." },
  ],
  vps: [
    { key: "ubuntu-26.10", label: "Ubuntu 26.10", hint: "Latest Ubuntu release." },
    { key: "ubuntu-26.04", label: "Ubuntu 26.04 LTS", hint: "Long-term support." },
    { key: "ubuntu-24.04", label: "Ubuntu 24.04 LTS", hint: "Most popular choice." },
    { key: "ubuntu-22.04", label: "Ubuntu 22.04 LTS", hint: "Long-term support." },
    { key: "debian-13", label: "Debian 13", hint: "Current stable release." },
    { key: "debian-12", label: "Debian 12", hint: "Stable and minimal." },
  ],
};

export const minecraftVersions = ["latest", "26.3", "26.2", "26.1", "1.21.11", "1.21.10", "1.21.8", "1.21.5", "1.21.4", "1.21.1", "1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.17.1", "1.16.5", "1.12.2", "1.8.8"];

export const softwareFor = (product: ProductKey) => softwareCatalog[product];
export const softwareLabel = (product: string, key: string | null | undefined) =>
  softwareCatalog[product as ProductKey]?.find((s) => s.key === key)?.label ?? key ?? "-";

/** Every Pterodactyl-backed software choice, as "product:software" keys for the admin egg mapping. */
export const panelSoftwareKeys = (Object.keys(softwareCatalog) as ProductKey[])
  .filter((p) => p !== "vps")
  .flatMap((p) => softwareCatalog[p].map((s) => ({ key: `${p}:${s.key}`, product: p, label: s.label })));

/** Short descriptions for the supported software strip on each game page. */
export const softwareDetails: Record<string, { blurb: string; tag: string }> = {
  PaperMC: { blurb: "High performance fork of Spigot with smarter chunk loading and huge plugin support.", tag: "Plugins" },
  Fabric: { blurb: "Lightweight, fast-updating mod loader loved for performance and QoL mods.", tag: "Mods" },
  Forge: { blurb: "The classic mod loader behind most big modpacks and tech packs.", tag: "Modpacks" },
  SpigotMC: { blurb: "Battle tested Bukkit compatible server for plugin networks and minigames.", tag: "Plugins" },
  NeoForge: { blurb: "Modern community fork of Forge for the newest Minecraft mods.", tag: "Mods" },
  Vanilla: { blurb: "The official Mojang server. Pure survival, exactly as intended.", tag: "Official" },
  "Hytale dedicated server": { blurb: "The official dedicated server, ready for adventure worlds and friends.", tag: "Official" },
  "Custom mods": { blurb: "Drop in community mods and custom content to shape your world.", tag: "Mods" },
  Plugins: { blurb: "Extend gameplay with server-side plugins, permissions and tools.", tag: "Plugins" },
  "Sandbox and TTT": { blurb: "Sandbox and Trouble in Terrorist Town ship with the game and are ready to pick at checkout.", tag: "Gamemodes" },
  Competitive: { blurb: "Competitive configs for scrims, PUGs and practice.", tag: "Mode" },
  Wingman: { blurb: "Two versus two on compact maps for quick practice matches.", tag: "Mode" },
  Deathmatch: { blurb: "Aim warm-ups and FFA deathmatch with instant respawns.", tag: "Mode" },
  "Arms Race": { blurb: "Gun game rounds where every kill upgrades your weapon.", tag: "Mode" },
  CounterStrikeSharp: { blurb: "Metamod and CounterStrikeSharp plugins for CS2 communities.", tag: "Plugins" },
  "Rust dedicated server": { blurb: "The official Facepunch server, kept up to date on every restart.", tag: "Official" },
  "Oxide and Carbon": { blurb: "Pick Oxide (uMod) or Carbon at checkout and add kits, teleports, clans and more.", tag: "Plugins" },
  "Procedural maps": { blurb: "Pick your world size and seed for a fresh map every wipe.", tag: "Maps" },
  "Palworld dedicated server": { blurb: "The official Pocketpair server for co-op and PvP worlds with up to 32 players.", tag: "Official" },
  "World settings": { blurb: "Tune capture rates, EXP, day length and raids from one settings file.", tag: "Config" },
  Crossplay: { blurb: "Steam, Xbox, PlayStation 5 and Mac players can all join the same world.", tag: "Crossplay" },
  "Save transfers": { blurb: "Upload your existing co-op world and keep every Pal you caught.", tag: "Worlds" },
  "ARK: Survival Ascended": { blurb: "The Unreal Engine 5 remaster with cross-platform mods through CurseForge.", tag: "Official" },
  "ARK: Survival Evolved": { blurb: "The original ARK server with its huge Steam Workshop mod library.", tag: "Official" },
  "Official maps": { blurb: "Seven official maps on Ascended and all twelve on Evolved, from The Island to Fjordur.", tag: "Maps" },
  Mods: { blurb: "Add CurseForge mods on Ascended or Steam Workshop mods on Evolved by their IDs.", tag: "Mods" },
  "Garry's Mod server": { blurb: "The Source dedicated server for sandbox, roleplay and minigame communities.", tag: "Official" },
  "Workshop collections": { blurb: "Add a Steam Workshop collection ID and its addons, maps and gamemodes like DarkRP load on start.", tag: "Addons" },
};
