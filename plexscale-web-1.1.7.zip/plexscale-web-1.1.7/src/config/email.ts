import { z } from "zod";

/** Every email the site can send. Admins edit the subject and text of each in Administrator. */
export const templateKeys = ["welcome", "purchase", "renewal", "upgrade", "credits", "expiry7", "expiry1", "ticketCreated", "ticketReply", "staffTicketAlert"] as const;
export type TemplateKey = (typeof templateKeys)[number];

export const templateMeta: Record<TemplateKey, { label: string; when: string; vars: string[]; invoice?: boolean }> = {
  welcome: { label: "Welcome", when: "First time someone signs in", vars: ["name", "email", "site_url", "support_url"] },
  purchase: { label: "Purchase receipt", when: "A new service is paid for (invoice PDF attached)", vars: ["name", "service_name", "plan_name", "amount", "billing", "invoice_number", "expiry_date", "billing_url", "support_url"], invoice: true },
  renewal: { label: "Renewal receipt", when: "A renewal is paid for (invoice PDF attached)", vars: ["name", "service_name", "plan_name", "amount", "billing", "invoice_number", "expiry_date", "billing_url", "support_url"], invoice: true },
  upgrade: { label: "Upgrade receipt", when: "A plan upgrade is paid for (invoice PDF attached)", vars: ["name", "service_name", "plan_name", "previous_plan", "amount", "invoice_number", "expiry_date", "billing_url", "support_url"], invoice: true },
  credits: { label: "Credits receipt", when: "A credit top-up is paid for (invoice PDF attached)", vars: ["name", "amount", "balance", "invoice_number", "billing_url", "support_url"], invoice: true },
  expiry7: { label: "Expiry reminder, 7 days", when: "7 days before a service expires", vars: ["name", "service_name", "plan_name", "expiry_date", "days_left", "amount", "billing_url", "support_url"] },
  expiry1: { label: "Expiry reminder, 1 day", when: "1 day before a service expires", vars: ["name", "service_name", "plan_name", "expiry_date", "days_left", "amount", "billing_url", "support_url"] },
  ticketCreated: { label: "Ticket received", when: "A customer opens a support ticket", vars: ["name", "ticket_number", "ticket_subject", "ticket_url"] },
  ticketReply: { label: "Ticket reply", when: "Staff reply to a customer’s ticket", vars: ["name", "ticket_number", "ticket_subject", "reply_excerpt", "ticket_url"] },
  staffTicketAlert: { label: "Staff ticket alert", when: "A customer opens or replies to a ticket (sent to the staff inbox)", vars: ["customer_email", "ticket_number", "ticket_subject", "ticket_category", "ticket_priority", "reply_excerpt", "admin_url"] },
};

const templateSchema = z.object({
  enabled: z.boolean(),
  subject: z.string().trim().min(1).max(160),
  body: z.string().trim().min(1).max(5000),
});
type EmailTemplate = z.infer<typeof templateSchema>;

const emailAddress = z.string().trim().toLowerCase().max(120).email();
const hostname = z.string().trim().toLowerCase().max(253).regex(/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/, "Use a host name such as smtp.example.com");
/** Display names may not contain characters that could break an email header. */
const headerSafe = (max: number) => z.string().trim().max(max).regex(/^[^\r\n<>"\\]*$/, "Remove line breaks, quotes and angle brackets");

/** Admin-editable email settings, without the stored secrets. */
export const emailSettingsSchema = z.object({
  smtp: z.object({
    enabled: z.boolean(),
    host: z.union([z.literal(""), hostname]),
    port: z.number().int().min(1).max(65535),
    security: z.enum(["starttls", "tls"]),
    username: z.string().trim().max(200).regex(/^[^\r\n]*$/),
    fromName: headerSafe(80),
    fromEmail: z.union([z.literal(""), emailAddress]),
    replyTo: z.union([z.literal(""), emailAddress]),
  }),
  staffEmail: z.union([z.literal(""), emailAddress]),
  discord: z.object({
    enabled: z.boolean(),
    notifyNewTickets: z.boolean(),
    notifyReplies: z.boolean(),
    roleId: z.union([z.literal(""), z.string().regex(/^\d{5,25}$/, "Use the numeric role ID")]),
  }),
  invoice: z.object({
    businessName: headerSafe(100),
    address: z.string().trim().max(300),
    gstin: z.union([z.literal(""), z.string().trim().toUpperCase().regex(/^[0-9]{2}[A-Z0-9]{13}$/, "GSTIN has 15 characters")]),
    email: z.union([z.literal(""), emailAddress]),
    note: z.string().trim().max(300),
  }),
  templates: z.object(Object.fromEntries(templateKeys.map((k) => [k, templateSchema])) as Record<TemplateKey, typeof templateSchema>),
});
export type EmailSettings = z.infer<typeof emailSettingsSchema>;

/** What the admin form sends: settings plus optional secret changes. Blank secrets keep the stored value. */
export const emailSettingsInput = emailSettingsSchema.extend({
  smtpPassword: z.string().max(500).regex(/^[^\r\n]*$/).optional(),
  clearSmtpPassword: z.boolean().optional(),
  discordWebhookUrl: z.string().trim().max(300).regex(/^https:\/\/(?:canary\.|ptb\.)?discord(?:app)?\.com\/api\/webhooks\/\d{5,25}\/[A-Za-z0-9_-]{20,120}$/, "Paste a Discord webhook address").optional(),
  clearDiscordWebhook: z.boolean().optional(),
});

const sign = "\n\nThanks,\nThe PlexScale team";

export const defaultTemplates: Record<TemplateKey, EmailTemplate> = {
  welcome: { enabled: true, subject: "Welcome to PlexScale, {{name}}", body: `Hi {{name}},\n\nYour PlexScale account is ready. Deploy game servers, VPS and bot hosting on tuned AMD EPYC hardware in about a minute.\n\nGet started: {{site_url}}\n\nNeed a hand? Open a support ticket any time: {{support_url}}${sign}` },
  purchase: { enabled: true, subject: "Payment received: {{service_name}} (Invoice {{invoice_number}})", body: `Hi {{name}},\n\nThanks for your order. We received {{amount}} for {{plan_name}} ({{billing}}).\n\nService: {{service_name}}\nPaid until: {{expiry_date}}\nInvoice: {{invoice_number}} (attached as PDF)\n\nManage your services: {{billing_url}}${sign}` },
  renewal: { enabled: true, subject: "Renewal confirmed: {{service_name}} (Invoice {{invoice_number}})", body: `Hi {{name}},\n\nYour renewal of {{service_name}} is confirmed. We received {{amount}}.\n\nNew expiry date: {{expiry_date}}\nInvoice: {{invoice_number}} (attached as PDF)\n\nManage your services: {{billing_url}}${sign}` },
  upgrade: { enabled: true, subject: "Upgrade complete: {{service_name}} is now on {{plan_name}}", body: `Hi {{name}},\n\n{{service_name}} has been upgraded from {{previous_plan}} to {{plan_name}}. We received {{amount}} for the remaining time on your billing period.\n\nPaid until: {{expiry_date}} (unchanged)\nInvoice: {{invoice_number}} (attached as PDF)\n\nRestart your server from the panel if the new resources are not visible yet.${sign}` },
  credits: { enabled: true, subject: "Credits added: {{amount}} (Invoice {{invoice_number}})", body: `Hi {{name}},\n\nWe added {{amount}} in PlexScale Credits to your account. Your balance is now {{balance}}.\n\nUse credits to pay for new servers, renewals and upgrades: {{billing_url}}\nInvoice: {{invoice_number}} (attached as PDF)${sign}` },
  expiry7: { enabled: true, subject: "{{service_name}} expires in 7 days", body: `Hi {{name}},\n\nA friendly reminder: {{service_name}} ({{plan_name}}) expires on {{expiry_date}}.\n\nRenew now to keep it online: {{billing_url}}\n\nNothing renews automatically, so no action means the service is suspended after it expires.${sign}` },
  expiry1: { enabled: true, subject: "Last day: {{service_name}} expires tomorrow", body: `Hi {{name}},\n\n{{service_name}} ({{plan_name}}) expires on {{expiry_date}}. Renew today to avoid any interruption.\n\nRenew now: {{billing_url}}\n\nQuestions? Open a ticket: {{support_url}}${sign}` },
  ticketCreated: { enabled: true, subject: "[Ticket #{{ticket_number}}] {{ticket_subject}}", body: `Hi {{name}},\n\nWe received your ticket #{{ticket_number}} and our team will reply shortly. You will get an email as soon as we respond.\n\nView your ticket: {{ticket_url}}${sign}` },
  ticketReply: { enabled: true, subject: "[Ticket #{{ticket_number}}] New reply from PlexScale support", body: `Hi {{name}},\n\nOur team replied to your ticket #{{ticket_number}} ({{ticket_subject}}):\n\n{{reply_excerpt}}\n\nRead and reply: {{ticket_url}}${sign}` },
  staffTicketAlert: { enabled: true, subject: "[Ticket #{{ticket_number}}] {{ticket_subject}}", body: `New activity on ticket #{{ticket_number}}.\n\nFrom: {{customer_email}}\nCategory: {{ticket_category}} · Priority: {{ticket_priority}}\n\n{{reply_excerpt}}\n\nOpen in Administrator: {{admin_url}}` },
};

const defaultEmailSettings: EmailSettings = {
  smtp: { enabled: false, host: "", port: 587, security: "starttls", username: "", fromName: "PlexScale", fromEmail: "", replyTo: "" },
  staffEmail: "",
  discord: { enabled: false, notifyNewTickets: true, notifyReplies: true, roleId: "" },
  invoice: { businessName: "PlexScale", address: "Mumbai, India (400001)", gstin: "", email: "", note: "All amounts are in Indian Rupees and inclusive of applicable taxes." },
  templates: defaultTemplates,
};

/** Never throws: bad or missing sections fall back to defaults, and every template is always present. */
export function normalizeEmailSettings(raw: unknown): EmailSettings {
  const src = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const out: Record<string, unknown> = {};
  for (const key of ["smtp", "staffEmail", "discord", "invoice"] as const) {
    const fallback = defaultEmailSettings[key];
    const value = src[key];
    const merged = fallback && typeof fallback === "object" && value && typeof value === "object" ? { ...fallback, ...value } : value ?? fallback;
    const r = emailSettingsSchema.shape[key].safeParse(merged);
    out[key] = r.success ? r.data : fallback;
  }
  const rawTemplates = (src["templates"] && typeof src["templates"] === "object" ? src["templates"] : {}) as Record<string, unknown>;
  const templates = {} as Record<TemplateKey, EmailTemplate>;
  for (const k of templateKeys) {
    const r = templateSchema.safeParse(rawTemplates[k]);
    templates[k] = r.success ? r.data : defaultTemplates[k];
  }
  out["templates"] = templates;
  return out as EmailSettings;
}

// ---------- Rendering (shared by the server and the admin preview) ----------

const escapeHtml = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);

/** Replaces {{placeholders}}. Unknown placeholders are left blank so nothing leaks. */
function fillTemplate(text: string, vars: Record<string, string>) {
  return text.replace(/\{\{\s*([a-z_]{1,40})\s*\}\}/g, (_m, k: string) => vars[k] ?? "");
}

/** Subject lines are single-line, plain text. */
export function renderSubject(subject: string, vars: Record<string, string>) {
  return fillTemplate(subject, vars).replace(/[\r\n\t]+/g, " ").replace(/\s{2,}/g, " ").trim().slice(0, 200);
}

/** Plain text body with placeholders filled. */
export function renderText(body: string, vars: Record<string, string>) {
  return fillTemplate(body, vars).replace(/\r\n?/g, "\n").trim();
}

/** Branded HTML. Every value is escaped; only https links are turned into links. */
export function renderHtml(body: string, vars: Record<string, string>, opts: { preheader?: string; siteUrl?: string; logoUrl?: string } = {}) {
  const text = renderText(body, vars);
  const linkify = (escaped: string) => escaped.replace(/https:\/\/[^\s<>"']{1,500}/g, (u) => {
    const clean = u.replace(/[.,;:!?)]+$/, "");
    const tail = u.slice(clean.length);
    return `<a href="${clean}" style="color:#76b4ff;text-decoration:underline;word-break:break-all">${clean}</a>${tail}`;
  });
  const paragraphs = text.split(/\n{2,}/).map((p) => `<p style="margin:0 0 16px;line-height:1.6">${linkify(escapeHtml(p)).replace(/\n/g, "<br>")}</p>`).join("");
  const pre = escapeHtml((opts.preheader ?? "").slice(0, 140));
  const site = escapeHtml(opts.siteUrl ?? "https://plexscale.com");
  // PNG (not WebP) so the logo shows in Outlook and older mail apps; the alt text keeps the brand when images are blocked.
  const logo = escapeHtml(opts.logoUrl ?? `${opts.siteUrl ?? "https://plexscale.com"}/email/plexscale-logo.png`);
  // Black theme to match the site: page #060609, card #0e0f13, hairline #22252b, blue logo and links.
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark"><meta name="supported-color-schemes" content="dark"><title>PlexScale</title></head>
<body style="margin:0;padding:0;background:#060609;font-family:Arial,Helvetica,sans-serif;color:#f8f8fa">
<div style="display:none;max-height:0;overflow:hidden;opacity:0">${pre}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#060609"><tr><td align="center" style="padding:32px 16px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px">
<tr><td style="background:#060609;border:1px solid #22252b;border-bottom:3px solid #2563eb;border-radius:12px 12px 0 0;padding:22px 28px"><a href="${site}" style="text-decoration:none"><img src="${logo}" width="159" height="28" alt="PlexScale" style="display:block;border:0;outline:none;height:28px;width:159px;max-width:100%;color:#f8f8fa;font-size:20px;font-weight:700"></a></td></tr>
<tr><td style="background:#0e0f13;border:1px solid #22252b;border-top:0;border-radius:0 0 12px 12px;padding:28px;font-size:15px;color:#e6e8ec">${paragraphs}</td></tr>
<tr><td style="padding:18px 8px;font-size:12px;color:#a6abb3;text-align:center">PlexScale · Game servers, VPS and bot hosting · <a href="${site}" style="color:#a6abb3">${site.replace(/^https:\/\//, "")}</a></td></tr>
</table></td></tr></table></body></html>`;
}

export const sampleVars: Record<string, string> = {
  name: "Aarav", email: "aarav@example.com", customer_email: "aarav@example.com", site_url: "https://plexscale.com", support_url: "https://plexscale.com/support",
  service_name: "Survival SMP", plan_name: "Mark 3", previous_plan: "Mark 2", amount: "₹279", billing: "Monthly", invoice_number: "PX-1001",
  expiry_date: "12 Dec 2026", days_left: "7", billing_url: "https://plexscale.com/billing", ticket_number: "10001", ticket_subject: "Server not starting",
  ticket_category: "Technical", ticket_priority: "High", ticket_url: "https://plexscale.com/support/…", reply_excerpt: "We restarted the node and your server is back online.", admin_url: "https://plexscale.com/administrator",
};
