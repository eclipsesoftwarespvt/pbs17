// Fixed brand facts. Links, contact details, banners and status live in site settings (Administrator).
export const site = {
  name: "PlexScale",
  domain: "plexscale.com",
  url: "https://plexscale.com",
  responseTime: "Average Response Time: 60 seconds",
  legalName: "PlexScale",
  blurb: "Fast game servers, VPS and bot hosting on tuned AMD EPYC hardware, at honest prices.",
  statusUrl: "https://status.plexscale.com",
  trustpilotUrl: "https://www.trustpilot.com/review/plexscale.com",
  trustpilotScore: 4.2,
  copyright: "© PlexScale. All Rights Reserved.",
};

export const specs = [
  { label: "Storage", value: "NVMe Gen 4 SSD" },
  { label: "Uplink", value: "10 Gbps+" },
  { label: "DDoS protection", value: "L3/L4/L7, up to 480 Gbps" },
  { label: "Uptime target", value: "99.95%*" },
];

/** Processors in the fleet, newest first. Servers land on whichever fits the location and current availability. */
export const cpus = [
  { model: "AMD EPYC 9V74", series: "EPYC 9000 series", clock: "3.70 GHz", memory: "DDR5 4800 MHz", note: "Our newest and fastest nodes. Zen 4 cores with DDR5 memory for the highest tick rates." },
  { model: "AMD EPYC 7763", series: "EPYC 7000 series", clock: "3.50 GHz", memory: "DDR4 3200 MHz", note: "The proven workhorse. Strong single-core speed that game servers love." },
  { model: "AMD EPYC 7V12", series: "EPYC 7000 series", clock: "3.35 GHz", memory: "DDR4 3200 MHz", note: "Our baseline, and still serious server-grade power for any plan." },
];

/** The minimum every server is guaranteed, whatever node it lands on. */
export const hardwareFloor = "Your server is placed on the best node available in your location. Every plan gets at least an AMD EPYC at 3.35 GHz with DDR4 3200 MHz memory.";

interface Location {
  id: string;
  city: string;
  region: string;
  country: string;
  x: number; // percent across map
  y: number;
  mockPing: number;
}

export const locations: Location[] = [
  { id: "mumbai", city: "Mumbai", region: "India", country: "IN", x: 34, y: 56, mockPing: 12 },
  { id: "virginia", city: "Virginia", region: "United States", country: "US", x: 10, y: 30, mockPing: 210 },
  { id: "hyderabad", city: "Hyderabad", region: "India", country: "IN", x: 39, y: 59, mockPing: 15 },
  { id: "dubai", city: "Dubai", region: "UAE", country: "AE", x: 23, y: 48, mockPing: 46 },
  { id: "frankfurt", city: "Frankfurt", region: "Germany", country: "DE", x: 8, y: 22, mockPing: 128 },
];

