export type Billing = "monthly" | "quarterly" | "semiannual" | "yearly";
export type GameKey = "minecraft" | "hytale" | "cs2" | "rust" | "palworld" | "ark" | "gmod";

export const billingPeriods: { key: Billing; label: string; months: number; discount: number }[] = [
  { key: "monthly", label: "Monthly", months: 1, discount: 0 },
  { key: "quarterly", label: "Quarterly", months: 3, discount: 0.05 },
  { key: "semiannual", label: "Semi-annually", months: 6, discount: 0.1 },
  { key: "yearly", label: "Yearly", months: 12, discount: 0.15 },
];

export interface Plan {
  id: string;
  name: string;
  ramGb: number;
  ramLabel: string;
  diskGb: number;
  storage: string;
  monthly: number;
  /** CPU allowance in percent; 100% = 1 vCore. */
  cpuPercent: number;
  /** Dedicated vCPU cores (VPS only). */
  vcpu?: number;
  popular?: boolean;
  deploy?: DeployValues;
  /** Admin-written lines for the plan card. When set they replace the generated spec and feature lines. */
  lines?: string[];
}

/** Admin-editable changes to a built-in plan, keyed by plan id in site settings. */
export interface PlanOverride {
  /** Set on plans an admin created; built-in plans leave this empty. */
  product?: string | undefined;
  custom?: boolean | undefined;
  name?: string | undefined;
  vcpu?: number | undefined;
  monthly?: number | undefined;
  cpuPercent?: number | undefined;
  ramGb?: number | undefined;
  diskGb?: number | undefined;
  hidden?: boolean | undefined;
  popular?: boolean | undefined;
  /** Exact Pterodactyl values used when the server is created. Empty fields fall back to the plan specs and panel defaults. */
  deploy?: DeployValues | undefined;
  /** Custom plan card lines ("Label: value" renders the label muted). Replaces the generated lines. */
  lines?: string[] | undefined;
}

export interface DeployValues {
  memoryMib?: number | undefined;
  diskMib?: number | undefined;
  cpu?: number | undefined;
  swapMib?: number | undefined;
  io?: number | undefined;
  threads?: string | undefined;
  databases?: number | undefined;
  backups?: number | undefined;
  allocations?: number | undefined;
}

export const deployFields: { key: keyof DeployValues; label: string; text?: boolean }[] = [
  { key: "memoryMib", label: "RAM (MiB)" },
  { key: "diskMib", label: "Disk (MiB)" },
  { key: "cpu", label: "CPU limit %" },
  { key: "swapMib", label: "Swap (MiB)" },
  { key: "io", label: "IO weight" },
  { key: "threads", label: "CPU threads", text: true },
  { key: "databases", label: "Databases" },
  { key: "backups", label: "Backups" },
  { key: "allocations", label: "Ports" },
];

/** Panel limits for a plan: explicit deploy values win over the plan's GB specs. */
export function deployLimits(p: Plan) {
  const d = p.deploy ?? {};
  return { memoryMib: d.memoryMib ?? Math.round(p.ramGb * 1024), diskMib: d.diskMib ?? p.diskGb * 1024, cpu: d.cpu ?? p.cpuPercent };
}

const ramLabelFor = (gb: number) => (gb < 1 ? `${Math.round(gb * 1024)} MB` : `${gb} GB`);

function mk(id: string, name: string, cpuPercent: number, ramGb: number, diskGb: number, monthly: number, vcpu?: number): Plan {
  return { id, name, cpuPercent, ramGb, ramLabel: ramLabelFor(ramGb), diskGb, storage: `${diskGb} GB`, monthly, ...(vcpu ? { vcpu } : {}) };
}

/** Plan tiers per game as [tier, RAM GB, CPU %, NVMe GB, INR/month]. The tier keeps ids and names stable per RAM size. */
const gameTables: Record<GameKey, [number, number, number, number, number][]> = {
  minecraft: [[1, 2, 100, 8, 99], [2, 4, 150, 16, 199], [3, 6, 200, 24, 279], [4, 8, 250, 32, 379], [5, 12, 300, 64, 529], [6, 16, 350, 72, 699], [7, 24, 400, 96, 999], [8, 32, 500, 128, 1299]],
  hytale: [[2, 4, 150, 16, 249], [3, 6, 200, 24, 349], [4, 8, 250, 32, 449], [5, 12, 300, 64, 649], [6, 16, 350, 72, 849]],
  cs2: [[1, 2, 100, 64, 149], [2, 4, 150, 72, 249], [3, 6, 200, 80, 349], [4, 8, 250, 96, 449]],
  rust: [[1, 8, 200, 32, 599], [2, 12, 250, 64, 749], [3, 16, 300, 72, 949], [4, 24, 400, 96, 1149]],
  palworld: [[4, 8, 200, 32, 479], [5, 12, 250, 64, 679], [6, 16, 300, 72, 899], [7, 24, 400, 96, 1299], [8, 32, 500, 128, 1649]],
  ark: [[5, 12, 250, 64, 749], [6, 16, 300, 72, 999], [7, 24, 400, 96, 1399], [8, 32, 500, 128, 1799]],
  gmod: [[1, 2, 100, 16, 99], [2, 4, 150, 24, 199], [3, 6, 200, 32, 279], [4, 8, 250, 64, 379], [5, 12, 300, 72, 549]],
};

const gameSeries: Record<GameKey, string> = { minecraft: "Mark", hytale: "Tale", cs2: "Strike", rust: "Raid", palworld: "Pal", ark: "Primal", gmod: "Sandbox" };

export function gamePlans(game: GameKey): Plan[] {
  const series = gameSeries[game];
  return gameTables[game].map(([tier, ram, cpu, disk, price]) => mk(`${series.toLowerCase()}-${tier}`, `${series} ${tier}`, cpu, ram, disk, price));
}

export const vpsPlans: Plan[] = [
  mk("vps-8", "VPS 8", 200, 8, 64, 599, 2),
  mk("vps-16", "VPS 16", 200, 16, 96, 949, 2),
  mk("vps-32", "VPS 32", 400, 32, 128, 1849, 4),
  mk("vps-64", "VPS 64", 800, 64, 256, 3399, 8),
];

export const botPlans: Plan[] = [
  mk("bot-1", "BOT 1", 25, 1, 4, 59),
  mk("bot-2", "BOT 2", 50, 2, 6, 99),
  mk("bot-3", "BOT 3", 75, 3, 8, 129),
  mk("bot-4", "BOT 4", 100, 4, 10, 159),
];

/** "150% CPU" style label. */
export const cpuLabel = (p: Plan) => `${p.cpuPercent}% CPU`;
/** vCore equivalent, e.g. 150% -> "1.50 vCores". */
const vcoreLabel = (p: Plan) => p.vcpu ? `${p.vcpu} dedicated vCPU cores` : `${(p.cpuPercent / 100).toFixed(2)} vCore${p.cpuPercent === 100 ? "" : "s"}`;

/** Total charged for the period, rounded to the nearest rupee. */
export function periodTotal(monthly: number, billing: Billing): number {
  const p = billingPeriods.find((b) => b.key === billing)!;
  return Math.round(monthly * p.months * (1 - p.discount));
}

/** Adds calendar months in UTC and stops at the end of a short month (31 Jan + 1 month = 28/29 Feb), like the database does. */
export function addMonthsClamped(from: Date, months: number): Date {
  const d = new Date(from);
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const lastDay = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, lastDay));
  return d;
}

export const periodMonths = (billing: Billing) => billingPeriods.find((b) => b.key === billing)!.months;

const inr = new Intl.NumberFormat("en-IN");
export const formatINR = (n: number) => `₹${inr.format(n)}`;

export const periodSuffix: Record<Billing, string> = { monthly: "/mo", quarterly: "/quarter", semiannual: "/6 months", yearly: "/year" };

/** Customer-facing name of a billing period, e.g. "Semi-annually". */
export const billingLabel = (b: string) => billingPeriods.find((p) => p.key === b)?.label ?? b;

/**
 * Lines shown on a plan card and in the order summary. Admin-written lines win;
 * otherwise CPU, RAM, disk (and IPv4 for VPS) plus up to two product features.
 */
export function planLines(p: Plan, features: string[] = []): string[] {
  if (p.lines && p.lines.length) return p.lines;
  return [
    `CPU: ${p.vcpu ? vcoreLabel(p) : `${cpuLabel(p)} (${vcoreLabel(p)})`}`,
    `RAM: ${p.ramLabel} DDR4/DDR5 memory`,
    `Disk: ${p.storage} NVMe SSD`,
    ...(p.vcpu ? ["IP: 1x Dedicated IPv4"] : []),
    ...features.slice(0, 2),
  ];
}

export function fromPrice(plans: Plan[]) {
  return plans.length ? Math.min(...plans.map((p) => p.monthly)) : 0;
}

export type ProductKey = GameKey | "vps" | "bot";
export const gameKeys: GameKey[] = ["minecraft", "hytale", "cs2", "rust", "palworld", "ark", "gmod"];
export const productKeys: ProductKey[] = [...gameKeys, "vps", "bot"];
export const productNames: Record<ProductKey, string> = { minecraft: "Minecraft", hytale: "Hytale", cs2: "Counter Strike 2", rust: "Rust", palworld: "Palworld", ark: "ARK: Survival", gmod: "Garry's Mod", vps: "VPS", bot: "Bot Hosting" };
export const isProduct = (v: unknown): v is ProductKey => typeof v === "string" && (productKeys as string[]).includes(v);

function plansFor(product: string): Plan[] {
  if (product === "vps") return vpsPlans;
  if (product === "bot") return botPlans;
  if (isGame(product)) return gamePlans(product);
  return [];
}

/** Built-in plan lookup, without admin overrides. */
function applyOverride(p: Plan, o?: PlanOverride): Plan {
  if (!o) return p;
  const ramGb = o.ramGb ?? p.ramGb;
  const diskGb = o.diskGb ?? p.diskGb;
  const vcpu = o.vcpu ?? p.vcpu;
  const cpuPercent = vcpu ? vcpu * 100 : o.cpuPercent ?? p.cpuPercent;
  return {
    ...p,
    name: o.name?.trim() || p.name,
    monthly: o.monthly ?? p.monthly,
    cpuPercent,
    ramGb,
    ramLabel: ramLabelFor(ramGb),
    diskGb,
    storage: `${diskGb} GB`,
    ...(vcpu ? { vcpu } : {}),
    ...(o.popular !== undefined ? { popular: o.popular } : {}),
    ...(o.deploy ? { deploy: o.deploy } : {}),
    ...(o.lines && o.lines.length ? { lines: o.lines } : {}),
  };
}

/** Plans a customer can buy right now: built-in table plus admin changes, hidden plans removed. */
export function effectivePlans(product: string, overrides: Record<string, PlanOverride> = {}, includeHidden = false): Plan[] {
  const builtIn = plansFor(product).map((p) => applyOverride(p, overrides[p.id]));
  const builtInIds = new Set(builtIn.map((p) => p.id));
  const custom = Object.entries(overrides)
    .filter(([id, o]) => o.custom && o.product === product && !builtInIds.has(id))
    .map(([id, o]) => customPlan(id, product, o));
  return [...builtIn, ...custom]
    .filter((p) => includeHidden || !overrides[p.id]?.hidden)
    .sort((a, b) => a.monthly - b.monthly);
}

/** Builds a full plan from an admin-created entry. */
function customPlan(id: string, product: string, o: PlanOverride): Plan {
  const base = mk(id, o.name?.trim() || "New plan", o.cpuPercent ?? 100, o.ramGb ?? 4, o.diskGb ?? 40, o.monthly ?? 199, product === "vps" ? o.vcpu ?? 2 : undefined);
  return applyOverride(base, o);
}

export const isGame = (p: string): p is GameKey => (gameKeys as string[]).includes(p);

/** Server and cart share this lookup so the charged price always comes from the same rules. */
export function findEffectivePlan(product: string, planId: string, overrides: Record<string, PlanOverride> = {}): Plan | undefined {
  return effectivePlans(product, overrides).find((p) => p.id === planId);
}

export function isBilling(v: unknown): v is Billing {
  return v === "monthly" || v === "quarterly" || v === "semiannual" || v === "yearly";
}
