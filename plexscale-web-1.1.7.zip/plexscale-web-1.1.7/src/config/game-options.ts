import { z } from "zod";

/** Counter Strike 2 match presets, as the CS2 egg's GAME_TYPE / GAME_MODE pairs. */
export const cs2Modes = {
  competitive: { label: "Competitive", type: "0", mode: "1", players: 12 },
  casual: { label: "Casual", type: "0", mode: "0", players: 20 },
  wingman: { label: "Wingman", type: "0", mode: "2", players: 6 },
  deathmatch: { label: "Deathmatch", type: "1", mode: "2", players: 16 },
  armsrace: { label: "Arms Race", type: "1", mode: "0", players: 16 },
} as const;
export type Cs2Mode = keyof typeof cs2Modes;
export const cs2Maps = ["de_dust2", "de_mirage", "de_inferno", "de_nuke", "de_ancient", "de_anubis", "de_overpass", "de_vertigo", "de_train", "cs_italy", "cs_office", "ar_baggage", "ar_shoots"] as const;
export const rustWorldSizes = [2000, 2500, 3000, 3500, 4000, 4500] as const;
export const hytalePatchlines = { release: "Release", "pre-release": "Pre-release" } as const;

/** Rust mod frameworks the Rust egg installs through its FRAMEWORK variable. */
export const rustFrameworks = { vanilla: "Vanilla", oxide: "Oxide (uMod)", carbon: "Carbon" } as const;
export type RustFramework = keyof typeof rustFrameworks;

export type ArkEdition = "ascended" | "evolved";
/** Official ARK maps, with each egg's SERVER_MAP name. A missing edition means the map is not on it. */
export const arkMaps: Record<string, { label: string } & Partial<Record<ArkEdition, string>>> = {
  island: { label: "The Island", ascended: "TheIsland_WP", evolved: "TheIsland" },
  center: { label: "The Center", ascended: "TheCenter_WP", evolved: "TheCenter" },
  scorched: { label: "Scorched Earth", ascended: "ScorchedEarth_WP", evolved: "ScorchedEarth_P" },
  ragnarok: { label: "Ragnarok", ascended: "Ragnarok_WP", evolved: "Ragnarok" },
  aberration: { label: "Aberration", ascended: "Aberration_WP", evolved: "Aberration_P" },
  extinction: { label: "Extinction", ascended: "Extinction_WP", evolved: "Extinction" },
  valguero: { label: "Valguero", ascended: "Valguero_WP", evolved: "Valguero_P" },
  genesis: { label: "Genesis Part 1", evolved: "Genesis" },
  crystal: { label: "Crystal Isles", evolved: "CrystalIsles" },
  genesis2: { label: "Genesis Part 2", evolved: "Gen2" },
  lost: { label: "Lost Island", evolved: "LostIsland" },
  fjordur: { label: "Fjordur", evolved: "Fjordur" },
};

export const arkEdition = (software: string | undefined): ArkEdition => (software === "evolved" ? "evolved" : "ascended");
/** Map keys offered on an ARK edition, in display order. */
export const arkMapsFor = (edition: ArkEdition) => Object.keys(arkMaps).filter((k) => arkMaps[k]?.[edition]);
/** The egg's SERVER_MAP value, falling back to The Island when the map is not on that edition. */
export const arkMapName = (key: string | undefined, edition: ArkEdition) => (key && Object.hasOwn(arkMaps, key) && arkMaps[key]?.[edition]) || arkMaps["island"]![edition]!;

/** Garry's Mod gamemodes that ship with the game, so the server starts without extra downloads. */
export const gmodGamemodes = { sandbox: "Sandbox", terrortown: "Trouble in Terrorist Town" } as const;
export type GmodGamemode = keyof typeof gmodGamemodes;
export const gmodMaps = ["gm_construct", "gm_flatgrass"] as const;

/** Steam Game Server Login Token: 32 hexadecimal characters (also satisfies the eggs' alpha_num|size:32 rule). */
export const GSLT_RE = /^[A-Fa-f0-9]{32}$/;
/** Join password allowed by the CS2, Palworld and ARK eggs (alpha_dash, 1 to 30). */
export const JOIN_PASSWORD_RE = /^[A-Za-z0-9_-]{1,30}$/;
/** Steam Workshop collection id (the Garry's Mod egg expects a whole number). */
export const WORKSHOP_RE = /^\d{1,12}$/;
export const MAX_SEED = 2_147_483_647;

/** Loose shape accepted from the browser; `gameOptionsIssue` applies the per-game rules. */
export const gameOptionsInput = z.object({
  gslt: z.string().trim().max(64).optional(),
  mode: z.string().max(20).optional(),
  map: z.string().max(40).optional(),
  password: z.string().trim().max(30).optional(),
  worldSize: z.number().int().optional(),
  seed: z.number().int().optional(),
  patchline: z.string().max(20).optional(),
  framework: z.string().max(20).optional(),
  workshop: z.string().trim().max(12).optional(),
}).strict();
export type GameOptionsInput = z.infer<typeof gameOptionsInput>;

export interface GameOptions {
  gslt?: string;
  mode?: Cs2Mode | GmodGamemode;
  map?: string;
  password?: string;
  worldSize?: number;
  seed?: number;
  patchline?: keyof typeof hytalePatchlines;
  framework?: RustFramework;
  workshop?: string;
}

const passwordIssue = (o: GameOptionsInput) =>
  o.password && !JOIN_PASSWORD_RE.test(o.password) ? { path: "password", message: "Join password: up to 30 letters, numbers, dashes or underscores" } : null;

/** First problem with the options for this product, or null when they are fine. */
export function gameOptionsIssue(product: string, o: GameOptionsInput = {}, software?: string): { path: string; message: string } | null {
  if (product === "cs2") {
    if (!o.gslt || !GSLT_RE.test(o.gslt)) return { path: "gslt", message: "Enter your 32 character Steam Game Server Login Token" };
    if (o.mode !== undefined && !Object.hasOwn(cs2Modes, o.mode)) return { path: "mode", message: "Pick a game mode" };
    if (o.map !== undefined && !(cs2Maps as readonly string[]).includes(o.map)) return { path: "map", message: "Pick a map from the list" };
    return passwordIssue(o);
  }
  if (product === "rust") {
    if (o.worldSize !== undefined && !(rustWorldSizes as readonly number[]).includes(o.worldSize)) return { path: "worldSize", message: "Pick a world size from the list" };
    if (o.seed !== undefined && (o.seed < 0 || o.seed > MAX_SEED)) return { path: "seed", message: `Map seed must be between 0 and ${MAX_SEED}` };
    if (o.framework !== undefined && !Object.hasOwn(rustFrameworks, o.framework)) return { path: "framework", message: "Pick a mod framework" };
  }
  if (product === "hytale" && o.patchline !== undefined && !Object.hasOwn(hytalePatchlines, o.patchline)) return { path: "patchline", message: "Pick a game version" };
  if (product === "palworld") return passwordIssue(o);
  if (product === "ark") {
    if (o.map !== undefined && !arkMapsFor(arkEdition(software)).includes(o.map)) return { path: "map", message: "Pick a map from the list" };
    return passwordIssue(o);
  }
  if (product === "gmod") {
    if (o.mode !== undefined && !Object.hasOwn(gmodGamemodes, o.mode)) return { path: "mode", message: "Pick a gamemode" };
    if (o.map !== undefined && !(gmodMaps as readonly string[]).includes(o.map)) return { path: "map", message: "Pick a map from the list" };
    if (o.gslt && !GSLT_RE.test(o.gslt)) return { path: "gslt", message: "A Steam token has 32 characters (0-9, A-F)" };
    if (o.workshop && !WORKSHOP_RE.test(o.workshop)) return { path: "workshop", message: "Workshop collection ID: numbers only" };
  }
  return null;
}

/** Keeps only the options that belong to the product, so nothing else is ever stored. */
export function pickGameOptions(product: string, o: GameOptionsInput = {}): GameOptions {
  const password = o.password ? { password: o.password } : {};
  if (product === "cs2") {
    return {
      ...(o.gslt ? { gslt: o.gslt } : {}),
      mode: (o.mode && Object.hasOwn(cs2Modes, o.mode) ? o.mode : "competitive") as Cs2Mode,
      map: o.map ?? "de_dust2",
      ...password,
    };
  }
  if (product === "rust") {
    const framework = (o.framework && Object.hasOwn(rustFrameworks, o.framework) ? o.framework : "vanilla") as RustFramework;
    return { worldSize: o.worldSize ?? 3500, framework, ...(o.seed !== undefined ? { seed: o.seed } : {}) };
  }
  if (product === "hytale") return { patchline: o.patchline === "pre-release" ? "pre-release" : "release" };
  if (product === "palworld") return { ...password };
  if (product === "ark") return { map: o.map && Object.hasOwn(arkMaps, o.map) ? o.map : "island", ...password };
  if (product === "gmod") {
    return {
      mode: (o.mode && Object.hasOwn(gmodGamemodes, o.mode) ? o.mode : "sandbox") as GmodGamemode,
      map: o.map && (gmodMaps as readonly string[]).includes(o.map) ? o.map : "gm_construct",
      ...(o.gslt ? { gslt: o.gslt } : {}),
      ...(o.workshop ? { workshop: o.workshop } : {}),
    };
  }
  return {};
}
