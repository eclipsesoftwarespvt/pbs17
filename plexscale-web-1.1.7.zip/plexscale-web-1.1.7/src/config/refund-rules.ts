import { gameKeys } from "./plans";
const REFUND_WINDOW_MS = 24 * 60 * 60 * 1000;
const REFUNDABLE_GAME_PRODUCTS = new Set<string>(gameKeys);

function isRefundEligible(product: string, paidAt: string | null, now = Date.now()) {
  if (!REFUNDABLE_GAME_PRODUCTS.has(product) || !paidAt) return false;
  const paidTime = Date.parse(paidAt);
  if (!Number.isFinite(paidTime) || paidTime > now) return false;
  return now - paidTime <= REFUND_WINDOW_MS;
}

export function isOrderRefundEligible(kind: string, product: string, paidAt: string | null, now = Date.now()) {
  return kind === "new" && isRefundEligible(product, paidAt, now);
}