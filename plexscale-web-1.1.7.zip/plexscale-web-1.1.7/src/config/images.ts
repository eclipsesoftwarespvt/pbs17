import minecraft from "@/assets/img/minecraft.webp";
import hytale from "@/assets/img/hytale.webp";
import cs2 from "@/assets/img/cs2.webp";
import rust from "@/assets/img/rust.webp";
import palworld from "@/assets/img/palworld.webp";
import ark from "@/assets/img/ark.webp";
import gmod from "@/assets/img/gmod.webp";
import bot from "@/assets/img/bot.webp";
import racks from "@/assets/img/racks.webp";
import vps from "@/assets/img/vps.webp";
import ribbon from "@/assets/img/blue-ribbon.webp";
import heroStack from "@/assets/img/hero-ribbon-stack.webp";
import heroStackLights from "@/assets/img/hero-stack-lights.webp";
import heroStackLit from "@/assets/img/hero-stack-lit.webp";
import trustShield from "@/assets/img/trust-shield-3d.webp";
import flagIn from "@/assets/img/flag_in.webp";
import flagAe from "@/assets/img/flag_ae.webp";
import flagDe from "@/assets/img/flag_de.webp";
import flagUs from "@/assets/img/flag_us.webp";
import plexusWordmark from "@/assets/img/plexus_wordmark.webp";
import plexusVpsPanel from "@/assets/img/plexus_vps_panel.webp";
import amd from "@/assets/img/amd_epyc.webp";
import cloudflare from "@/assets/img/cloudflare.webp";
import razorpay from "@/assets/img/razorpay.webp";
import pterodactyl from "@/assets/img/pterodactyl.webp";
import azure from "@/assets/img/azure.webp";
import gcloud from "@/assets/img/googlecloud.webp";
import minecraftBlock from "@/assets/img/minecraft-block.jpg";
import hytaleLogo from "@/assets/img/hytale_logo.webp";
import cs2Logo from "@/assets/img/cs2_logo.webp";
import rustLogo from "@/assets/img/rust_logo.webp";
import palworldLogo from "@/assets/img/palworld_logo.webp";
import arkLogo from "@/assets/img/ark_logo.webp";
import gmodLogo from "@/assets/img/gmod_logo.webp";

export const gameMenuImages = { minecraft: minecraftBlock, hytale: hytaleLogo, cs2: cs2Logo, rust: rustLogo, palworld: palworldLogo, ark: arkLogo, gmod: gmodLogo };

export const img = {
  minecraft: minecraft,
  hytale: hytale,
  cs2: cs2,
  rust: rust,
  palworld: palworld,
  ark: ark,
  gmod: gmod,
  vps: vps,
  bot: bot,
  racks: racks,
  ribbon: ribbon,
  heroStack: heroStack,
  heroStackLights: heroStackLights,
  /** The server stack with every status light on, as one still image (maintenance and other pages). The homepage keeps its animated ServerStack. */
  heroStackLit: heroStackLit,
  trustShield: trustShield,
  amdEpyc: amd,
  plexusWordmark: plexusWordmark,
  plexusVpsPanel: plexusVpsPanel,
};

export const flags: Record<string, string> = { IN: flagIn, AE: flagAe, DE: flagDe, US: flagUs };

/**
 * Flag image for any ISO 3166-1 alpha-2 country code. Bundled flags are used when we have them;
 * every other code is mapped automatically to flagcdn.com, so a new node only needs its country code.
 */
export function flagFor(country: string | undefined | null): string | undefined {
  const code = (country ?? "").trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) return undefined;
  return flags[code] ?? `https://flagcdn.com/w80/${code.toLowerCase()}.png`;
}

/** Partner logos with their trimmed aspect ratio (width / height), used to give every mark the same visual weight. */
export const partners = [
  { name: "AMD EPYC", src: amd, ratio: 6.79 },
  { name: "Cloudflare", src: cloudflare, ratio: 7.18 },
  { name: "Razorpay", src: razorpay, ratio: 4.65 },
  { name: "Pterodactyl", src: pterodactyl, ratio: 3.83 },
  { name: "Microsoft Azure", src: azure, ratio: 1.06 },
  { name: "Google Cloud", src: gcloud, ratio: 6.33 },
  { name: "Plexus", src: plexusWordmark, ratio: 5.14 },
];

/** Equal optical area for logos of any shape: wide wordmarks get shorter, square marks get taller (capped). */
export function partnerLogoSize(ratio: number, area = 3400, maxHeight = 38) {
  const height = Math.min(maxHeight, Math.sqrt(area / ratio));
  return { width: Math.round(height * ratio), height: Math.round(height) };
}
