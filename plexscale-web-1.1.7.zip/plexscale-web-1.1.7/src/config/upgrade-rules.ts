import { isGame, periodMonths, periodTotal, type Billing, type Plan } from "./plans";

/** Days in one billing period for proration. */
const periodDays = (billing: Billing) => periodMonths(billing) * 30;

/** Game servers and bot hosting change plans online (both run on the game panel). VPS goes through support. */
export const canUpgradeProduct = (product: string) => isGame(product) || product === "bot";

/** A plan is an upgrade only if it costs more and no resource shrinks (disks can never shrink safely). */
export function isUpgradePath(from: Plan, to: Plan) {
  if (from.id === to.id) return false;
  if (to.monthly <= from.monthly) return false;
  return to.ramGb >= from.ramGb && to.diskGb >= from.diskGb && to.cpuPercent >= from.cpuPercent;
}

type UpgradeQuote = { ok: true; amount: number; remainingDays: number; periodDays: number; difference: number } | { ok: false; reason: string };

/**
 * Prorated price to move to a bigger plan until the current expiry date.
 * amount = (new period price - current period price) x remaining days / days in a period, rounded up to a whole rupee (minimum 1).
 */
export function upgradeQuote(from: Plan, to: Plan, billing: Billing, renewsAt: string | null, now = Date.now()): UpgradeQuote {
  if (!isUpgradePath(from, to)) return { ok: false, reason: "Pick a bigger plan than your current one." };
  if (!renewsAt) return { ok: false, reason: "This service has no expiry date. Please contact support." };
  const msLeft = Date.parse(renewsAt) - now;
  if (!Number.isFinite(msLeft) || msLeft < 864e5) return { ok: false, reason: "Your service expires within a day. Renew it first, then upgrade." };
  const remainingDays = Math.min(Math.ceil(msLeft / 864e5), 3 * 366);
  const pd = periodDays(billing);
  const difference = periodTotal(to.monthly, billing) - periodTotal(from.monthly, billing);
  if (difference <= 0) return { ok: false, reason: "Pick a bigger plan than your current one." };
  const amount = Math.max(1, Math.ceil((difference * remainingDays) / pd));
  return { ok: true, amount, remainingDays, periodDays: pd, difference };
}
