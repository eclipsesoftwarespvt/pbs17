import { Link } from "@tanstack/react-router";
import { Clock, Lock, ShieldCheck, XCircle } from "lucide-react";
import { SuccessTick } from "@/components/ui-px/SuccessTick";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { btn } from "@/components/ui-px/btn";
import { Spinner } from "@/components/ui-px/Spinner";
import { openRazorpay, type RazorpayResult } from "@/lib/razorpay-client";
import { cn } from "@/lib/utils";
import { shownError } from "@/lib/public-error";

/** What the server returns when a payment starts. Credit payments are already complete; Razorpay ones open the checkout window. */
type Checkout =
  | { orderId: string; razorpayOrderId: string; keyId: string; amount: number; paidWithCredits?: false }
  | { orderId: string; razorpayOrderId: null; keyId: null; amount: number; paidWithCredits: true };

type PaymentPhase =
  | { kind: "idle" }
  | { kind: "preparing" }
  | { kind: "open" }
  | { kind: "verifying" }
  | { kind: "success"; title: string; body: string; action?: { label: string; onClick: () => void }; viaCredits?: boolean }
  | { kind: "cancelled" }
  | { kind: "failed"; reason: string }
  | { kind: "error"; message: string }
  | { kind: "pending" };

interface PaymentRun<T extends Checkout> {
  create: () => Promise<T>;
  description: string;
  email?: string | undefined;
  verify: (co: Extract<T, { razorpayOrderId: string }>, r: RazorpayResult) => Promise<unknown>;
  success: (co: T) => { title: string; body: string; action?: { label: string; onClick: () => void } };
}

/** Drives the full payment journey: prepare order → Razorpay → verify → result screen. */
export function usePaymentFlow() {
  const [phase, setPhase] = useState<PaymentPhase>({ kind: "idle" });
  const last = useRef<PaymentRun<Checkout> | null>(null);
  const busy = phase.kind === "preparing" || phase.kind === "open" || phase.kind === "verifying";

  useEffect(() => {
    if (!busy) return;
    const warn = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [busy]);

  const run = useCallback(async <T extends Checkout>(opts: PaymentRun<T>) => {
    last.current = opts as unknown as PaymentRun<Checkout>;
    setPhase({ kind: "preparing" });
    let co: T;
    try {
      co = await opts.create();
    } catch (e) {
      const msg = shownError(e, "We couldn’t set up your order. Nothing has been charged. Please try again.");
      setPhase({ kind: "error", message: msg });
      return;
    }
    if (co.paidWithCredits) {
      // Paid from the credit balance on the server: no payment window, nothing to verify.
      setPhase({ kind: "success", ...opts.success(co), viaCredits: true });
      return;
    }
    const rc = co as Extract<T, { razorpayOrderId: string }>;
    let outcome;
    try {
      outcome = await openRazorpay({ keyId: rc.keyId, amount: rc.amount, orderId: rc.razorpayOrderId, description: opts.description, email: opts.email, onOpen: () => setPhase({ kind: "open" }) });
    } catch (e) {
      setPhase({ kind: "error", message: shownError(e, "The payment window could not be opened.") });
      return;
    }
    if (outcome.status === "cancelled") { setPhase({ kind: "cancelled" }); return; }
    if (outcome.status === "failed") { setPhase({ kind: "failed", reason: outcome.reason }); return; }
    setPhase({ kind: "verifying" });
    try {
      await opts.verify(rc, outcome.result);
      setPhase({ kind: "success", ...opts.success(co) });
    } catch {
      setPhase({ kind: "pending" });
    }
  }, []);

  const retry = useCallback(() => { if (last.current) void run(last.current); }, [run]);
  const reset = useCallback(() => setPhase({ kind: "idle" }), []);
  return { phase, busy, run, retry, reset, overlay: <PaymentOverlay phase={phase} onRetry={retry} onClose={reset} /> };
}

function Shell({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "ok" | "bad" }) {
  return (
    <div className="overlay-veil animate-fade fixed inset-0 z-[100] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-live="assertive">
      <div className={cn("popup-surface animate-pop relative w-full max-w-md overflow-hidden p-8 text-center", tone === "ok" && "popup-surface-ok", tone === "bad" && "popup-surface-bad")}>
        <div className="relative flex flex-col items-center">{children}</div>
      </div>
    </div>
  );
}

function SecureBadge() {
  return (
    <div className="mt-8 w-full rounded-md border border-steel bg-ink/60 px-4 py-3">
      <p className="flex items-center justify-center gap-2 font-display text-sm font-semibold"><Lock className="size-4 text-ok" />Secure Transaction</p>
      <p className="mt-1 text-xs text-muted-foreground">Don’t close this tab or press back.</p>
    </div>
  );
}

function PaymentOverlay({ phase, onRetry, onClose }: { phase: PaymentPhase; onRetry: () => void; onClose: () => void }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted || phase.kind === "idle") return null;

  let content: ReactNode;
  if (phase.kind === "preparing" || phase.kind === "open" || phase.kind === "verifying") {
    const copy = phase.kind === "preparing"
      ? { t: "Opening your payment", b: "Setting up the order. This takes a few seconds." }
      : phase.kind === "open"
        ? { t: "Complete your payment", b: "Finish paying in the secure Razorpay window." }
        : { t: "Confirming your payment", b: "Verifying with Razorpay. This takes a few seconds." };
    content = (
      <Shell>
        <Spinner size="xl" label={copy.t} />
        <h2 className="mt-8 text-2xl">{copy.t}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{copy.b}</p>
        <SecureBadge />
      </Shell>
    );
  } else if (phase.kind === "success") {
    content = (
      <Shell tone="ok">
        <SuccessTick />
        <h2 className="mt-6 text-2xl">{phase.title}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{phase.body}</p>
        <div className="mt-8 flex w-full flex-col gap-2">
          {phase.action ? <button type="button" className={cn(btn({ size: "lg" }), "w-full")} onClick={phase.action.onClick}>{phase.action.label}</button>
            : <button type="button" className={cn(btn({ size: "lg" }), "w-full")} onClick={onClose}>Done</button>}
        </div>
        <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground"><ShieldCheck className="size-3.5 text-ok" />{phase.viaCredits ? "Paid from your PlexScale Credits. Your invoice is on its way." : "Your invoice is on its way to your inbox."}</p>
      </Shell>
    );
  } else if (phase.kind === "pending") {
    content = (
      <Shell>
        <span className="popup-icon popup-icon-info size-20"><Clock className="size-10" /></span>
        <h2 className="mt-6 text-2xl">We’re confirming your payment</h2>
        <p className="mt-2 text-sm text-muted-foreground">If you were charged, your order completes automatically within a few minutes. You can track it in Billing.</p>
        <div className="mt-8 flex w-full flex-col gap-2">
          <Link to="/billing" onClick={onClose} className={cn(btn({ size: "lg" }), "w-full")}>Go to billing</Link>
          <Link to="/support/new" search={{ category: "billing" }} onClick={onClose} className={cn(btn({ size: "lg", variant: "secondary" }), "w-full")}>Contact support</Link>
        </div>
      </Shell>
    );
  } else {
    const body = phase.kind === "cancelled"
      ? "The payment was cancelled. Nothing has been charged."
      : phase.kind === "failed"
        ? `${phase.reason.replace(/\.$/, "")}. Nothing has been charged. If money left your account, your bank returns it automatically.`
        : phase.message;
    content = (
      <Shell tone="bad">
        <span className="popup-icon popup-icon-bad size-20"><XCircle className="size-10" /></span>
        <h2 className="mt-6 text-2xl">{phase.kind === "error" ? "We couldn’t start your payment" : "Payment didn’t go through"}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{body}</p>
        <p className="mt-1 text-sm text-muted-foreground">Try again or contact support.</p>
        <div className="mt-8 flex w-full flex-col gap-2">
          <button type="button" className={cn(btn({ size: "lg" }), "w-full")} onClick={onRetry}>Try again</button>
          <Link to="/support/new" search={{ category: "billing" }} onClick={onClose} className={cn(btn({ size: "lg", variant: "secondary" }), "w-full")}>Contact support</Link>
          <button type="button" className={cn(btn({ variant: "text" }), "mx-auto mt-1")} onClick={onClose}>Close</button>
        </div>
      </Shell>
    );
  }
  return createPortal(content, document.body);
}
