import type { SVGProps } from "react";

/** Policy document with a shield: the Legal menu icon. Sized and coloured like a lucide icon (currentColor, 24px box). */
export function LegalIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      <path d="M12 21H6.5A2.5 2.5 0 0 1 4 18.5v-13A2.5 2.5 0 0 1 6.5 3H14l5 5v3.5" />
      <path d="M14 3v3.5A1.5 1.5 0 0 0 15.5 8H19" />
      <path d="M8 12h4M8 16h2" />
      <path d="M18 13.5l3.5 1.4v2.6c0 2.2-1.5 3.7-3.5 4.5-2-.8-3.5-2.3-3.5-4.5v-2.6z" />
    </svg>
  );
}
