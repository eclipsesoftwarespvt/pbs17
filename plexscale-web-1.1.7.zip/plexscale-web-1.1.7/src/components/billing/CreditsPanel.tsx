import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowDownLeft, ArrowUpRight, History, Plus, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Spinner } from "@/components/ui-px/Spinner";
import { Badge } from "@/components/ui-px/page";
import { inputCls, tdCls, thCls } from "@/components/ui-px/form";
import { usePaymentFlow } from "@/components/payment/PaymentFlow";
import { creditKindLabel, topupProblem } from "@/config/credits";
import { formatINR } from "@/config/plans";
import { useCredits } from "@/hooks/use-credits";
import { useSettings } from "@/hooks/use-settings";
import { createCreditTopup } from "@/lib/credits.functions";
import { verifyPayment } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

const when = (s: string) => new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

/** Balance card, "Add credits" checkout and the credit ledger for the Billing page. */
export function CreditsPanel() {
  const s = useSettings();
  const qc = useQueryClient();
  const credits = useCredits();
  const create = useServerFn(createCreditTopup);
  const verify = useServerFn(verifyPayment);
  const payment = usePaymentFlow();
  const [open, setOpen] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const balance = credits.data?.balance ?? 0;
  const tx = credits.data?.transactions ?? [];
  if (!s.credits.enabled && balance === 0 && tx.length === 0) return null;
  const shown = showAll ? tx : tx.slice(0, 6);

  return (
    <section id="credits" aria-labelledby="credits-title" className="scroll-mt-24">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div className="credits-card relative flex flex-col justify-between overflow-hidden p-6">
          <div>
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-azure-bright"><Wallet className="size-4" />PlexScale Credits</p>
            <h2 id="credits-title" className="sr-only">Credits</h2>
            <p className="mt-4 font-display text-4xl tabular-nums md:text-5xl" aria-live="polite">{credits.isLoading ? <Spinner size="md" /> : formatINR(balance)}</p>
            <p className="mt-2 text-sm text-muted-foreground">Pay for new servers, renewals and upgrades in one click.</p>
          </div>
          <div className="mt-6 flex flex-wrap gap-2">
            {s.credits.enabled ? <Button onClick={() => setOpen(true)}><Plus />Add credits</Button> : <Badge tone="muted">Top-ups are paused</Badge>}
          </div>
        </div>
        <div className="panel min-w-0 overflow-hidden">
          <div className="flex items-center justify-between gap-3 border-b border-steel px-5 py-4">
            <p className="flex items-center gap-2 font-display font-semibold"><History className="size-4 text-azure" />Credit activity</p>
            {tx.length > 6 && <Button variant="text" size="sm" onClick={() => setShowAll(!showAll)}>{showAll ? "Show less" : `Show all (${tx.length})`}</Button>}
          </div>
          {tx.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-muted-foreground">No credit activity yet. Top-ups and payments made with credits appear here.</p>
          ) : (
            <div className="max-h-80 overflow-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-graphite"><tr><th className={thCls}>Date</th><th className={thCls}>Activity</th><th className={cn(thCls, "text-right")}>Amount</th><th className={cn(thCls, "text-right")}>Balance</th></tr></thead>
                <tbody>
                  {shown.map((t) => (
                    <tr key={t.id}>
                      <td className={cn(tdCls, "whitespace-nowrap text-muted-foreground")}>{when(t.created_at)}</td>
                      <td className={tdCls}>
                        <span className="flex items-center gap-2">
                          {t.amount > 0 ? <ArrowDownLeft className="size-4 shrink-0 text-ok" /> : <ArrowUpRight className="size-4 shrink-0 text-azure" />}
                          <span className="min-w-0"><span className="block font-medium">{creditKindLabel[t.kind] ?? t.kind}</span>{t.note && t.kind !== "topup" && <span className="block truncate text-xs text-muted-foreground">{t.note}</span>}</span>
                        </span>
                      </td>
                      <td className={cn(tdCls, "whitespace-nowrap text-right font-semibold tabular-nums", t.amount > 0 ? "text-ok" : "text-foreground")}>{t.amount > 0 ? "+" : "-"}{formatINR(Math.abs(t.amount))}</td>
                      <td className={cn(tdCls, "whitespace-nowrap text-right tabular-nums text-muted-foreground")}>{formatINR(t.balance_after)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      {open && <TopupDialog balance={balance} busy={payment.busy} onClose={() => setOpen(false)} onPay={async (value) => {
        const { data: u } = await supabase.auth.getUser();
        setOpen(false);
        await payment.run({
          create: () => create({ data: { amount: value } }),
          description: `PlexScale Credits ${formatINR(value)}`,
          email: u.user?.email,
          verify: (co, r) => verify({ data: { orderId: co.orderId, razorpayOrderId: r.razorpay_order_id, paymentId: r.razorpay_payment_id, signature: r.razorpay_signature } }),
          success: () => {
            void qc.invalidateQueries({ queryKey: ["credits"] });
            void qc.invalidateQueries({ queryKey: ["billing"] });
            return { title: "Credits added", body: `${formatINR(value)} in credits is now on your account. Use it for new servers, renewals and upgrades.` };
          },
        });
      }} />}
      {payment.overlay}
    </section>
  );
}

function TopupDialog({ balance, busy, onClose, onPay }: { balance: number; busy: boolean; onClose: () => void; onPay: (amount: number) => void }) {
  const s = useSettings();
  const c = s.credits;
  const [amount, setAmount] = useState<number>(c.presets[1] ?? c.presets[0] ?? c.minTopup);
  const [custom, setCustom] = useState("");
  const value = custom ? Number(custom) : amount;
  const problem = topupProblem(value, balance, c);

  return (
    <>
      <Dialog open onOpenChange={(v) => !v && onClose()}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Add credits</DialogTitle>
            <DialogDescription>Pay securely with Razorpay, then use your credits at checkout, for renewals and for upgrades.</DialogDescription>
          </DialogHeader>
          {c.presets.length > 0 && (
            <div role="radiogroup" aria-label="Quick amounts" className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {c.presets.map((p) => {
                const on = !custom && amount === p;
                return (
                  <button key={p} type="button" role="radio" aria-checked={on} onClick={() => { setAmount(p); setCustom(""); }}
                    className={cn("rounded-md border px-3 py-3 text-center font-display text-lg font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", on ? "border-azure bg-azure/15 text-foreground" : "border-steel bg-ink/40 text-foreground hover:border-azure/60 hover:bg-accent")}>
                    {formatINR(p)}
                  </button>
                );
              })}
            </div>
          )}
          <label className="grid gap-1.5 text-sm">
            <span className="font-semibold">Or enter an amount</span>
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted-foreground">₹</span>
              <input inputMode="numeric" value={custom} onChange={(e) => setCustom(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))} placeholder={`${c.minTopup} to ${c.maxTopup}`} aria-invalid={Boolean(custom) && Boolean(problem)} className={cn(inputCls, "h-11 pl-7 font-display text-base")} />
            </div>
            <span className={cn("text-xs", custom && problem ? "text-destructive" : "text-muted-foreground")}>{custom && problem ? problem : `Between ${formatINR(c.minTopup)} and ${formatINR(c.maxTopup)} per top-up.`}</span>
          </label>
          <div className="panel-inset flex items-center justify-between p-4 text-sm">
            <span className="text-muted-foreground">Balance after top-up</span>
            <span className="font-display text-lg tabular-nums">{formatINR(balance + (Number.isFinite(value) && value > 0 ? value : 0))}</span>
          </div>
          {!custom && problem && <p role="alert" className="text-sm text-destructive">{problem}</p>}
          <Button size="lg" className="w-full" disabled={Boolean(problem) || busy} onClick={() => { if (!problem) onPay(value); }}>{busy ? <Spinner size="xs" /> : <Plus />}{problem ? "Add credits" : `Pay ${formatINR(value)}`}</Button>
          <p className="text-center text-xs text-muted-foreground">GST included. Credits stay on your PlexScale account and can’t be withdrawn or transferred.</p>
        </DialogContent>
      </Dialog>
    </>
  );
}
