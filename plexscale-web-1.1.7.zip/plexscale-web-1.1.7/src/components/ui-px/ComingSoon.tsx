import { BellRing } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { DiscordIcon } from "@/components/icons/DiscordIcon";
import { isComingSoon } from "@/config/settings";
import { useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";

/** "Coming soon" label for products the admin has announced but not opened for orders. */
export function SoonTag({ compact, className }: { compact?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex shrink-0 items-center gap-1.5 rounded-full border border-azure/40 bg-azure-deep font-semibold uppercase tracking-wide text-azure-bright", compact ? "px-1.5 py-px text-[10px]" : "px-2.5 py-1 text-[11px]", className)}>
      <span aria-hidden className="size-1.5 rounded-full bg-azure-bright motion-safe:animate-pulse" />
      {compact ? "Soon" : "Coming soon"}
    </span>
  );
}

export function useComingSoon(product: string) {
  return isComingSoon(useSettings(), product);
}

/** Hero button: "Deploy a server" normally, or a Discord invite for launch news while the product is coming soon. */
export function DeployCta({ product }: { product: string }) {
  const s = useSettings();
  if (!isComingSoon(s, product)) return <a href="#plans" className={btn({ size: "lg" })}>Deploy a server</a>;
  return (
    <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg" })}>
      <DiscordIcon /> Get launch news
    </a>
  );
}

/** Notice above the plan cards while a product is coming soon. */
export function ComingSoonNotice({ name }: { name: string }) {
  const s = useSettings();
  return (
    <div role="status" className="panel-accent mt-8 flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-start gap-3">
        <span className="grid size-10 shrink-0 place-items-center rounded-md border border-azure/40 bg-azure-deep text-azure-bright"><BellRing className="size-5" /></span>
        <div>
          <p className="flex flex-wrap items-center gap-2 font-display font-semibold">{name} is coming soon <SoonTag compact /></p>
          <p className="mt-1 text-sm text-muted-foreground">These plans are a preview. Ordering opens at launch, and our Discord hears about it first.</p>
        </div>
      </div>
      <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={cn(btn({ variant: "secondary" }), "shrink-0")}><DiscordIcon /> Join Discord</a>
    </div>
  );
}

/** Hero label shown only while the product is coming soon. */
export function SoonBadge({ product }: { product: string }) {
  return useComingSoon(product) ? <div className="mb-5"><SoonTag /></div> : null;
}
