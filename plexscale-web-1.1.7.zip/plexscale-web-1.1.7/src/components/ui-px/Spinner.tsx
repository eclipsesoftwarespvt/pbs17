import { cn } from "@/lib/utils";

const sizes = { xs: 16, sm: 20, md: 32, lg: 56, xl: 84 } as const;

/** The PlexScale preloader: a thick, smooth ring in the current text colour. Used for every loading state. */
export function Spinner({ size = "md", className, label }: { size?: keyof typeof sizes; className?: string; label?: string }) {
  const px = sizes[size];
  return (
    <svg viewBox="0 0 50 50" width={px} height={px} className={cn("px-spinner shrink-0", className)} role={label ? "status" : undefined} aria-label={label} aria-hidden={label ? undefined : true}>
      <circle className="px-spinner-track" cx="25" cy="25" r="20" fill="none" strokeWidth="5.5" />
      <circle className="px-spinner-arc" cx="25" cy="25" r="20" fill="none" strokeWidth="5.5" />
    </svg>
  );
}

/** Centered preloader for page and section loading. */
export function PageLoader({ text, className }: { text?: string; className?: string }) {
  return (
    <div className={cn("flex min-h-[50vh] flex-col items-center justify-center gap-5 px-4 py-16 text-center", className)} role="status" aria-live="polite">
      <Spinner size="lg" className="text-azure" />
      {text && <p className="text-sm text-muted-foreground">{text}</p>}
      {!text && <span className="sr-only">Loading</span>}
    </div>
  );
}
