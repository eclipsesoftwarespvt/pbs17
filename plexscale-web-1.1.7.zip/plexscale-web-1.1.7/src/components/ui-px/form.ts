/** Shared form control styles so inputs look identical on account pages, checkout and Administrator. */
export const inputCls =
  "h-10 w-full rounded-md border border-steel bg-ink px-3 text-sm text-foreground placeholder:text-muted-foreground transition-colors hover:border-steel focus:border-azure focus:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:cursor-not-allowed disabled:opacity-50 aria-[invalid=true]:border-destructive";
export const textareaCls = `${inputCls} h-auto py-2 leading-relaxed`;
/** Table header and cell styles shared by Billing and Administrator tables. */
export const thCls = "p-3 text-left text-xs font-medium uppercase tracking-wide text-muted-foreground";
export const tdCls = "p-3 border-t border-steel align-middle";
