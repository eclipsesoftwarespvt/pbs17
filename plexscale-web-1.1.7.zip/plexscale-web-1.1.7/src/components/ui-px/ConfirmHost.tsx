import { useEffect, useState } from "react";
import { HelpCircle } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { btn } from "@/components/ui-px/btn";
import { cn } from "@/lib/utils";

type Ask = { message: string; resolve: (ok: boolean) => void };
let push: ((a: Ask) => void) | null = null;

/** Themed replacement for window.confirm. Resolves true when the user confirms. */
export function askConfirm(message: string): Promise<boolean> {
  if (!push) return Promise.resolve(typeof window !== "undefined" && window.confirm(message));
  return new Promise((resolve) => push?.({ message, resolve }));
}

/** Mount once in the root layout. */
export function ConfirmHost() {
  const [ask, setAsk] = useState<Ask | null>(null);
  useEffect(() => { push = setAsk; return () => { push = null; }; }, []);
  const done = (ok: boolean) => { ask?.resolve(ok); setAsk(null); };
  return (
    <Dialog open={Boolean(ask)} onOpenChange={(v) => !v && done(false)}>
      <DialogContent className="max-w-sm text-center">
        <DialogHeader className="items-center text-center sm:text-center">
          <span className="popup-icon popup-icon-info"><HelpCircle className="size-8" /></span>
          <DialogTitle className="mt-4 font-display text-xl">Please confirm</DialogTitle>
          <DialogDescription>{ask?.message}</DialogDescription>
        </DialogHeader>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button type="button" className={btn({ variant: "secondary" })} onClick={() => done(false)}>Cancel</button>
          <button type="button" autoFocus className={cn(btn())} onClick={() => done(true)}>Confirm</button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
