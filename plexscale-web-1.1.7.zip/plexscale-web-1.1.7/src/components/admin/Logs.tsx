import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { listPanelAlerts } from "@/lib/admin.functions";
import { ActivityPanel } from "./Activity";
import { AlertsPanel } from "./Alerts";
import { Segmented } from "./fields";

type Row = Parameters<typeof ActivityPanel>[0]["rows"][number];
type Profile = Parameters<typeof ActivityPanel>[0]["profiles"][number];

/** One place for what went wrong (system alerts) and who changed what (admin activity). */
export function LogsPanel({ rows, profiles, onChange }: { rows: Row[]; profiles: Profile[]; onChange: () => void }) {
  const [view, setView] = useState<"alerts" | "activity">("alerts");
  const list = useServerFn(listPanelAlerts);
  const { data: open } = useQuery({ queryKey: ["panel-alerts", "open", ""], queryFn: () => list({ data: { status: "open", q: "" } }) });
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Segmented label="Log type" value={view} onChange={setView} options={[
          { value: "alerts", label: "System alerts", count: open?.length ?? 0 },
          { value: "activity", label: "Admin activity" },
        ]} />
        <p className="text-xs text-muted-foreground">{view === "alerts" ? "Failed game panel actions with the full detail." : "Last 100 admin actions. Click an IP to reveal it."}</p>
      </div>
      {view === "alerts" ? <AlertsPanel onChange={onChange} /> : <ActivityPanel rows={rows} profiles={profiles} />}
    </div>
  );
}
