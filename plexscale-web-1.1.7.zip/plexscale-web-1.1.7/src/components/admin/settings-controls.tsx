import { askConfirm } from "@/components/ui-px/ConfirmHost";
import { useEffect, useState } from "react";
import { Plus, Save, RotateCcw, Trash2, ShieldCheck, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MAX_LOCATIONS, minecraftVersionSchema, sortByNodeOrder, type SiteSettings } from "@/config/settings";
import { flagFor } from "@/config/images";
import { cn } from "@/lib/utils";
import { Card, Field, inputCls, Toggle } from "./fields";
import { toast } from "sonner";

export function useSettingsDraft<T>(initial: T) {
  const [draft, setDraft] = useState(initial);
  const [baseline, setBaseline] = useState(initial);
  const dirty = JSON.stringify(draft) !== JSON.stringify(baseline);
  useEffect(() => {
    if (!dirty) { setDraft(initial); setBaseline(initial); }
  }, [initial]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ""; };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  return { draft, setDraft, dirty, discard: () => setDraft(baseline), accept: (saved: T) => { setBaseline(saved); setDraft(saved); } };
}

export function SaveBar({ dirty, saving, onSave, onDiscard, label = "Save changes" }: { dirty: boolean; saving: boolean; onSave: () => void; onDiscard: () => void; label?: string }) {
  return <div className="admin-save-bar sticky bottom-0 z-20 flex flex-wrap items-center justify-between gap-3 border-t border-steel bg-background px-4 py-4">
    <span className="flex items-center gap-2 text-sm text-muted-foreground"><ShieldCheck className="size-4 text-ok" />{saving ? "Saving changes…" : dirty ? "Unsaved changes" : "All changes saved"}</span>
    <div className="flex flex-wrap gap-2">
      <Button type="button" variant="outline" disabled={saving || !dirty} onClick={onDiscard}><RotateCcw />Discard</Button>
      <Button type="button" disabled={saving || !dirty} onClick={onSave}><Save />{saving ? "Saving…" : label}</Button>
    </div>
  </div>;
}

/** Lowercase dash id from a city name, made unique against the existing ids. */
function nodeIdFor(city: string, taken: string[]) {
  const base = city.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 34) || "node";
  let id = base;
  for (let n = 2; taken.includes(id); n++) id = `${base}-${n}`;
  return id;
}

const flagCls = "h-4 w-8 shrink-0 rounded-sm object-cover ring-1 ring-steel";
function Flag({ code }: { code: string }) {
  const src = flagFor(code);
  return src ? <img src={src} alt="" width={32} height={16} referrerPolicy="no-referrer" className={flagCls} /> : <span className={cn(flagCls, "inline-block bg-muted")} />;
}

const emptyNode = { city: "", region: "", country: "", mockPing: 50 };

/**
 * Locations and deploy nodes. The list shows the deploy (checkout) page order; arrows change only that order.
 * New nodes are deploy-only: the homepage, about and product pages keep their locations unless "Show on public pages" is ticked.
 */
export function LocationsEditor({ value, onChange }: { value: SiteSettings; onChange: (value: SiteSettings) => void }) {
  const [node, setNode] = useState(emptyNode);
  const ordered = sortByNodeOrder(value.locations, value.ordering.nodeOrder);
  const patch = (id: string, key: string, next: string | number | boolean) => onChange({ ...value, locations: value.locations.map((l) => l.id === id ? { ...l, [key]: next } : l) });
  const setOrder = (ids: string[]) => onChange({ ...value, ordering: { ...value.ordering, nodeOrder: ids } });
  function move(index: number, dir: -1 | 1) {
    const ids = ordered.map((l) => l.id);
    const j = index + dir;
    if (j < 0 || j >= ids.length) return;
    [ids[index], ids[j]] = [ids[j]!, ids[index]!];
    setOrder(ids);
  }
  function addNode() {
    const city = node.city.trim();
    const region = node.region.trim();
    const country = node.country.trim().toUpperCase();
    if (!city || !region) { toast.error("Enter the city and the country or region."); return; }
    if (!/^[A-Z]{2}$/.test(country)) { toast.error("Enter a two-letter country code, for example SG or GB."); return; }
    if (value.locations.length >= MAX_LOCATIONS) { toast.error(`You can list up to ${MAX_LOCATIONS} nodes.`); return; }
    const id = nodeIdFor(city, value.locations.map((l) => l.id));
    const mockPing = Math.max(0, Math.min(2000, Math.round(Number(node.mockPing) || 0)));
    onChange({
      ...value,
      locations: [...value.locations, { id, city, region, country, x: 50, y: 50, mockPing, home: false }],
      ordering: { ...value.ordering, nodeOrder: [...ordered.map((l) => l.id), id] },
    });
    setNode(emptyNode);
    toast.success(`${city} added. Save, then map it in Pterodactyl (or Plexus for VPS) before customers deploy there.`);
  }
  function remove(id: string) {
    const ids = (list: string[]) => list.filter((x) => x !== id);
    onChange({
      ...value,
      locations: value.locations.filter((x) => x.id !== id),
      ordering: {
        ...value.ordering,
        disabledLocations: ids(value.ordering.disabledLocations),
        nodeOrder: ids(value.ordering.nodeOrder ?? []),
        productLocations: Object.fromEntries(Object.entries(value.ordering.productLocations ?? {}).map(([k, list]) => [k, ids(list)]).filter(([, list]) => (list as string[]).length > 0)),
      },
    });
  }
  return <div className="space-y-6">
    <Card title="Add a node" sub="Shown on the deploy (checkout) page only. The flag is loaded automatically from the country code.">
      <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5" onSubmit={(e) => { e.preventDefault(); addNode(); }}>
        <Field label="City"><input className={inputCls} maxLength={60} value={node.city} placeholder="Singapore" onChange={(e) => setNode({ ...node, city: e.target.value })} /></Field>
        <Field label="Country / region"><input className={inputCls} maxLength={60} value={node.region} placeholder="Singapore" onChange={(e) => setNode({ ...node, region: e.target.value })} /></Field>
        <Field label="Country code" hint="ISO code, e.g. SG, GB, JP"><div className="flex items-center gap-2"><input className={cn(inputCls, "font-mono uppercase")} maxLength={2} value={node.country} placeholder="SG" onChange={(e) => setNode({ ...node, country: e.target.value.toUpperCase().replace(/[^A-Z]/g, "") })} /><Flag code={node.country} /></div></Field>
        <Field label="Estimated latency (ms)"><input className={inputCls} type="number" min={0} max={2000} value={node.mockPing} onChange={(e) => setNode({ ...node, mockPing: Number(e.target.value) })} /></Field>
        <Button className="self-end" type="submit" disabled={value.locations.length >= MAX_LOCATIONS}><Plus />Add node</Button>
      </form>
    </Card>
    <Card title="Nodes and locations" sub="Top to bottom is the order on the deploy page. Arrows change the deploy order only; the homepage order stays as it is.">
      <div className="divide-y divide-steel">
        {ordered.map((l, i) => <div key={l.id} className="grid gap-4 py-5 first:pt-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="flex flex-wrap items-center gap-3 font-display font-semibold"><span className="w-6 text-right font-mono text-xs font-normal text-muted-foreground">{i + 1}</span><Flag code={l.country} />{l.city}<span className="font-mono text-xs font-normal text-muted-foreground">{l.id}</span>
              <span className={cn("rounded border px-1.5 py-0.5 text-[11px] font-normal", l.home === false ? "border-azure/50 text-azure-bright" : "border-steel text-muted-foreground")}>{l.home === false ? "Deploy only" : "Public + deploy"}</span>
            </p>
            <div className="flex items-center gap-1">
              <Button type="button" variant="ghost" size="icon" aria-label={`Move ${l.city} up`} title="Move up" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp /></Button>
              <Button type="button" variant="ghost" size="icon" aria-label={`Move ${l.city} down`} title="Move down" disabled={i === ordered.length - 1} onClick={() => move(i, 1)}><ArrowDown /></Button>
              <Button type="button" variant="ghost" size="icon" aria-label={`Remove ${l.city}`} title={`Remove ${l.city}`} disabled={value.locations.length <= 1} onClick={async () => { if (await askConfirm(`Remove ${l.city} from new deployments? Existing orders are retained.`)) remove(l.id); }}><Trash2 /></Button>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="City"><input className={inputCls} maxLength={60} value={l.city} onChange={(e) => patch(l.id, "city", e.target.value)} /></Field>
            <Field label="Country / region"><input className={inputCls} maxLength={60} value={l.region} onChange={(e) => patch(l.id, "region", e.target.value)} /></Field>
            <Field label="Country code"><input className={cn(inputCls, "font-mono uppercase")} maxLength={2} value={l.country} onChange={(e) => patch(l.id, "country", e.target.value.toUpperCase().replace(/[^A-Z]/g, ""))} /></Field>
            <Field label="Estimated latency (ms)"><input className={inputCls} type="number" min={0} max={2000} value={l.mockPing} onChange={(e) => patch(l.id, "mockPing", Number(e.target.value))} /></Field>
          </div>
          <Toggle checked={l.home !== false} onChange={(v) => patch(l.id, "home", v)} label="Show on public pages (homepage, about, product pages)" />
        </div>)}
      </div>
    </Card>
  </div>;
}

export function VersionsEditor({ value, onChange }: { value: string[]; onChange: (value: string[]) => void }) {
  const [release, setRelease] = useState("");
  function add() {
    const parsed = minecraftVersionSchema.safeParse(release);
    if (!parsed.success) { toast.error("Enter a release number such as 26.3."); return; }
    if (value.includes(parsed.data)) { toast.error("This version is already listed."); return; }
    onChange(["latest", parsed.data, ...value.filter((v) => v !== "latest")]); setRelease("");
  }
  return <Card title="Minecraft versions">
    <div className="flex flex-wrap gap-3"><Field label="Release number"><input className={inputCls} value={release} maxLength={20} placeholder="26.3" onChange={(e) => setRelease(e.target.value)} /></Field><Button className="self-end" type="button" disabled={!release.trim() || value.length >= 200} onClick={add}><Plus />Add version</Button></div>
    <ul className="mt-5 flex flex-wrap gap-2">{value.map((v) => <li key={v} className="flex items-center gap-2 rounded-md border border-steel py-1 pl-3 pr-1 text-sm"><span>{v === "latest" ? "Latest release" : v}</span>{v !== "latest" && <Button type="button" variant="ghost" size="icon" aria-label={`Remove version ${v}`} title={`Remove ${v}`} onClick={() => onChange(value.filter((x) => x !== v))}><Trash2 /></Button>}</li>)}</ul>
  </Card>;
}