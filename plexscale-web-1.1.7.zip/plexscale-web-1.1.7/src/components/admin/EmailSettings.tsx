import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Eye, KeyRound, Send } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { defaultTemplates, emailSettingsInput, renderHtml, renderSubject, sampleVars, templateKeys, templateMeta, type EmailSettings, type TemplateKey } from "@/config/email";
import { getEmailSettings, saveEmailSettings, sendTestEmail, testDiscordWebhook } from "@/lib/email-admin.functions";
import { cn } from "@/lib/utils";
import { Card, Field, inputCls, Pill, td, th, Toggle } from "./fields";
import { SaveBar, useSettingsDraft } from "./settings-controls";

export function EmailSettingsPanel() {
  const load = useServerFn(getEmailSettings);
  const { data, isLoading, error } = useQuery({ queryKey: ["admin-email"], queryFn: () => load() });
  if (isLoading) return <PageLoader text="Loading email settings" className="min-h-[30vh]" />;
  if (error || !data) return <p className="text-destructive">Could not load email settings.</p>;
  return <Editor data={data} />;
}

type Data = Awaited<ReturnType<typeof getEmailSettings>>;

function Editor({ data }: { data: Data }) {
  const qc = useQueryClient();
  const save = useServerFn(saveEmailSettings);
  const test = useServerFn(sendTestEmail);
  const testDiscord = useServerFn(testDiscordWebhook);
  const { draft: d, setDraft: setD, dirty, discard, accept } = useSettingsDraft<EmailSettings>(data.settings);
  const [password, setPassword] = useState("");
  const [clearPassword, setClearPassword] = useState(false);
  const [webhook, setWebhook] = useState("");
  const [clearWebhook, setClearWebhook] = useState(false);
  const [saving, setSaving] = useState(false);
  const [active, setActive] = useState<TemplateKey>("welcome");
  const [testing, setTesting] = useState(false);
  const [preview, setPreview] = useState(false);
  const secretsDirty = Boolean(password || clearPassword || webhook || clearWebhook);
  const set = <K extends keyof EmailSettings>(k: K, v: EmailSettings[K]) => setD((p) => ({ ...p, [k]: v }));
  const tpl = d.templates[active];
  const previewHtml = useMemo(() => renderHtml(tpl.body, sampleVars, { preheader: renderSubject(tpl.subject, sampleVars), ...(typeof window !== "undefined" ? { logoUrl: `${window.location.origin}/email/plexscale-logo.png` } : {}) }), [tpl]);

  async function submit() {
    const input = { ...d, ...(password ? { smtpPassword: password } : {}), ...(clearPassword ? { clearSmtpPassword: true } : {}), ...(webhook ? { discordWebhookUrl: webhook } : {}), ...(clearWebhook ? { clearDiscordWebhook: true } : {}) };
    const check = emailSettingsInput.safeParse(input);
    if (!check.success) { const i = check.error.issues[0]; toast.error(`${i?.path.join(" › ") ?? "Settings"}: ${i?.message ?? "invalid value"}`); return; }
    setSaving(true);
    try {
      await save({ data: input });
      accept(d); setPassword(""); setClearPassword(false); setWebhook(""); setClearWebhook(false);
      toast.success("Email settings saved.");
      await qc.invalidateQueries({ queryKey: ["admin-email"] });
    } catch { toast.error("Could not save. Check the highlighted values and try again."); }
    setSaving(false);
  }

  async function sendTest() {
    if (dirty || secretsDirty) { toast.error("Save your changes first, then send a test."); return; }
    setTesting(true);
    try { const r = await test({ data: { template: active } }); (r.ok ? toast.success : toast.error)(r.message); } catch { toast.error("Test email could not be sent."); }
    setTesting(false);
  }

  return (
    <div className="space-y-2">
      <Card title="SMTP server" sub="Port 587 (STARTTLS) or 465 (TLS)." actions={<div className="flex flex-wrap gap-2"><Pill ok={data.ready}>{data.ready ? "Sending ready" : "Not ready"}</Pill><Pill ok={data.encryption}>Credential encryption</Pill></div>}>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="md:col-span-2"><Toggle checked={d.smtp.enabled} onChange={(v) => set("smtp", { ...d.smtp, enabled: v })} label="Send emails through SMTP" /></div>
          <Field label="SMTP host"><input className={inputCls} value={d.smtp.host} onChange={(e) => set("smtp", { ...d.smtp, host: e.target.value.trim() })} placeholder="smtp.zoho.in" autoComplete="off" /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Port"><input type="number" min={1} max={65535} className={inputCls} value={d.smtp.port} onChange={(e) => set("smtp", { ...d.smtp, port: Number(e.target.value) || 587 })} /></Field>
            <Field label="Security"><select className={inputCls} value={d.smtp.security} onChange={(e) => { const security = e.target.value as "starttls" | "tls"; set("smtp", { ...d.smtp, security, port: security === "tls" && d.smtp.port === 587 ? 465 : security === "starttls" && d.smtp.port === 465 ? 587 : d.smtp.port }); }}><option value="starttls">STARTTLS (587)</option><option value="tls">TLS (465)</option></select></Field>
          </div>
          <Field label="Username"><input className={inputCls} value={d.smtp.username} onChange={(e) => set("smtp", { ...d.smtp, username: e.target.value })} autoComplete="off" placeholder="no-reply@plexscale.com" /></Field>
          <Field label="Password" hint={data.smtpPasswordSet && !clearPassword ? "Saved. Leave blank to keep." : "Stored encrypted."}>
            <div className="flex gap-2">
              <input type="password" className={inputCls} value={password} onChange={(e) => { setPassword(e.target.value); setClearPassword(false); }} autoComplete="new-password" placeholder={data.smtpPasswordSet && !clearPassword ? "••••••••••••" : "App password"} />
              {data.smtpPasswordSet && <Button type="button" variant="outline" onClick={() => { setClearPassword(!clearPassword); setPassword(""); }}>{clearPassword ? "Keep" : "Remove"}</Button>}
            </div>
          </Field>
          <Field label="From name"><input className={inputCls} maxLength={80} value={d.smtp.fromName} onChange={(e) => set("smtp", { ...d.smtp, fromName: e.target.value })} /></Field>
          <Field label="From address"><input type="email" className={inputCls} value={d.smtp.fromEmail} onChange={(e) => set("smtp", { ...d.smtp, fromEmail: e.target.value.trim() })} placeholder="no-reply@plexscale.com" /></Field>
          <Field label="Reply-to address (optional)"><input type="email" className={inputCls} value={d.smtp.replyTo} onChange={(e) => set("smtp", { ...d.smtp, replyTo: e.target.value.trim() })} placeholder="help@plexscale.com" /></Field>
          <Field label="Staff inbox for ticket alerts (optional)"><input type="email" className={inputCls} value={d.staffEmail} onChange={(e) => set("staffEmail", e.target.value.trim())} placeholder="support@plexscale.com" /></Field>
        </div>
      </Card>

      <Card title="Discord ticket alerts" sub="Posts new tickets and replies to Discord." actions={<Button type="button" variant="outline" onClick={async () => { const r = await testDiscord(); (r.ok ? toast.success : toast.error)(r.message); }} disabled={!data.discordWebhookSet}><Send />Send test alert</Button>}>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="flex flex-wrap gap-5 md:col-span-2">
            <Toggle checked={d.discord.enabled} onChange={(v) => set("discord", { ...d.discord, enabled: v })} label="Discord alerts on" />
            <Toggle checked={d.discord.notifyNewTickets} onChange={(v) => set("discord", { ...d.discord, notifyNewTickets: v })} label="New tickets" />
            <Toggle checked={d.discord.notifyReplies} onChange={(v) => set("discord", { ...d.discord, notifyReplies: v })} label="Customer replies" />
          </div>
          <Field label="Webhook address" hint={data.discordWebhookSet && !clearWebhook ? "Saved. Paste a new one to replace." : undefined}>
            <div className="flex gap-2">
              <input type="password" className={inputCls} value={webhook} onChange={(e) => { setWebhook(e.target.value.trim()); setClearWebhook(false); }} autoComplete="off" placeholder={data.discordWebhookSet && !clearWebhook ? "••••••••••••" : "https://discord.com/api/webhooks/…"} />
              {data.discordWebhookSet && <Button type="button" variant="outline" onClick={() => { setClearWebhook(!clearWebhook); setWebhook(""); }}>{clearWebhook ? "Keep" : "Remove"}</Button>}
            </div>
          </Field>
          <Field label="Role to mention (optional)" hint="Numeric role ID."><input className={inputCls} value={d.discord.roleId} onChange={(e) => set("discord", { ...d.discord, roleId: e.target.value.trim() })} inputMode="numeric" /></Field>
        </div>
      </Card>

      <Card title="Invoice details" sub="Shown on PDF invoices.">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Business name"><input className={inputCls} maxLength={100} value={d.invoice.businessName} onChange={(e) => set("invoice", { ...d.invoice, businessName: e.target.value })} /></Field>
          <Field label="GSTIN (optional)"><input className={cn(inputCls, "font-mono uppercase")} maxLength={15} value={d.invoice.gstin} onChange={(e) => set("invoice", { ...d.invoice, gstin: e.target.value.toUpperCase().trim() })} /></Field>
          <Field label="Address" className="md:col-span-2"><textarea className={cn(inputCls, "h-auto py-2")} rows={2} maxLength={300} value={d.invoice.address} onChange={(e) => set("invoice", { ...d.invoice, address: e.target.value })} /></Field>
          <Field label="Billing email on invoice"><input type="email" className={inputCls} value={d.invoice.email} onChange={(e) => set("invoice", { ...d.invoice, email: e.target.value.trim() })} placeholder="billing@plexscale.com" /></Field>
          <Field label="Footer note"><input className={inputCls} maxLength={300} value={d.invoice.note} onChange={(e) => set("invoice", { ...d.invoice, note: e.target.value })} /></Field>
        </div>
      </Card>

      <Card title="Email messages" sub="Edit each email. Placeholders fill in automatically.">
        <div className="grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
          <ul className="flex flex-wrap gap-1 lg:flex-col">
            {templateKeys.map((k) => (
              <li key={k}><button type="button" onClick={() => { setActive(k); setPreview(false); }} className={cn("flex w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors", active === k ? "bg-accent text-azure" : "text-muted-foreground hover:text-foreground")}>
                {templateMeta[k].label}<span className={cn("size-1.5 rounded-full", d.templates[k].enabled ? "bg-ok" : "bg-steel")} />
              </button></li>
            ))}
          </ul>
          <div className="min-w-0 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><p className="font-display text-lg">{templateMeta[active].label}</p><p className="text-xs text-muted-foreground">Sent when: {templateMeta[active].when}</p></div>
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="outline" onClick={() => setPreview(!preview)}><Eye />{preview ? "Edit" : "Preview"}</Button>
                <Button type="button" variant="outline" onClick={sendTest} disabled={testing}>{testing ? <Spinner size="xs" /> : <Send />}Send me a test</Button>
              </div>
            </div>
            <Toggle checked={tpl.enabled} onChange={(v) => set("templates", { ...d.templates, [active]: { ...tpl, enabled: v } })} label="Send this email" />
            {preview ? (
              <div className="overflow-hidden rounded-md border border-steel">
                <p className="border-b border-steel bg-ink px-4 py-2 text-sm"><span className="text-muted-foreground">Subject:</span> {renderSubject(tpl.subject, sampleVars)}</p>
                <iframe title="Email preview" sandbox="" srcDoc={previewHtml} className="h-[460px] w-full bg-on-accent" />
              </div>
            ) : (
              <>
                <Field label="Subject"><input className={inputCls} maxLength={160} value={tpl.subject} onChange={(e) => set("templates", { ...d.templates, [active]: { ...tpl, subject: e.target.value } })} /></Field>
                <Field label="Message" hint="Plain text. Blank line starts a new paragraph.">
                  <textarea className={cn(inputCls, "h-auto py-3 font-mono text-[13px] leading-relaxed")} rows={12} maxLength={5000} value={tpl.body} onChange={(e) => set("templates", { ...d.templates, [active]: { ...tpl, body: e.target.value } })} />
                </Field>
              </>
            )}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-muted-foreground">Placeholders:</span>
              {templateMeta[active].vars.map((v) => <code key={v} className="rounded border border-steel bg-ink px-1.5 py-0.5 font-mono text-azure">{`{{${v}}}`}</code>)}
              <button type="button" className="ml-auto text-muted-foreground underline-offset-4 hover:text-foreground hover:underline" onClick={() => set("templates", { ...d.templates, [active]: defaultTemplates[active] })}>Reset to default</button>
            </div>
          </div>
        </div>
      </Card>

      <Card title="Recent email activity" sub="Last 50 emails.">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr><th className={th}>When</th><th className={th}>Email</th><th className={th}>To</th><th className={th}>Result</th></tr></thead>
            <tbody>
              {data.log.length === 0 && <tr><td className={td} colSpan={4}>Nothing sent yet.</td></tr>}
              {data.log.map((l) => (
                <tr key={l.id}>
                  <td className={td}>{new Date(l.created_at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</td>
                  <td className={td}>{templateMeta[l.kind as TemplateKey]?.label ?? l.kind}</td>
                  <td className={cn(td, "font-mono text-xs")}>{l.recipient ?? "-"}</td>
                  <td className={td}><span className={l.status === "sent" ? "text-ok" : l.status === "failed" ? "text-destructive" : "text-muted-foreground"}>{l.status}</span>{l.error ? <span className="block max-w-sm text-xs text-muted-foreground">{l.error}</span> : null}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <p className="flex items-center gap-2 pt-2 text-xs text-muted-foreground"><KeyRound className="size-3.5 text-ok" />Passwords and webhooks are stored encrypted.</p>
      <SaveBar dirty={dirty || secretsDirty} saving={saving} onSave={submit} onDiscard={() => { discard(); setPassword(""); setClearPassword(false); setWebhook(""); setClearWebhook(false); }} label="Save email settings" />
    </div>
  );
}
