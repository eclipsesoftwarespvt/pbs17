import { askConfirm } from "@/components/ui-px/ConfirmHost";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { billingLabel, deployFields, effectivePlans, formatINR, planLines, type DeployValues, gameKeys, productKeys, productNames, type PlanOverride, type ProductKey } from "@/config/plans";
import { defaultSiteSettings, type PanelSettings, type SiteSettings } from "@/config/settings";
import { useLocations } from "@/hooks/use-settings";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, ShoppingCart, RotateCcw, SlidersHorizontal, Globe, Server, CreditCard, Users, LifeBuoy, Mail, Plus, Trash2, ArrowUp, ArrowDown, TicketPercent, BellRing, Boxes, ShieldCheck, Gamepad2, Wallet, Receipt, type LucideIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { LogsPanel } from "./Logs";
import { CouponsPanel } from "./Coupons";
import { CreditsAdmin } from "./Credits";
import { InvoicesPanel } from "./Invoices";
import { PageLoader } from "@/components/ui-px/Spinner";
import { EmailSettingsPanel } from "./EmailSettings";
import { TicketsPanel } from "./Tickets";
import { PlexusSettingsPanel } from "./PlexusSettings";
import { LocationsEditor, VersionsEditor, SaveBar, useSettingsDraft } from "./settings-controls";
import { panelSoftwareKeys, softwareLabel } from "@/config/software";
import { EGG_FILLS, PORT_VARIABLES } from "@/config/egg-env";
import { decideRefund, getAdminData, listPanelAlerts, retryProvision, retryUpgrade, savePanelSettings, saveSiteSettings, setAdmin, setOrderStatus, testPanelConnection } from "@/lib/admin.functions";
import { cn } from "@/lib/utils";
import { Card, Field, inputCls, num, Pill, Segmented, td, th, Toggle } from "./fields";

type NavItem = { key: string; label: string; icon: LucideIcon; sub: string };
const nav = [
  { group: "Business", items: [
    { key: "Overview", label: "Overview", icon: LayoutDashboard, sub: "Revenue, services and connections at a glance." },
    { key: "Orders", label: "Orders", icon: ShoppingCart, sub: "Every order, its status and server setup." },
    { key: "Invoices", label: "Invoices", icon: Receipt, sub: "Every invoice for game servers, VPS, bot hosting and credits. Filter, export and download PDFs." },
    { key: "Refunds", label: "Refunds", icon: RotateCcw, sub: "Refund requests waiting for a decision." },
    { key: "Tickets", label: "Tickets", icon: LifeBuoy, sub: "Customer support conversations." },
    { key: "Coupons", label: "Coupons", icon: TicketPercent, sub: "Discount codes for new orders." },
    { key: "Credits", label: "Credits", icon: Wallet, sub: "Customer balances, adjustments and top-up limits." },
  ] },
  { group: "Catalog", items: [
    { key: "Plans", label: "Plans", icon: SlidersHorizontal, sub: "Prices and resources for every plan." },
    { key: "Inventory", label: "Inventory", icon: Boxes, sub: "Stock, locations and Minecraft versions in one place." },
  ] },
  { group: "Configuration", items: [
    { key: "Site", label: "Site", icon: Globe, sub: "Maintenance, links, alert banner and ordering." },
    { key: "Emails", label: "SMTP & emails", icon: Mail, sub: "Outgoing mail, Discord alerts and email templates." },
    { key: "Panel", label: "Pterodactyl", icon: Gamepad2, sub: "Game panel connection, eggs, locations and ports." },
    { key: "Plexus", label: "Plexus", icon: Server, sub: "VPS panel API, OS image, location and cluster mappings." },
    { key: "Razorpay", label: "Razorpay", icon: CreditCard, sub: "Payment keys and webhook." },
  ] },
  { group: "System", items: [
    { key: "Admins", label: "Admins", icon: Users, sub: "Who can open this console, and your customers." },
    { key: "Logs", label: "Alerts & activity", icon: BellRing, sub: "System alerts and admin activity, with filters." },
  ] },
] as const satisfies readonly { group: string; items: readonly NavItem[] }[];
type Tab = (typeof nav)[number]["items"][number]["key"];
const allItems: readonly NavItem[] = nav.flatMap((g) => g.items as readonly NavItem[]);
const orderStatuses = ["pending", "provisioning", "active", "suspended", "cancelled", "refunded", "failed"];
const when = (s: string | null) => (s ? new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "-");
const errMsg = (_e: unknown) => "That action could not be completed. Please try again.";
const IDLE_SIGN_OUT_MS = 20 * 60_000;

/** Signs the admin out after a period with no keyboard, mouse or touch activity. */
function useIdleSignOut(ms: number) {
  useEffect(() => {
    let warnTimer = 0;
    let outTimer = 0;
    const reset = () => {
      window.clearTimeout(warnTimer); window.clearTimeout(outTimer);
      warnTimer = window.setTimeout(() => toast.warning("For security you'll be signed out in 1 minute. Move the mouse to stay signed in."), ms - 60_000);
      outTimer = window.setTimeout(async () => { await supabase.auth.signOut(); window.location.assign("/auth"); }, ms);
    };
    const events = ["pointerdown", "pointermove", "keydown", "scroll", "touchstart"] as const;
    events.forEach((e) => window.addEventListener(e, reset, { passive: true }));
    reset();
    return () => { window.clearTimeout(warnTimer); window.clearTimeout(outTimer); events.forEach((e) => window.removeEventListener(e, reset)); };
  }, [ms]);
}

export function AdminPanel() {
  const qc = useQueryClient();
  const load = useServerFn(getAdminData);
  const alerts = useServerFn(listPanelAlerts);
  const [tab, setTab] = useState<Tab>("Overview");
  const [email, setEmail] = useState<string | null>(null);
  const { data, isLoading, error } = useQuery({ queryKey: ["admin-data"], queryFn: () => load() });
  const { data: openAlerts } = useQuery({ queryKey: ["panel-alerts", "open", ""], queryFn: () => alerts({ data: { status: "open", q: "" } }) });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["admin-data"] }); qc.invalidateQueries({ queryKey: ["site-settings"] }); };
  useIdleSignOut(IDLE_SIGN_OUT_MS);
  useEffect(() => { void supabase.auth.getSession().then(({ data: s }) => setEmail(s.session?.user.email ?? null)); }, []);


  if (isLoading) return <PageLoader text="Loading administration" />;
  if (error || !data) return <section className="section container-px"><p className="text-destructive">Could not load administration data.</p></section>;
  const current = allItems.find((i) => i.key === tab) ?? allItems[0]!;
  const badges: Partial<Record<Tab, number>> = {
    Logs: openAlerts?.length ?? 0,
    Refunds: data.refunds.filter((r) => r.status === "requested").length,
  };

  return (
    <section className="admin-shell section container-px">
      <header className="flex flex-wrap items-end justify-between gap-4 border-b border-steel pb-6">
        <div>
          <h1 className="text-3xl md:text-4xl">Administrator</h1>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-2 rounded-full border border-ok/40 bg-ok/10 px-3 py-1 text-xs text-ok" title="Every action is checked on the server. You are signed out after 20 minutes without activity.">
            <ShieldCheck className="size-3.5" />Secure session
          </span>
          {email && <span className="hidden text-sm text-muted-foreground sm:inline">{email}</span>}
          
        </div>
      </header>
      <div className="mt-8 grid gap-8 lg:grid-cols-[220px_minmax(0,1fr)]">
        <nav className="flex gap-6 overflow-x-auto pb-2 lg:sticky lg:top-24 lg:h-fit lg:flex-col lg:gap-5 lg:overflow-visible lg:pb-0" aria-label="Administration">
          {nav.map((g) => (
            <div key={g.group} className="flex shrink-0 gap-1 lg:flex-col">
              <p className="hidden px-3 pb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground lg:block">{g.group}</p>
              {(g.items as readonly NavItem[]).map((item) => {
                const Icon = item.icon;
                const active = tab === item.key;
                const badge = badges[item.key as Tab] ?? 0;
                return (
                  <Button key={item.key} type="button" variant="ghost" aria-current={active ? "page" : undefined} onClick={() => setTab(item.key as Tab)}
                    className={cn("group h-9 shrink-0 justify-start gap-2.5 px-3 text-sm",
                      active ? "bg-accent font-semibold text-accent-foreground hover:bg-accent" : "text-muted-foreground hover:bg-graphite hover:text-foreground")}>
                    <Icon className={cn("size-4", active ? "text-foreground" : "text-muted-foreground group-hover:text-foreground")} />
                    <span className="flex-1 text-left">{item.label}</span>
                    {badge > 0 && <span className="rounded-full bg-destructive/15 px-1.5 text-xs font-medium text-destructive">{badge}</span>}
                  </Button>
                );
              })}
            </div>
          ))}
        </nav>
        <div id="admin-content" className="min-w-0">
          <div className="mb-6">
            <h2 className="text-2xl font-semibold tracking-tight">{current.label}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{current.sub}</p>
          </div>
          {tab === "Overview" && <Overview data={data} />}
          {tab === "Orders" && <Orders data={data} onChange={refresh} />}
          {tab === "Refunds" && <Refunds data={data} onChange={refresh} />}
          {tab === "Tickets" && <TicketsPanel />}
          {tab === "Emails" && <EmailSettingsPanel />}
          {(tab === "Plans" || tab === "Inventory" || tab === "Site") && <SiteEditor key="site-settings" initial={data.site} onSaved={refresh} section={tab === "Plans" ? "plans" : tab === "Inventory" ? "inventory" : "site"} />}
          {tab === "Panel" && <PanelEditor initial={data.panel} connected={data.setup.panel} onSaved={refresh} />}
          {tab === "Plexus" && <PlexusSettingsPanel key="plexus-settings" panel={data.panel} site={data.site} connected={data.setup.plexus} onSaved={refresh} />}
          {tab === "Razorpay" && <Razorpay setup={data.setup} />}
          {tab === "Admins" && <Admins data={data} onChange={refresh} />}
          {tab === "Logs" && <LogsPanel rows={data.audit} profiles={data.profiles} onChange={refresh} />}
          {tab === "Coupons" && <CouponsPanel />}
          {tab === "Credits" && <CreditsAdmin site={data.site} onSaved={refresh} />}
          {tab === "Invoices" && <InvoicesPanel />}
        </div>
      </div>
    </section>
  );
}

type Data = Awaited<ReturnType<typeof getAdminData>>;

function Overview({ data }: { data: Data }) {
  // Cash received through Razorpay. Credit-paid orders were already counted when the credits were bought.
  const paid = data.orders.filter((o) => o.paid_at && o.status !== "refunded" && o.paid_with !== "credits");
  const monthAgo = Date.now() - 30 * 864e5;
  const stats: [string, string | number][] = [
    ["Clients", data.profiles.length],
    ["Revenue, all time", formatINR(paid.reduce((s, o) => s + o.amount, 0))],
    ["Revenue, 30 days", formatINR(paid.filter((o) => new Date(o.paid_at ?? "").getTime() > monthAgo).reduce((s, o) => s + o.amount, 0))],
    ["Active services", data.orders.filter((o) => o.status === "active").length],
    ["Waiting for setup", data.orders.filter((o) => o.status === "provisioning").length],
    ["Suspended", data.orders.filter((o) => o.status === "suspended").length],
    ["Open refunds", data.refunds.filter((r) => r.status === "requested").length],
    ["Unpaid checkouts", data.orders.filter((o) => o.status === "pending").length],
  ];
  const problems = data.orders.filter((o) => o.status === "provisioning" || (o.kind === "upgrade" && o.status === "upgraded" && o.provision_error));
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map(([k, v]) => <div key={k} className="rounded-xl border border-steel bg-graphite/60 p-5"><p className="text-xs uppercase tracking-wide text-muted-foreground">{k}</p><p className="mt-2 font-display text-2xl">{v}</p></div>)}
      </div>
      <Card title="Service connections">
        <div className="flex flex-wrap gap-3">
          <Pill ok={data.setup.razorpay}>Razorpay keys</Pill>
          <Pill ok={data.setup.webhook}>Razorpay webhook</Pill>
          <Pill ok={data.setup.panel}>Game panel API</Pill>
          <Pill ok={data.setup.turnstile}>{data.setup.turnstile ? "Turnstile keys" : "Turnstile keys (test mode)"}</Pill>
          <Pill ok={Object.keys(data.panel.eggs).length > 0}>Eggs mapped</Pill>
          <Pill ok={Object.keys(data.panel.locations).length > 0}>Locations mapped</Pill>
        </div>
      </Card>
      {problems.length > 0 && (
        <Card title="Needs attention">
          <ul className="space-y-2 text-sm">{problems.map((o) => <li key={o.id} className="rounded-md border border-steel p-3"><span className="font-semibold">{o.server_name || o.plan_name}</span> · {o.kind === "upgrade" ? `Upgrade to ${o.plan_name}: ${o.provision_error}` : "Setup needs attention. Retry setup from Orders."}</li>)}</ul>
        </Card>
      )}
    </div>
  );
}

function Orders({ data, onChange }: { data: Data; onChange: () => void }) {
  const locations = useLocations();
  const setStatus = useServerFn(setOrderStatus);
  const retry = useServerFn(retryProvision);
  const retryUp = useServerFn(retryUpgrade);
  const [filter, setFilter] = useState("all");
  const [q, setQ] = useState("");
  const who = (id: string) => data.profiles.find((p) => p.id === id)?.email ?? id.slice(0, 8);
  const rows = data.orders.filter((o) => (filter === "all" || (filter === "deleted" ? Boolean(o.server_deleted_at) : o.status === filter)) && (!q || `${o.server_name} ${o.plan_name} ${who(o.user_id)} ${o.id}`.toLowerCase().includes(q.toLowerCase())));

  async function change(id: string, status: string) {
    if (!(await askConfirm(`Change this order to "${status}"?`))) return;
    try { const r = await setStatus({ data: { orderId: id, status } }); toast.success(r.message); onChange(); } catch (e) { toast.error(errMsg(e)); }
  }
  async function doRetryUpgrade(id: string) {
    try { const r = await retryUp({ data: { orderId: id } }); (r.ok ? toast.success : toast.error)(r.message); onChange(); } catch (e) { toast.error(errMsg(e)); }
  }
  async function doRetry(id: string) {
    try { const r = await retry({ data: { orderId: id } }); (r.ok ? toast.success : toast.error)(r.message); onChange(); } catch (e) { toast.error(errMsg(e)); }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email or order id" className={cn(inputCls, "max-w-xs")} />
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className={cn(inputCls, "w-48")}>
          <option value="all">All statuses</option>
          {[...orderStatuses, "renewed", "upgraded", "credited"].map((s) => <option key={s}>{s}</option>)}
          <option value="deleted">deleted (server removed)</option>
        </select>
      </div>
      <div className="panel overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr><th className={th}>Created</th><th className={th}>Customer</th><th className={th}>Server</th><th className={th}>Plan</th><th className={th}>Amount</th><th className={th}>Paid until</th><th className={th}>Status</th><th className={th} /></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td className={td} colSpan={8}>No orders.</td></tr>}
            {rows.map((o) => (
              <tr key={o.id}>
                <td className={td}>{when(o.created_at)}</td>
                <td className={td}>{who(o.user_id)}</td>
                <td className={td}>
                  <p className="font-medium">{o.server_name || "-"}</p>
                  <p className="text-xs text-muted-foreground">{o.paid_with === "credits" ? "Paid with credits · " : ""}{o.kind === "credits" ? "Credits top-up" : o.kind === "renewal" ? "Renewal" : o.kind === "upgrade" ? `Upgrade${o.provision_error ? ` · ${o.provision_error}` : ""}` : `${softwareLabel(o.product, o.software)}${o.version ? ` ${o.version}` : ""}`} · {locations.find((l) => l.id === o.location)?.city ?? o.location}{o.ptero_identifier ? ` · ${o.ptero_identifier}` : ""}{o.discount > 0 ? ` · coupon -${formatINR(o.discount)}` : ""}</p>
                  {o.server_deleted_at && <p className="text-xs text-destructive">Server deleted {when(o.server_deleted_at)}</p>}
                </td>
                <td className={td}>{o.kind === "credits" ? "Credits" : `${o.plan_name} · ${billingLabel(o.billing)}`}</td>
                <td className={td}>{formatINR(o.amount)}</td>
                <td className={td}>{when(o.renews_at)}</td>
                <td className={td}>
                  {o.kind !== "new" ? <span className="text-muted-foreground">{o.status}</span> : (
                    <select className={cn(inputCls, "h-9 w-36")} value={o.status} onChange={(e) => change(o.id, e.target.value)}>{orderStatuses.map((s) => <option key={s}>{s}</option>)}</select>
                  )}
                </td>
                <td className={td}>
                  {o.status === "provisioning" && o.kind === "new" && <Button type="button" onClick={() => doRetry(o.id)} variant="secondary">Retry setup</Button>}
                  {o.kind === "upgrade" && o.status === "upgraded" && o.provision_error && <Button type="button" onClick={() => doRetryUpgrade(o.id)} variant="secondary">Retry upgrade</Button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Refunds({ data, onChange }: { data: Data; onChange: () => void }) {
  const decide = useServerFn(decideRefund);
  const who = (id: string) => data.profiles.find((p) => p.id === id)?.email ?? id.slice(0, 8);
  async function go(id: string, approve: boolean) {
    if (!(await askConfirm(approve ? "Send this refund through Razorpay? The service will be suspended." : "Reject this refund?"))) return;
    try { const r = await decide({ data: { refundId: id, approve } }); toast.success(r.message); onChange(); } catch (e) { toast.error(errMsg(e)); }
  }
  return (
    <div className="panel overflow-x-auto">
      <table className="w-full text-sm">
        <thead><tr><th className={th}>Requested</th><th className={th}>Customer</th><th className={th}>Order</th><th className={th}>Reason</th><th className={th}>Status</th><th className={th} /></tr></thead>
        <tbody>
          {data.refunds.length === 0 && <tr><td className={td} colSpan={6}>No refund requests.</td></tr>}
          {data.refunds.map((r) => {
            const o = data.orders.find((x) => x.id === r.order_id);
            return (
              <tr key={r.id}>
                <td className={td}>{when(r.created_at)}</td><td className={td}>{who(r.user_id)}</td>
                <td className={td}>{o ? `${o.server_name || o.plan_name} · ${formatINR(o.amount)} · paid ${when(o.paid_at)}` : r.order_id.slice(0, 8)}</td>
                <td className={cn(td, "max-w-sm")}>{r.reason}</td><td className={td}>{r.status}</td>
                <td className={td}>{r.status === "requested" && <div className="flex gap-2"><Button type="button" onClick={() => go(r.id, true)}>Refund</Button><Button type="button" onClick={() => go(r.id, false)} variant="danger-ghost">Reject</Button></div>}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function SiteEditor({ initial, onSaved, section }: { initial: SiteSettings; onSaved: () => void; section: "site" | "plans" | "inventory" }) {
  const save = useServerFn(saveSiteSettings);
  const [view, setView] = useState<"stock" | "locations" | "versions">("stock");
  const { draft: d, setDraft: setD, dirty, discard, accept } = useSettingsDraft(initial);
  const [saving, setSaving] = useState(false);
  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => setD((p) => ({ ...p, [k]: v }));

  async function submit() {
    setSaving(true);
    try { await save({ data: d }); accept(d); toast.success("Saved. Changes are live."); onSaved(); } catch (e) { toast.error(errMsg(e).slice(0, 200)); }
    setSaving(false);
  }
  const saveBar = <SaveBar dirty={dirty} saving={saving} onSave={submit} onDiscard={discard} />;

  if (section === "plans") return <div className="space-y-6"><PlansEditor value={d.plans} onChange={(v) => set("plans", v)} />{saveBar}</div>;
  if (section === "inventory") return (
    <div className="space-y-6">
      <Segmented label="Inventory view" value={view} onChange={setView} options={[
        { value: "stock", label: "Stock" },
        { value: "locations", label: "Nodes & locations" },
        { value: "versions", label: "Versions" },
      ]} />
      {view === "stock" && <>
        <Card title="Out of stock products" sub="Blocks new orders and upgrades. Existing services keep running.">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {productKeys.map((p) => {
              const out = d.ordering.disabledProducts.includes(p);
              return (
                <label key={p} className={cn("flex cursor-pointer items-center justify-between gap-3 rounded-md border p-4 text-sm transition-colors", out ? "border-destructive/50 bg-destructive/10" : "border-steel hover:border-azure/60")}>
                  <span><span className="block font-display font-semibold">{productNames[p]}</span><span className={cn("text-xs", out ? "text-destructive" : "text-ok")}>{out ? "Out of stock" : "In stock"}</span></span>
                  <input type="checkbox" className="size-4 accent-azure" checked={out} onChange={(e) => set("ordering", { ...d.ordering, disabledProducts: e.target.checked ? [...new Set([...d.ordering.disabledProducts, p])] : d.ordering.disabledProducts.filter((x) => x !== p) })} />
                </label>
              );
            })}
          </div>
        </Card>
        <Card title="Coming soon" sub="Shows a Coming soon label on the menu, homepage, footer and plan page, and keeps orders closed until you switch it off.">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {productKeys.map((p) => {
              const soon = d.ordering.comingSoon.includes(p);
              return (
                <label key={p} className={cn("flex cursor-pointer items-center justify-between gap-3 rounded-md border p-4 text-sm transition-colors", soon ? "border-azure/60 bg-azure/10" : "border-steel hover:border-azure/60")}>
                  <span><span className="block font-display font-semibold">{productNames[p]}</span><span className={cn("text-xs", soon ? "text-azure-bright" : "text-muted-foreground")}>{soon ? "Coming soon" : "Available"}</span></span>
                  <input type="checkbox" className="size-4 accent-azure" checked={soon} onChange={(e) => set("ordering", { ...d.ordering, comingSoon: e.target.checked ? [...new Set([...d.ordering.comingSoon, p])] : d.ordering.comingSoon.filter((x) => x !== p) })} />
                </label>
              );
            })}
          </div>
        </Card>
        <Card title="Out of stock locations" sub="No new servers in these locations.">
          <div className="flex flex-wrap gap-4">{d.locations.map((l) => <Toggle key={l.id} label={l.city} checked={d.ordering.disabledLocations.includes(l.id)} onChange={(v) => set("ordering", { ...d.ordering, disabledLocations: v ? [...new Set([...d.ordering.disabledLocations, l.id])] : d.ordering.disabledLocations.filter((x) => x !== l.id) })} />)}</div>
        </Card>
        <ProductLocationsEditor value={d} onChange={(ordering) => set("ordering", ordering)} />
      </>}
      {view === "locations" && <LocationsEditor value={d} onChange={setD} />}
      {view === "versions" && <VersionsEditor value={d.minecraftVersions} onChange={(v) => set("minecraftVersions", v)} />}
      {saveBar}
    </div>
  );

  return (
    <div className="space-y-6">
      <MaintenanceEditor value={d.maintenance} onChange={(v) => set("maintenance", v)} />
      <Card title="Links and contact">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Discord invite link"><input className={inputCls} value={d.discordUrl} onChange={(e) => set("discordUrl", e.target.value)} placeholder="https://discord.gg/..." /></Field>
          <Field label="Discord label"><input className={inputCls} value={d.discordLabel} onChange={(e) => set("discordLabel", e.target.value)} /></Field>
          <Field label="Support email"><input className={inputCls} type="email" value={d.supportEmail} onChange={(e) => set("supportEmail", e.target.value)} /></Field>
          <div />
          <Field label="Game Panel address"><input className={inputCls} value={d.gamePanelUrl} onChange={(e) => set("gamePanelUrl", e.target.value)} /></Field>
          <Field label="VPS Panel address"><input className={inputCls} value={d.vpsPanelUrl} onChange={(e) => set("vpsPanelUrl", e.target.value)} /></Field>
        </div>
      </Card>
      <Card title="Alert banner">
        <div className="grid gap-4 md:grid-cols-2">
          <Toggle checked={d.announcement.enabled} onChange={(v) => set("announcement", { ...d.announcement, enabled: v })} label="Show the banner" />
          <Field label="Style">
            <select className={inputCls} value={d.announcement.tone} onChange={(e) => set("announcement", { ...d.announcement, tone: e.target.value as SiteSettings["announcement"]["tone"] })}>
              <option value="info">Information</option><option value="success">Good news</option><option value="warning">Warning</option><option value="danger">Urgent</option>
            </select>
          </Field>
          <Field label="Message" className="md:col-span-2"><input className={inputCls} maxLength={240} value={d.announcement.message} onChange={(e) => set("announcement", { ...d.announcement, message: e.target.value })} placeholder="Scheduled maintenance in Mumbai on Sunday 2 AM IST." /></Field>
          <Field label="Link text (optional)"><input className={inputCls} maxLength={40} value={d.announcement.linkLabel} onChange={(e) => set("announcement", { ...d.announcement, linkLabel: e.target.value })} /></Field>
          <Field label="Link address (optional)"><input className={inputCls} value={d.announcement.linkUrl} onChange={(e) => set("announcement", { ...d.announcement, linkUrl: e.target.value })} placeholder="https://..." /></Field>
        </div>
      </Card>
      <Card title="Ordering">
        <div className="grid gap-5">
          <Toggle checked={d.ordering.enabled} onChange={(v) => set("ordering", { ...d.ordering, enabled: v })} label="Accept new orders" />
          <Field label="Message when orders are paused"><input className={inputCls} maxLength={240} value={d.ordering.pausedMessage} onChange={(e) => set("ordering", { ...d.ordering, pausedMessage: e.target.value })} /></Field>
        </div>
      </Card>
      <div className="flex justify-between gap-2">
        <Button type="button" onClick={() => setD({ ...d, discordUrl: defaultSiteSettings.discordUrl, discordLabel: defaultSiteSettings.discordLabel, supportEmail: defaultSiteSettings.supportEmail })} variant="text">Reset links to defaults</Button>
      </div>
      {saveBar}
    </div>
  );
}


function PlansEditor({ value, onChange }: { value: Record<string, PlanOverride>; onChange: (v: Record<string, PlanOverride>) => void }) {
  const [product, setProduct] = useState<ProductKey | "allgames">("minecraft");
  const [open, setOpen] = useState<string | null>(null);
  const [linesOpen, setLinesOpen] = useState<string | null>(null);
  function patchDeploy(id: string, k: keyof DeployValues, v: unknown) {
    const cur: Record<string, unknown> = { ...(value[id]?.deploy ?? {}) };
    if (v === undefined || v === "" || (typeof v === "number" && Number.isNaN(v))) delete cur[k]; else cur[k] = v;
    patch(id, "deploy", Object.keys(cur).length ? cur : undefined);
  }
  const shown: ProductKey[] = product === "allgames" ? gameKeys : [product];

  function patch(id: string, k: keyof PlanOverride, v: unknown) {
    const cur: Record<string, unknown> = { ...(value[id] ?? {}) };
    if (v === undefined || v === "" || (typeof v === "number" && Number.isNaN(v))) delete cur[k]; else cur[k] = v;
    const next = { ...value };
    if (Object.keys(cur).length) next[id] = cur as PlanOverride; else delete next[id];
    onChange(next);
  }
  function addPlan() {
    const next = { ...value };
    for (const p of shown) {
      const id = `c-${p}-${crypto.randomUUID().slice(0, 6)}`;
      next[id] = { custom: true, product: p, name: "New plan", monthly: 199, cpuPercent: 100, ramGb: 4, diskGb: 40, ...(p === "vps" ? { vcpu: 2 } : {}) };
    }
    onChange(next);
  }
  async function remove(id: string) {
    if (!(await askConfirm("Delete this plan?"))) return;
    const next = { ...value }; delete next[id]; onChange(next);
  }

  return (
    <Card title="Plans"
      actions={<div className="flex flex-wrap gap-2">
        <select className={cn(inputCls, "w-48")} value={product} onChange={(e) => setProduct(e.target.value as ProductKey | "allgames")}>
          <option value="allgames">All game servers</option>
          {productKeys.map((p) => <option key={p} value={p}>{productNames[p]}</option>)}
        </select>
        <Button type="button" onClick={addPlan}>{product === "allgames" ? "Add plan to all games" : "Add plan"}</Button>
      </div>}>
      <div className="space-y-8">
        {shown.map((prod) => {
          const isVps = prod === "vps";
          const plans = effectivePlans(prod, value, true);
          return (
            <div key={prod}>
              {shown.length > 1 && <h3 className="mb-2 text-lg font-semibold">{productNames[prod]}</h3>}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr><th className={th}>Name</th><th className={th}>Price ₹/mo</th><th className={th}>{isVps ? "vCPU" : "CPU %"}</th><th className={th}>RAM GB</th><th className={th}>Disk GB</th><th className={th}>Popular</th><th className={th}>Hidden</th><th className={th} /></tr></thead>
                  <tbody>
                    {plans.length === 0 && <tr><td className={td} colSpan={8}>No plans.</td></tr>}
                    {plans.map((p) => {
                      const o = value[p.id] ?? {};
                      const cell = (k: "monthly" | "cpuPercent" | "ramGb" | "diskGb" | "vcpu", step = 1) => (
                        <input type="number" min={0} step={step} className={cn(inputCls, "h-9 w-20")} value={p[k] ?? ""} onChange={(e) => patch(p.id, k, num(e.target.value))} />
                      );
                      return [
                        <tr key={p.id} className={cn(o.hidden && "opacity-50")}>
                          <td className={td}><input className={cn(inputCls, "h-9 w-32")} maxLength={40} value={o.name ?? p.name} onChange={(e) => patch(p.id, "name", e.target.value)} /></td>
                          <td className={td}>{cell("monthly")}</td>
                          <td className={td}>{isVps ? cell("vcpu") : cell("cpuPercent", 5)}</td>
                          <td className={td}>{cell("ramGb", 0.5)}</td><td className={td}>{cell("diskGb")}</td>
                          <td className={td}><input type="checkbox" className="size-4 accent-azure" checked={Boolean(p.popular)} onChange={(e) => patch(p.id, "popular", e.target.checked)} /></td>
                          <td className={td}><input type="checkbox" className="size-4 accent-azure" checked={Boolean(o.hidden)} onChange={(e) => patch(p.id, "hidden", e.target.checked || undefined)} /></td>
                          <td className={td}><div className="flex flex-col items-start gap-0.5">
                            <Button type="button" onClick={() => setLinesOpen(linesOpen === p.id ? null : p.id)} variant="text" size="xs">{linesOpen === p.id ? "Close lines" : "Card lines"}</Button>
                            <Button type="button" onClick={() => setOpen(open === p.id ? null : p.id)} variant="text" size="xs">{open === p.id ? "Close" : "Deploy values"}</Button>
                            {o.custom && <Button type="button" onClick={() => remove(p.id)} variant="danger-ghost" size="xs">Delete</Button>}
                          </div></td>
                        </tr>,
                        linesOpen === p.id && (
                          <tr key={`${p.id}-lines`}><td className={td} colSpan={8}>
                            <CardLinesEditor custom={Boolean(o.lines?.length)} lines={o.lines?.length ? o.lines : planLines(p, defaultFeatures(prod))} onChange={(lines) => patch(p.id, "lines", lines && lines.length ? lines : undefined)} />
                          </td></tr>
                        ),
                        open === p.id && (
                          <tr key={`${p.id}-deploy`}><td className={td} colSpan={8}>
                            <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
                              {deployFields.map((f) => {
                                const auto = f.key === "memoryMib" ? Math.round(p.ramGb * 1024) : f.key === "diskMib" ? p.diskGb * 1024 : f.key === "cpu" ? p.cpuPercent : undefined;
                                return (
                                  <Field key={f.key} label={f.label}>
                                    <input type={f.text ? "text" : "number"} className={cn(inputCls, "h-9")} placeholder={auto !== undefined ? String(auto) : "Panel default"}
                                      value={o.deploy?.[f.key] ?? ""} onChange={(e) => patchDeploy(p.id, f.key, f.text ? e.target.value.trim() : num(e.target.value))} />
                                  </Field>
                                );
                              })}
                            </div>
                          </td></tr>
                        ),
                      ];
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

/** Same feature lines the public plan pages pass in, so the editor starts from what customers see. */
function defaultFeatures(product: ProductKey): string[] {
  if (product === "vps") return ["Full root access", "DDoS protection, up to 480 Gbps"];
  if (product === "bot") return ["Node.js and Python", "Live console and file manager"];
  return ["AMD EPYC 9V74 / 7763, up to 3.70 GHz", "DDoS protection, up to 480 Gbps"];
}

function CardLinesEditor({ lines, custom, onChange }: { lines: string[]; custom: boolean; onChange: (lines: string[] | undefined) => void }) {
  const edit = (next: string[]) => onChange(next);
  const move = (i: number, by: number) => { const next = [...lines]; const [x] = next.splice(i, 1); next.splice(i + by, 0, x ?? ""); edit(next); };
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground"><span className="font-mono text-foreground">Label: text</span> greys out the label. {custom ? "Custom lines." : "Automatic lines."}</p>
      <ul className="space-y-2">
        {lines.map((line, i) => (
          <li key={i} className="flex items-center gap-2">
            <input className={cn(inputCls, "h-9 flex-1")} maxLength={120} value={line} onChange={(e) => edit(lines.map((l, j) => (j === i ? e.target.value : l)))} />
            <Button type="button" variant="ghost" size="icon" aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp /></Button>
            <Button type="button" variant="ghost" size="icon" aria-label="Move down" disabled={i === lines.length - 1} onClick={() => move(i, 1)}><ArrowDown /></Button>
            <Button type="button" variant="ghost" size="icon" aria-label="Remove line" disabled={lines.length <= 1} onClick={() => edit(lines.filter((_, j) => j !== i))}><Trash2 /></Button>
          </li>
        ))}
      </ul>
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="outline" disabled={lines.length >= 12} onClick={() => edit([...lines, "New line"])}><Plus />Add line</Button>
        {custom && <Button type="button" variant="ghost" onClick={() => onChange(undefined)}>Reset to automatic lines</Button>}
      </div>
    </div>
  );
}

function ProductLocationsEditor({ value, onChange }: { value: SiteSettings; onChange: (ordering: SiteSettings["ordering"]) => void }) {
  const map = value.ordering.productLocations ?? {};
  function toggle(product: ProductKey, id: string, on: boolean) {
    const current = map[product]?.length ? map[product]! : value.locations.map((l) => l.id);
    const nextList = on ? [...new Set([...current, id])] : current.filter((x) => x !== id);
    if (nextList.length === 0) { toast.error("Keep at least one location for each product."); return; }
    const next = { ...map };
    if (nextList.length === value.locations.length) delete next[product]; else next[product] = value.locations.map((l) => l.id).filter((x) => nextList.includes(x));
    onChange({ ...value.ordering, productLocations: next });
  }
  return (
    <Card title="Locations per product" sub="Where each product can be deployed.">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr><th className={th}>Product</th>{value.locations.map((l) => <th key={l.id} className={th}>{l.city}</th>)}</tr></thead>
          <tbody>
            {productKeys.map((p) => (
              <tr key={p}>
                <td className={cn(td, "font-medium")}>{productNames[p]}</td>
                {value.locations.map((l) => {
                  const on = !map[p]?.length || map[p]!.includes(l.id);
                  return <td key={l.id} className={td}><input type="checkbox" aria-label={`${productNames[p]} in ${l.city}`} className="size-4 accent-azure" checked={on} onChange={(e) => toggle(p, l.id, e.target.checked)} /></td>;
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function MaintenanceEditor({ value, onChange }: { value: SiteSettings["maintenance"]; onChange: (v: SiteSettings["maintenance"]) => void }) {
  return (
    <Card title="Global maintenance" sub="Locks the site for everyone except admins. Running servers are not affected.">
      <div className={cn("rounded-md border p-4", value.enabled ? "border-destructive/50 bg-destructive/10" : "border-steel")}>
        <Toggle checked={value.enabled} onChange={(v) => onChange({ ...value, enabled: v })} label={value.enabled ? "Maintenance is on" : "Turn on maintenance"} />
      </div>
      <div className="mt-5 grid gap-4">
        <Field label="Headline"><input className={inputCls} maxLength={80} value={value.title} onChange={(e) => onChange({ ...value, title: e.target.value })} /></Field>
        <Field label="Message"><textarea className={cn(inputCls, "h-auto py-2")} rows={3} maxLength={400} value={value.message} onChange={(e) => onChange({ ...value, message: e.target.value })} /></Field>
      </div>
    </Card>
  );
}

/** "KEY=value" lines → map. Bad lines are skipped; the server validates again on save. */
function parseEnvLines(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of text.split("\n")) {
    const i = line.indexOf("=");
    if (i < 1) continue;
    const k = line.slice(0, i).trim().toUpperCase();
    if (/^[A-Z0-9_]{1,60}$/.test(k)) out[k] = line.slice(i + 1).trim().slice(0, 500);
  }
  return out;
}

function EnvBox({ value, disabled, placeholder, onCommit }: { value: Record<string, string>; disabled: boolean; placeholder: string; onCommit: (text: string) => void }) {
  const text = Object.entries(value).map(([k, v]) => `${k}=${v}`).join("\n");
  const [draft, setDraft] = useState(text);
  useEffect(() => setDraft(text), [text]);
  return <textarea rows={2} className={cn(inputCls, "h-auto w-64 py-1.5 font-mono text-xs")} value={draft} disabled={disabled} placeholder={placeholder} onChange={(e) => setDraft(e.target.value)} onBlur={() => onCommit(draft)} />;
}

/** Example fixed values per game, shown as the placeholder of the "Fixed values" box. */
const envExamples: Record<string, string> = { cs2: "RCON_ENABLED=1", rust: "SAVEINTERVAL=600", palworld: "ENABLE_ENEMY=False", ark: "MOD_ID=928102085", gmod: "TICKRATE=33", hytale: "INSTALL_SOURCEQUERY_PLUGIN=1" };

/** What the site sets up on its own for a software row: filled values and reserved extra ports. */
function EggNotes({ product, software }: { product: string; software: string }) {
  const fills = EGG_FILLS[product];
  const ports = [...(product === "ark" && software === "evolved" ? ["game port + 1"] : []), ...(PORT_VARIABLES[product] ?? [])];
  if (!fills && !ports.length) return null;
  const summary = [fills && `${fills.length} values`, ports.length > 0 && `${ports.length} extra port${ports.length > 1 ? "s" : ""}`].filter(Boolean).join(" · ");
  const chip = "rounded border border-border bg-background px-1.5 py-0.5 font-mono text-[10px]";
  return (
    <details className="group mt-1 max-w-64 text-xs text-muted-foreground">
      <summary className="cursor-pointer list-none select-none hover:text-foreground [&::-webkit-details-marker]:hidden">
        Auto-filled: {summary} <span className="inline-block transition-transform group-open:rotate-90">›</span>
      </summary>
      <span className="mt-1.5 flex flex-wrap gap-1">
        {fills?.map((v) => <span key={v} className={chip}>{v}</span>)}
        {ports.map((v) => <span key={v} className={cn(chip, "text-azure-bright")}>{v}</span>)}
      </span>
    </details>
  );
}

const versionHints: Record<string, string> = { "minecraft:paper": "MINECRAFT_VERSION", "minecraft:vanilla": "VANILLA_VERSION", "minecraft:fabric": "MC_VERSION", "minecraft:forge": "MC_VERSION", "minecraft:neoforge": "MC_VERSION", "minecraft:spigot": "DL_VERSION" };

function PanelEditor({ initial, connected, onSaved }: { initial: PanelSettings; connected: boolean; onSaved: () => void }) {
  const save = useServerFn(savePanelSettings);
  const test = useServerFn(testPanelConnection);
  const locations = useLocations();
  const { draft: d, setDraft: setD, dirty, discard, accept } = useSettingsDraft(initial);
  const [saving, setSaving] = useState(false);
  const [probe, setProbe] = useState<Awaited<ReturnType<typeof testPanelConnection>> | null>(null);


  function setEgg(key: string, k: "nestId" | "eggId" | "versionVariable" | "dockerImage", v: string) {
    const cur = d.eggs[key] ?? { nestId: 0, eggId: 0, versionVariable: versionHints[key] ?? "", dockerImage: "", env: {} };
    const next = { ...cur, [k]: k === "nestId" || k === "eggId" ? Number(v) || 0 : v };
    const eggs = { ...d.eggs };
    if (!next.nestId && !next.eggId) delete eggs[key]; else eggs[key] = next;
    setD({ ...d, eggs });
  }
  function setEggEnv(key: string, text: string) {
    const cur = d.eggs[key];
    if (!cur) return;
    setD({ ...d, eggs: { ...d.eggs, [key]: { ...cur, env: parseEnvLines(text) } } });
  }
  /** Fills empty location mappings from panel locations whose short code or name matches the node id, city or country. */
  async function autoMatch() {
    let p = probe;
    if (!p?.ok) {
      try { p = await test(); setProbe(p); } catch (e) { toast.error(errMsg(e)); return; }
    }
    if (!p.ok) { toast.error(p.message); return; }
    const norm = (v: string) => v.toLowerCase().replace(/[^a-z0-9]/g, "");
    const next = { ...d.locations };
    let filled = 0;
    for (const l of locations) {
      if (next[l.id]) continue;
      const keys = [norm(l.id), norm(l.city)].filter((k) => k.length >= 3);
      const hit = p.locations.find((pl) => { const n = norm(pl.name); return n.length >= 2 && keys.some((k) => n === k || n.includes(k) || (n.length >= 3 && k.includes(n))); });
      if (hit) { next[l.id] = hit.id; filled++; }
    }
    setD({ ...d, locations: next });
    if (filled) toast.success(`Matched ${filled} location${filled > 1 ? "s" : ""}. Check them, then save.`);
    else toast.message("No new matches. Enter the panel location ID by hand.");
  }
  async function submit() {
    const incomplete = Object.entries(d.eggs).find(([, e]) => !e.nestId || !e.eggId);
    if (incomplete) { toast.error(`Fill both nest and egg for ${incomplete[0]}, or clear both.`); return; }
    setSaving(true);
    try { await save({ data: d }); accept(d); toast.success("Panel settings saved."); onSaved(); } catch (e) { toast.error(errMsg(e).slice(0, 200)); }
    setSaving(false);
  }

  return (
    <div className="space-y-6">
      <Card title="Connection"
        actions={<Button type="button" variant="secondary" onClick={async () => { try { setProbe(await test()); } catch (e) { toast.error(errMsg(e)); } }}>Test connection</Button>}>
        <Pill ok={connected}>{connected ? "API key set" : "API key missing"}</Pill>
        {probe && (probe.ok ? (
          <div className="mt-4 grid gap-4 text-sm md:grid-cols-2">
            <div><p className="font-semibold text-ok">Connected</p><p className="mt-2 text-muted-foreground">Locations on the panel:</p><ul className="mt-1 font-mono text-xs">{probe.locations.map((l) => <li key={l.id}>#{l.id} {l.name}</li>)}</ul></div>
            <div><p className="text-muted-foreground">Eggs (nest / egg):</p><ul className="mt-1 max-h-60 overflow-y-auto font-mono text-xs">{probe.eggs.map((e) => <li key={`${e.nestId}-${e.eggId}`}>{e.nestId} / {e.eggId} · {e.nest} › {e.egg}</li>)}</ul></div>
          </div>
        ) : <p className="mt-4 text-sm text-destructive">{probe.message}</p>)}
      </Card>
      <Card title="Software eggs" sub="Which panel nest and egg each software uses. The site fills the listed startup values and reserves the extra ports on its own; fixed values override them (a customer's own Steam token always wins).">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr><th className={th}>Software</th><th className={th}>Nest ID</th><th className={th}>Egg ID</th><th className={th}>Version variable</th><th className={th}>Docker image (optional)</th><th className={th}>Fixed values (KEY=value)</th></tr></thead>
            <tbody>
              {panelSoftwareKeys.map((s) => {
                const e = d.eggs[s.key];
                return (
                  <tr key={s.key}>
                    <td className={td}><span className="font-medium">{productNames[s.product]}</span> · {s.label}<EggNotes product={s.product} software={s.key.split(":")[1] ?? ""} /></td>
                    <td className={td}><input type="number" min={1} className={cn(inputCls, "h-9 w-20")} value={e?.nestId || ""} onChange={(ev) => setEgg(s.key, "nestId", ev.target.value)} /></td>
                    <td className={td}><input type="number" min={1} className={cn(inputCls, "h-9 w-20")} value={e?.eggId || ""} onChange={(ev) => setEgg(s.key, "eggId", ev.target.value)} /></td>
                    <td className={td}><input className={cn(inputCls, "h-9 w-44 font-mono")} value={e?.versionVariable ?? ""} placeholder={versionHints[s.key] ?? ""} disabled={!e} onChange={(ev) => setEgg(s.key, "versionVariable", ev.target.value.toUpperCase())} /></td>
                    <td className={td}><input className={cn(inputCls, "h-9 w-64 font-mono")} value={e?.dockerImage ?? ""} disabled={!e} onChange={(ev) => setEgg(s.key, "dockerImage", ev.target.value)} placeholder="Egg default" /></td>
                    <td className={td}><EnvBox value={e?.env ?? {}} disabled={!e} placeholder={envExamples[s.product] ?? "KEY=value"} onCommit={(t) => setEggEnv(s.key, t)} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
      <Card title="Panel location IDs" sub="The panel location each site location and node deploys to. New nodes appear here automatically; Auto-match fills empty ones from panel locations with a matching name."
        actions={<Button type="button" variant="secondary" onClick={() => void autoMatch()}>Auto-match</Button>}>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {locations.map((l) => <Field key={l.id} label={l.city}><input type="number" min={1} className={inputCls} value={d.locations[l.id] ?? ""} onChange={(e) => { const v = Number(e.target.value); const next = { ...d.locations }; if (v > 0) next[l.id] = v; else delete next[l.id]; setD({ ...d, locations: next }); }} /></Field>)}
        </div>
      </Card>
      <Card title="Server limits">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Databases"><input type="number" min={0} max={50} className={inputCls} value={d.databases} onChange={(e) => setD({ ...d, databases: Number(e.target.value) || 0 })} /></Field>
          <Field label="Backups"><input type="number" min={0} max={50} className={inputCls} value={d.backups} onChange={(e) => setD({ ...d, backups: Number(e.target.value) || 0 })} /></Field>
          <Field label="Extra ports"><input type="number" min={0} max={20} className={inputCls} value={d.extraAllocations} onChange={(e) => setD({ ...d, extraAllocations: Number(e.target.value) || 0 })} /></Field>
          <Field label="Disk IO weight"><input type="number" min={10} max={1000} className={inputCls} value={d.io} onChange={(e) => setD({ ...d, io: Number(e.target.value) || 500 })} /></Field>
        </div>
      </Card>
      <Card title="Port pools" sub="Optional. Ports each product may use, e.g. 25565-25665. Keeps Minecraft and bots out of game port ranges. Empty means any free port.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {productKeys.filter((p) => p !== "vps").map((p) => (
            <Field key={p} label={productNames[p]}>
              <PortRangesInput value={d.portRanges[p] ?? []} onCommit={(list) => { const next = { ...d.portRanges }; if (list.length) next[p] = list; else delete next[p]; setD({ ...d, portRanges: next }); }} />
            </Field>
          ))}
        </div>
      </Card>
      <SaveBar dirty={dirty} saving={saving} onSave={submit} onDiscard={discard} label="Save panel settings" />
    </div>
  );
}

function PortRangesInput({ value, onCommit }: { value: string[]; onCommit: (list: string[]) => void }) {
  const text = value.join(", ");
  const [draft, setDraft] = useState(text);
  useEffect(() => setDraft(text), [text]);
  return <input className={cn(inputCls, "font-mono")} value={draft} placeholder="25565-25665, 27015" onChange={(e) => setDraft(e.target.value)}
    onBlur={() => onCommit(draft.split(/[\s,]+/).map((x) => x.trim()).filter((x) => /^\d{1,5}(-\d{1,5})?$/.test(x)).slice(0, 10))} />;
}

function Razorpay({ setup }: { setup: Data["setup"] }) {
  const [origin, setOrigin] = useState("");
  useEffect(() => setOrigin(window.location.origin), []);
  return (
    <div className="space-y-6">
      <Card title="Connection" sub="Keys are stored as encrypted secrets and never shown here.">
        <div className="flex flex-wrap gap-3"><Pill ok={setup.razorpay}>Key ID and secret</Pill><Pill ok={setup.webhook}>Webhook secret</Pill></div>
        <div className="mt-6 grid gap-2 text-sm">
          <p className="font-semibold">Webhook address</p>
          <code className="rounded-md border border-steel bg-ink px-3 py-2 font-mono text-xs">{origin}/api/public/razorpay-webhook</code>
        </div>
      </Card>
    </div>
  );
}

function Admins({ data, onChange }: { data: Data; onChange: () => void }) {
  const set = useServerFn(setAdmin);
  const [email, setEmail] = useState("");
  async function go(e: string, admin: boolean) {
    try { await set({ data: { email: e, admin } }); toast.success(admin ? "Admin added" : "Admin removed"); setEmail(""); onChange(); } catch (err) { toast.error(errMsg(err)); }
  }
  const admins = data.profiles.filter((p) => data.adminIds.includes(p.id));
  return (
    <div className="space-y-6">
      <Card title="Administrators">
        <ul className="divide-y divide-steel text-sm">
          {admins.map((a) => <li key={a.id} className="flex items-center justify-between py-2"><span>{a.email}</span><Button type="button" variant="text" onClick={async () => { if (await askConfirm(`Remove admin access for ${a.email}?`)) go(a.email ?? "", false); }}>Remove</Button></li>)}
        </ul>
        <form className="mt-5 flex flex-wrap gap-2" onSubmit={(e) => { e.preventDefault(); void go(email, true); }}>
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="their-email@example.com" className={cn(inputCls, "max-w-sm")} />
          <Button type="submit">Add admin</Button>
        </form>
      </Card>
      <Card title="Customers">
        <div className="max-h-[480px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead><tr><th className={th}>Email</th><th className={th}>Name</th><th className={th}>Joined</th><th className={th}>Services</th></tr></thead>
            <tbody>{data.profiles.map((p) => <tr key={p.id}><td className={td}>{p.email}</td><td className={td}>{p.display_name}</td><td className={td}>{when(p.created_at)}</td><td className={td}>{data.orders.filter((o) => o.user_id === p.id && o.kind === "new" && o.paid_at).length}</td></tr>)}</tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
