import { askConfirm } from "@/components/ui-px/ConfirmHost";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui-px/Spinner";
import { couponInput, type CouponInput } from "@/config/coupon-rules";
import { formatINR, productKeys, productNames } from "@/config/plans";
import { deleteCoupon, listCoupons, saveCoupon } from "@/lib/admin.functions";
import { cn } from "@/lib/utils";
import { Card, Field, inputCls, num, td, th, Toggle } from "./fields";
import { shownError } from "@/lib/public-error";

type Row = Awaited<ReturnType<typeof listCoupons>>[number];
type Draft = { id?: string; code: string; kind: "percent" | "fixed"; value: string; maxDiscount: string; minAmount: string; products: string[]; maxUses: string; perUserLimit: string; startsAt: string; expiresAt: string; active: boolean; note: string };

const empty: Draft = { code: "", kind: "percent", value: "10", maxDiscount: "", minAmount: "", products: [], maxUses: "", perUserLimit: "1", startsAt: "", expiresAt: "", active: true, note: "" };
const when = (s: string | null) => (s ? new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "-");
/** ISO → value for <input type="datetime-local"> in the admin's local time. */
const toLocal = (iso: string | null) => { if (!iso) return ""; const d = new Date(iso); return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16); };
const fromLocal = (v: string) => (v ? new Date(v).toISOString() : null);

function toDraft(r: Row): Draft {
  return { id: r.id, code: r.code, kind: r.kind as Draft["kind"], value: String(r.value), maxDiscount: r.max_discount ? String(r.max_discount) : "", minAmount: r.min_amount ? String(r.min_amount) : "", products: r.products, maxUses: r.max_uses ? String(r.max_uses) : "", perUserLimit: String(r.per_user_limit), startsAt: toLocal(r.starts_at), expiresAt: toLocal(r.expires_at), active: r.active, note: r.note ?? "" };
}

/** Coupons for new orders. Limits are enforced again by the database at checkout. */
export function CouponsPanel() {
  const qc = useQueryClient();
  const list = useServerFn(listCoupons);
  const save = useServerFn(saveCoupon);
  const remove = useServerFn(deleteCoupon);
  const { data, isLoading } = useQuery({ queryKey: ["admin-coupons"], queryFn: () => list() });
  const [d, setD] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin-coupons"] });

  async function submit() {
    if (!d) return;
    const input: Record<string, unknown> = {
      ...(d.id ? { id: d.id } : {}), code: d.code, kind: d.kind, value: num(d.value) ?? 0, maxDiscount: d.kind === "percent" ? num(d.maxDiscount) ?? null : null,
      minAmount: num(d.minAmount) ?? 0, products: d.products, maxUses: num(d.maxUses) ?? null, perUserLimit: num(d.perUserLimit) ?? 1,
      startsAt: fromLocal(d.startsAt), expiresAt: fromLocal(d.expiresAt), active: d.active, note: d.note,
    };
    const check = couponInput.safeParse(input);
    if (!check.success) { toast.error(check.error.issues[0]?.message ?? "Please check the coupon."); return; }
    setSaving(true);
    try { await save({ data: check.data as CouponInput }); toast.success("Coupon saved."); setD(null); refresh(); } catch (e) { toast.error(shownError(e, "Could not save the coupon.")); }
    setSaving(false);
  }
  async function del(r: Row) {
    if (!(await askConfirm(`Delete coupon ${r.code}?`))) return;
    try { const res = await remove({ data: { id: r.id } }); toast.success(res.message); refresh(); } catch { toast.error("Could not delete the coupon."); }
  }
  async function toggle(r: Row) {
    const draft = toDraft(r);
    setD(null);
    try {
      await save({ data: couponInput.parse({ id: r.id, code: r.code, kind: r.kind, value: r.value, maxDiscount: r.max_discount, minAmount: r.min_amount, products: r.products, maxUses: r.max_uses, perUserLimit: r.per_user_limit, startsAt: r.starts_at ? new Date(r.starts_at).toISOString() : null, expiresAt: r.expires_at ? new Date(r.expires_at).toISOString() : null, active: !draft.active, note: draft.note }) });
      refresh();
    } catch { toast.error("Could not update the coupon."); }
  }

  return (
    <div className="space-y-6">
      <Card title="Coupons" sub="Discounts for new orders only. Renewals and upgrades never take coupons." actions={!d && <Button type="button" onClick={() => setD({ ...empty })}>New coupon</Button>}>
        {d && (
          <div className="mb-6 grid gap-4 rounded-md border border-steel p-4 md:grid-cols-3">
            <Field label="Code"><input className={cn(inputCls, "font-mono uppercase")} maxLength={32} value={d.code} onChange={(e) => setD({ ...d, code: e.target.value.toUpperCase() })} placeholder="LAUNCH20" /></Field>
            <Field label="Type">
              <select className={inputCls} value={d.kind} onChange={(e) => setD({ ...d, kind: e.target.value as Draft["kind"] })}><option value="percent">Percent off</option><option value="fixed">Fixed ₹ off</option></select>
            </Field>
            <Field label={d.kind === "percent" ? "Percent (1-100)" : "Amount ₹"}><input type="number" min={1} max={d.kind === "percent" ? 100 : undefined} className={inputCls} value={d.value} onChange={(e) => setD({ ...d, value: e.target.value })} /></Field>
            {d.kind === "percent" && <Field label="Max discount ₹ (optional)"><input type="number" min={1} className={inputCls} value={d.maxDiscount} onChange={(e) => setD({ ...d, maxDiscount: e.target.value })} /></Field>}
            <Field label="Minimum order ₹ (optional)"><input type="number" min={0} className={inputCls} value={d.minAmount} onChange={(e) => setD({ ...d, minAmount: e.target.value })} /></Field>
            <Field label="Total uses (empty = unlimited)"><input type="number" min={1} className={inputCls} value={d.maxUses} onChange={(e) => setD({ ...d, maxUses: e.target.value })} /></Field>
            <Field label="Uses per customer"><input type="number" min={1} max={100} className={inputCls} value={d.perUserLimit} onChange={(e) => setD({ ...d, perUserLimit: e.target.value })} /></Field>
            <Field label="Starts (optional)"><input type="datetime-local" className={inputCls} value={d.startsAt} onChange={(e) => setD({ ...d, startsAt: e.target.value })} /></Field>
            <Field label="Expires (optional)"><input type="datetime-local" className={inputCls} value={d.expiresAt} onChange={(e) => setD({ ...d, expiresAt: e.target.value })} /></Field>
            <div className="md:col-span-3">
              <p className="text-sm font-semibold">Products <span className="font-normal text-muted-foreground">(none selected = all)</span></p>
              <div className="mt-2 flex flex-wrap gap-4">{productKeys.map((p) => <Toggle key={p} label={productNames[p]} checked={d.products.includes(p)} onChange={(v) => setD({ ...d, products: v ? [...new Set([...d.products, p])] : d.products.filter((x) => x !== p) })} />)}</div>
            </div>
            <Field label="Note (admins only)" className="md:col-span-2"><input className={inputCls} maxLength={200} value={d.note} onChange={(e) => setD({ ...d, note: e.target.value })} /></Field>
            <div className="flex items-end"><Toggle label="Active" checked={d.active} onChange={(v) => setD({ ...d, active: v })} /></div>
            <div className="flex gap-2 md:col-span-3">
              <Button type="button" disabled={saving} onClick={submit}>{saving ? <Spinner size="xs" /> : null}{d.id ? "Save coupon" : "Create coupon"}</Button>
              <Button type="button" variant="ghost" onClick={() => setD(null)}>Cancel</Button>
            </div>
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr><th className={th}>Code</th><th className={th}>Discount</th><th className={th}>Limits</th><th className={th}>Used</th><th className={th}>Valid</th><th className={th}>Status</th><th className={th} /></tr></thead>
            <tbody>
              {isLoading && <tr><td className={td} colSpan={7}><Spinner size="xs" /></td></tr>}
              {!isLoading && (data ?? []).length === 0 && <tr><td className={td} colSpan={7}>No coupons yet.</td></tr>}
              {(data ?? []).map((r) => (
                <tr key={r.id} className={cn(!r.active && "opacity-60")}>
                  <td className={cn(td, "font-mono font-semibold")}>{r.code}{r.note && <span className="block font-sans text-xs font-normal text-muted-foreground">{r.note}</span>}</td>
                  <td className={td}>{r.kind === "percent" ? `${r.value}%${r.max_discount ? ` (max ${formatINR(r.max_discount)})` : ""}` : formatINR(r.value)}{r.min_amount > 0 && <span className="block text-xs text-muted-foreground">min order {formatINR(r.min_amount)}</span>}</td>
                  <td className={td}>{r.max_uses ? `${r.max_uses} total` : "Unlimited"} · {r.per_user_limit} per customer<span className="block text-xs text-muted-foreground">{r.products.length ? r.products.map((p) => productNames[p as keyof typeof productNames] ?? p).join(", ") : "All products"}</span></td>
                  <td className={td}>{r.paid} paid{r.uses > r.paid ? ` · ${r.uses - r.paid} unpaid` : ""}<span className="block text-xs text-muted-foreground">{formatINR(r.discount)} given</span></td>
                  <td className={cn(td, "text-xs")}>{r.starts_at ? `From ${when(r.starts_at)}` : "Now"}<br />{r.expires_at ? `Until ${when(r.expires_at)}` : "No expiry"}</td>
                  <td className={td}><Button type="button" variant="link" size="sm" onClick={() => toggle(r)}>{r.active ? "Active" : "Off"}</Button></td>
                  <td className={td}><div className="flex gap-2"><Button type="button" variant="secondary" onClick={() => setD(toDraft(r))}>Edit</Button><Button type="button" variant="ghost" onClick={() => del(r)}>Delete</Button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
