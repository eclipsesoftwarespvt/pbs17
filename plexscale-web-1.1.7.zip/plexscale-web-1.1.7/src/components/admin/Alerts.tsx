import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui-px/Spinner";
import { listPanelAlerts, resolvePanelAlert, retryProvision } from "@/lib/admin.functions";
import { cn } from "@/lib/utils";
import { inputCls, td, th } from "./fields";

const when = (s: string | null) => (s ? new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "-");
const actionLabel: Record<string, string> = { provision: "Server setup", upgrade_resize: "Upgrade resize", renewal_unsuspend: "Renewal unsuspend", suspend: "Suspend", reserve_ports: "Reserve ports", delete: "Delete server" };

/** Failed panel calls with the full scrubbed detail. Customers only ever saw the short error line. */
export function AlertsPanel({ onChange }: { onChange: () => void }) {
  const qc = useQueryClient();
  const list = useServerFn(listPanelAlerts);
  const resolve = useServerFn(resolvePanelAlert);
  const retry = useServerFn(retryProvision);
  const [status, setStatus] = useState<"open" | "resolved" | "all">("open");
  const [q, setQ] = useState("");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ["panel-alerts", status, search], queryFn: () => list({ data: { status, q: search } }) });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["panel-alerts"] }); onChange(); };

  async function doResolve(id: string) {
    setBusy(id);
    try { const r = await resolve({ data: { id } }); toast.success(r.message); refresh(); } catch { toast.error("Could not resolve the alert."); }
    setBusy(null);
  }
  async function doRetry(id: string, orderId: string) {
    setBusy(id);
    try { const r = await retry({ data: { orderId } }); (r.ok ? toast.success : toast.error)(r.message); refresh(); } catch { toast.error("Retry could not be started."); }
    setBusy(null);
  }

  return (
    <div className="space-y-4">
      <form className="flex flex-wrap gap-3" onSubmit={(e) => { e.preventDefault(); setSearch(q.trim()); }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Email, error text or order ID" className={cn(inputCls, "max-w-xs")} aria-label="Search alerts" />
        <select value={status} onChange={(e) => setStatus(e.target.value as typeof status)} className={cn(inputCls, "w-40")} aria-label="Alert status">
          <option value="open">Open</option><option value="resolved">Resolved</option><option value="all">All</option>
        </select>
        <Button type="submit" variant="secondary">Search</Button>
      </form>
      <div className="panel overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr>
            <th className={th}>Time</th><th className={th}>Action</th><th className={th}>Order</th><th className={th}>User email</th>
            <th className={th}>Panel status</th><th className={th}>Panel error code</th><th className={th}>Actual error</th><th className={th}>Count</th><th className={th} />
          </tr></thead>
          <tbody>
            {isLoading && <tr><td className={td} colSpan={9}><Spinner size="xs" /></td></tr>}
            {!isLoading && (data ?? []).length === 0 && <tr><td className={td} colSpan={9}>No alerts.</td></tr>}
            {(data ?? []).map((a) => [
              <tr key={a.id} className={cn(a.status === "resolved" && "opacity-60")}>
                <td className={td}><p>{when(a.last_seen_at)}</p>{a.count > 1 && <p className="text-xs text-muted-foreground">first {when(a.created_at)}</p>}</td>
                <td className={td}>{actionLabel[a.action] ?? a.action}</td>
                <td className={cn(td, "font-mono text-xs")}>{a.order_id ? a.order_id.slice(0, 8) : "-"}{a.product ? <span className="block font-sans text-muted-foreground">{a.product}</span> : null}</td>
                <td className={td}>{a.user_email ?? "-"}</td>
                <td className={td}>{a.http_status ?? "-"}</td>
                <td className={cn(td, "font-mono text-xs")}>{a.panel_code ?? "-"}</td>
                <td className={cn(td, "max-w-sm")}>
                  <p className="line-clamp-3 break-words">{a.panel_detail ?? "-"}</p>
                  {a.raw && <Button type="button" variant="link" size="xs" onClick={() => setOpen(open === a.id ? null : a.id)}>{open === a.id ? "Hide panel reply" : "Show panel reply"}</Button>}
                </td>
                <td className={td}>{a.count}</td>
                <td className={td}>
                  {a.status === "open" && (
                    <div className="flex flex-col gap-1.5">
                      <Button type="button" disabled={busy === a.id} onClick={() => doResolve(a.id)} variant="secondary">Resolve</Button>
                      {(a.action === "provision" || a.action === "reserve_ports") && a.order_id && <Button type="button" disabled={busy === a.id} onClick={() => doRetry(a.id, a.order_id!)} variant="ghost">Retry</Button>}
                    </div>
                  )}
                  {a.status === "resolved" && <span className="text-xs text-muted-foreground">Resolved {when(a.resolved_at)}</span>}
                </td>
              </tr>,
              open === a.id && a.raw && <tr key={`${a.id}-raw`}><td className={td} colSpan={9}><pre className="max-h-64 overflow-auto whitespace-pre-wrap break-all rounded-md border border-steel bg-ink p-3 font-mono text-xs">{a.raw}</pre></td></tr>,
            ])}
          </tbody>
        </table>
      </div>
    </div>
  );
}
