import { ChevronRight, Cpu, HardDrive, MemoryStick } from "lucide-react";
import { img } from "@/config/images";

// Illustrative readings only (not live data), drawn as a still chart.
const points = [30, 34, 28, 40, 36, 44, 38, 46, 41, 50, 44, 47];

function sparkPath(w: number, h: number) {
  const max = 60;
  const step = w / (points.length - 1);
  const xy = points.map((p, i) => [i * step, h - (p / max) * h] as const);
  const line = xy.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");
  return { line, area: `${line} L${w} ${h} L0 ${h} Z` };
}

const stats = [
  { icon: Cpu, k: "Clock", v: "Up to 3.70 GHz" },
  { icon: MemoryStick, k: "Memory", v: "DDR5 4800" },
  { icon: HardDrive, k: "Storage", v: "NVMe Gen 4" },
];

/** Hardware section artwork: a still CPU usage card with the AMD EPYC chip and a blue ribbon behind it. */
export function CpuVisual() {
  const { line, area } = sparkPath(320, 80);
  return (
    <div aria-hidden className="relative isolate mx-auto w-full max-w-[420px] pt-8">
      <img src={img.ribbon} alt="" width={322} height={700} loading="lazy" className="pointer-events-none absolute -left-5 -top-6 -z-10 h-[230px] w-auto -rotate-[24deg] opacity-90" />
      <div className="cpu-card relative rounded-2xl p-5 shadow-lift">
        <p className="flex items-center gap-1 text-xs text-muted-foreground">CPU usage <ChevronRight className="size-3.5" /></p>
        <p className="mt-1 font-display text-3xl font-bold tabular-nums text-foreground">22%</p>
        <svg viewBox="0 0 320 80" className="mt-3 h-20 w-full" preserveAspectRatio="none">
          <defs>
            <linearGradient id="cpu-fill" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--azure)" stopOpacity="0.45" />
              <stop offset="100%" stopColor="var(--azure)" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={area} className="cpu-fill" />
          <path d={line} fill="none" strokeWidth="2" strokeLinejoin="round" className="cpu-line" />
        </svg>
        <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-steel pt-4">
          {stats.map((s) => (
            <div key={s.k}>
              <dt className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><s.icon className="size-3.5 text-azure-bright" />{s.k}</dt>
              <dd className="mt-1 font-display text-[13px] font-semibold leading-tight">{s.v}</dd>
            </div>
          ))}
        </dl>
      </div>
      <div className="epyc-chip absolute -right-2 top-0 flex h-14 w-36 items-center rounded-xl px-4 sm:h-16 sm:w-40">
        <img src={img.amdEpyc} alt="" width={557} height={82} loading="lazy" className="w-full object-contain" />
      </div>
    </div>
  );
}
