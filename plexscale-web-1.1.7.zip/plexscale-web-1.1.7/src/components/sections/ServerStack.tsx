import { img } from "@/config/images";
import { cn } from "@/lib/utils";

/** Hero artwork. The status lights live on a separate layer, clipped per light so each one breathes or blinks on its own beat. */
const LIGHT_ROWS = [[240, 264], [349, 380], [459, 495]] as const;
const DOT_COLS = [[504, 521], [521, 537], [537, 552]] as const;
const pct = (v: number) => `${((v / 760) * 100).toFixed(2)}%`;
const clip = (x0: number, x1: number, y0: number, y1: number) => `inset(${pct(y0)} ${pct(760 - x1)} ${pct(760 - y1)} ${pct(x0)})`;

export function ServerStack({ className, priority }: { className?: string; priority?: boolean }) {
  return (
    <div className={cn("relative mx-auto w-full max-w-[220px] sm:max-w-[340px] lg:max-w-[440px]", className)}>
      <img src={img.heroStack} alt="Stacked PlexScale server nodes wrapped in a blue ribbon" width={760} height={760} {...(priority ? { fetchPriority: "high" as const } : { loading: "lazy" as const })} className="block w-full" />
      {LIGHT_ROWS.map(([y0, y1], row) => (
        <span key={row} aria-hidden>
          <img src={img.heroStackLights} alt="" width={760} height={760} className="led led-bar" style={{ clipPath: clip(298, 494, y0, y1), animationDelay: `${row * -1.1}s` }} />
          {DOT_COLS.map(([x0, x1], col) => (
            <img key={col} src={img.heroStackLights} alt="" width={760} height={760} className="led led-dot" style={{ clipPath: clip(x0, x1, y0, y0 + 20), animationDelay: `${-(row * 0.7 + col * 0.35)}s`, animationDuration: `${1.8 + ((row + col) % 3) * 0.5}s` }} />
          ))}
        </span>
      ))}
    </div>
  );
}
