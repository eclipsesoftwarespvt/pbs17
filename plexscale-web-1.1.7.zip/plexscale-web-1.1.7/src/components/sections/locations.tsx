import { Activity, Signal } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocations } from "@/hooks/use-settings";
import { publicLocations } from "@/config/settings";
import { SectionHead } from "@/components/sections/common";
import { flagFor } from "@/config/images";

function LocationMap({ pings }: { pings?: Record<string, number> | undefined }) {
  // Homepage list: deploy-only nodes never appear here.
  const locations = publicLocations(useLocations());
  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {locations.map((l) => (
        <li key={l.id} className="panel flex flex-col p-5">
          <div className="flex items-center gap-3">
            {flagFor(l.country) && <img src={flagFor(l.country)} alt={`${l.region} flag`} referrerPolicy="no-referrer" width={32} height={16} loading="lazy" className="h-4 w-8 shrink-0 rounded-sm object-cover ring-1 ring-steel" />}
            <h3 className="text-base font-semibold">{l.city}</h3>
            <span className="text-sm text-muted-foreground">{l.region}</span>
          </div>
          <div className="mt-4 flex items-center justify-between gap-2 border-t border-steel pt-3 text-xs">
            <span className="inline-flex items-center gap-2 font-medium text-ok"><span className="size-1.5 rounded-full bg-ok" />Online</span>
            <span className="inline-flex items-center gap-1.5 text-muted-foreground"><Signal className="size-3.5 text-azure" /><span className="tabular-nums">{pings?.[l.id] != null ? `${pings[l.id]} ms` : "EPYC · NVMe"}</span></span>
          </div>
        </li>
      ))}
      <li className="panel-accent relative flex flex-col justify-center overflow-hidden p-5">
        <p className="font-display text-lg font-semibold">One network, {locations.length} locations</p>
        <p className="mt-2 text-sm text-muted-foreground">{[...new Set(locations.map((l) => l.region))].join(" · ")}</p>
      </li>
    </ul>
  );
}

function usePingTest() {
  const locations = publicLocations(useLocations());
  const [pings, setPings] = useState<Record<string, number> | undefined>();
  const [running, setRunning] = useState(false);
  const run = () => {
    setRunning(true);
    setPings(undefined);
    // Mock values until the backend ping endpoints exist.
    setTimeout(() => {
      setPings(Object.fromEntries(locations.map((l) => [l.id, l.mockPing + Math.round(Math.random() * 6)])));
      setRunning(false);
    }, 900);
  };
  return { pings, running, run };
}

export function LocationsSection() {
  const locations = publicLocations(useLocations());
  const { pings, running, run } = usePingTest();
  return (
    <section id="locations" className="section container-px scroll-mt-20">
      <SectionHead
        title="Close to your players"
        sub={`${locations.map((l) => l.city).join(", ")}. Pick the one nearest your community and test your ping right here.`}
        action={<Button onClick={run} disabled={running} size="lg"><Activity /> {running ? "Testing..." : "Test your ping"}</Button>}
      />
      <div className="mt-8"><LocationMap pings={pings} /></div>
    </section>
  );
}
