import { HardDrive, Info, Network, ShieldCheck, Timer } from "lucide-react";
import { SectionHead } from "@/components/sections/common";
import { CpuVisual } from "@/components/sections/HeroVisual";
import { cpus, hardwareFloor, specs } from "@/config/site";
import { cn } from "@/lib/utils";

const specIcons = [HardDrive, Network, ShieldCheck, Timer];

/** The three EPYC processors in the fleet, newest first. */
export function CpuLineup({ className }: { className?: string }) {
  return (
    <div className={cn("grid gap-4 md:grid-cols-3", className)}>
      {cpus.map((c, i) => (
        <article key={c.model} className={cn("relative flex flex-col p-5", i === 0 ? "panel-accent" : "panel")}>
          <div className="flex items-center justify-between gap-3">
            <span className="text-xs text-muted-foreground">{c.series}</span>
            {i === 0 && <span className="rounded-full bg-primary px-2.5 py-0.5 text-xs font-semibold text-primary-foreground">Newest</span>}
          </div>
          <h3 className="mt-2 text-xl font-bold">{c.model}</h3>
          <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-steel pt-4">
            <div><dt className="text-xs text-muted-foreground">Clock speed</dt><dd className="mt-0.5 font-display text-[15px] font-semibold">Up to {c.clock}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Memory</dt><dd className="mt-0.5 font-display text-[15px] font-semibold">{c.memory}</dd></div>
          </dl>
        </article>
      ))}
    </div>
  );
}

export function HardwareFloor({ className }: { className?: string }) {
  return <p className={cn("flex items-start gap-3 text-sm text-muted-foreground", className)}><Info className="mt-0.5 size-4 shrink-0 text-azure" />{hardwareFloor}</p>;
}

export function Hardware() {
  return (
    <section id="hardware" className="band section scroll-mt-20">
      <div className="container-px">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
          <div className="order-2 lg:order-1 lg:col-span-5"><CpuVisual /></div>
          <div className="order-1 lg:order-2 lg:col-span-7">
            <SectionHead title="Enterprise AMD EPYC power, priced for everyone" sub="The same server-grade processors big cloud platforms run on. Our newest nodes use the AMD EPYC 9V74 with DDR5 memory, backed by the proven EPYC 7763 and 7V12, all on NVMe Gen 4 storage." />
            <dl className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-steel bg-steel md:grid-cols-4">
              {specs.map((s, i) => {
                const Icon = specIcons[i] ?? HardDrive;
                return (
                  <div key={s.label} className="bg-graphite p-4">
                    <dt className="flex items-center gap-2 text-xs text-muted-foreground"><Icon className="size-4 text-azure-bright" />{s.label}</dt>
                    <dd className="mt-1.5 font-display text-sm font-semibold leading-snug">{s.value}</dd>
                  </div>
                );
              })}
            </dl>
          </div>
        </div>
        <CpuLineup className="mt-10" />
        <HardwareFloor className="mt-4" />
      </div>
    </section>
  );
}
