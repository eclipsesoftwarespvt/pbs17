import { Link } from "@tanstack/react-router";
import { ArrowRight, ChevronsRight } from "lucide-react";
import type { ReactNode } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { btn } from "@/components/ui-px/btn";
import { DiscordIcon } from "@/components/icons/DiscordIcon";
import type { QA } from "@/config/faq";
import { img } from "@/config/images";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";

/** Section title block. Small labels above titles were removed site-wide; `eyebrow` is accepted but not shown. */
export function SectionHead({ title, sub, center, action }: { eyebrow?: string; title: string; sub?: string; center?: boolean; action?: ReactNode }) {
  const head = (
    <div className={cn(center && "mx-auto text-center", "max-w-2xl")}>
      <h2>{title}</h2>
      {sub && <p className={cn("measure mt-3 text-muted-foreground md:text-[17px]", center && "mx-auto")}>{sub}</p>}
    </div>
  );
  if (!action) return head;
  return <div className="flex flex-wrap items-end justify-between gap-6">{head}<div className="shrink-0">{action}</div></div>;
}

/** The one card used for feature, step and value grids, so every section shares the same shape. */
export function FeatureCard({ icon, title, body, index, className }: { icon: ReactNode; title: string; body: string; index?: string; className?: string }) {
  return (
    <div className={cn("panel flex h-full flex-col p-5", className)}>
      <div className="flex items-center justify-between">
        <span className="icon-well">{icon}</span>
        {index && <span className="font-display text-sm font-semibold tabular-nums text-muted-foreground">{index}</span>}
      </div>
      <h3 className="mt-4 text-base font-semibold md:text-[17px]">{title}</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}

export function FaqList({ items }: { items: QA[] }) {
  return (
    <Accordion type="single" collapsible className="panel divide-y divide-steel px-5 md:px-6">
      {items.map((it, i) => (
        <AccordionItem key={it.q} value={`i${i}`} className="border-0">
          <AccordionTrigger className="py-4 text-left font-display text-[15px] font-semibold hover:no-underline md:text-base">{it.q}</AccordionTrigger>
          {/* forceMount keeps closed answers in the HTML (hidden) so search engines and assistants can read them. */}
          <AccordionContent forceMount className="measure pb-4 text-[15px] leading-relaxed text-muted-foreground">{it.a}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

export function FaqSection({ items, title = "Questions, answered" }: { items: QA[]; title?: string }) {
  return (
    <section className="section container-px">
      <div className="grid gap-8 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-4">
          <h2>{title}</h2>
          <p className="mt-3 text-muted-foreground">Still unsure? Open a ticket or drop into Discord and we will sort it out.</p>
          <Link to="/queries" className={cn(btn({ variant: "secondary" }), "mt-6")}>See all questions</Link>
        </div>
        <div className="lg:col-span-8"><FaqList items={items} /></div>
      </div>
    </section>
  );
}

/** Black page header for product and company pages. The artwork sits on the right and fades into black. */
export function PageHero({ title, sub, image, imageAlt, badge, children }: { eyebrow?: string; title: string; sub: string; image?: string; imageAlt?: string; badge?: ReactNode; children?: ReactNode }) {
  return (
    <section className="theme-dark relative overflow-hidden border-b border-steel">
      {image && (
        <div aria-hidden={imageAlt ? undefined : true} className="absolute inset-y-0 right-0 w-full md:w-[62%]">
          <img src={image} alt={imageAlt ?? ""} width={1280} height={720} className="h-full w-full object-cover opacity-55 md:opacity-80" />
          <div className="fade-ink-side absolute inset-0" />
        </div>
      )}
      <div className="container-px relative py-16 md:py-24">
        <div className="max-w-2xl animate-rise">
          {badge}
          <h1>{title}</h1>
          <p className="measure mt-4 text-lg text-muted-foreground">{sub}</p>
          {children && <div className="mt-7 flex flex-wrap gap-3">{children}</div>}
        </div>
      </div>
    </section>
  );
}

/** Support tickets and email as black-to-blue tiles with 3D artwork, matching the Discord banner. */
export function SupportOptions({ className }: { className?: string }) {
  const s = useSettings();
  const tile = "support-tile brand-banner group relative isolate flex min-h-[200px] flex-col justify-between overflow-hidden rounded-2xl p-6 md:min-h-[220px] md:p-8";
  const body = (title: string, text: string, cta: string) => (
    <>
      <div className="max-w-md">
        <h3 className="text-2xl font-bold leading-tight tracking-[-0.02em] md:text-[28px]">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-azure-bright md:text-[15px]">{text}</p>
      </div>
      <span className="mt-6 inline-flex w-fit items-center gap-1.5 break-all font-display text-sm font-semibold text-foreground">{cta}<ArrowRight className="size-4 shrink-0 transition-transform group-hover:translate-x-0.5" /></span>
    </>
  );
  return (
    <div className={cn("grid items-stretch gap-5 md:grid-cols-2", className)}>
      <Link to="/support/new" className={tile}>
        {body("Support tickets", "Private, tracked help for servers, billing and account issues, with an email on every reply.", "Open a ticket")}
      </Link>
      <a href={`mailto:${s.supportEmail}`} className={tile}>
        {body("Email", "Best for billing questions, invoices and private account matters.", s.supportEmail)}
      </a>
    </div>
  );
}

/** Wide black-to-blue Discord banner. */
export function DiscordBanner({ className }: { className?: string }) {
  const s = useSettings();
  return (
    <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" aria-label={`Join PlexScale on Discord (${s.discordLabel})`} className={cn("support-tile brand-banner group relative isolate flex items-center gap-5 overflow-hidden rounded-2xl px-6 py-7 md:gap-8 md:px-12 md:py-9", className)}>
      <img src={img.ribbon} alt="" aria-hidden width={322} height={700} loading="lazy" className="pointer-events-none absolute -top-16 right-[18%] -z-10 hidden h-[260px] w-auto rotate-12 opacity-90 xl:block" />
      <img src={img.ribbon} alt="" aria-hidden width={322} height={700} loading="lazy" className="pointer-events-none absolute -bottom-24 right-[4%] -z-10 hidden h-[300px] w-auto -rotate-[24deg] opacity-80 lg:block" />
      <DiscordIcon className="size-10 shrink-0 text-foreground md:size-14" />
      <div className="min-w-0 flex-1">
        <p className="font-display text-xl font-bold leading-tight tracking-[-0.02em] text-foreground md:text-4xl">Stuck? Real people on Discord.</p>
        <p className="mt-1.5 text-sm text-azure-bright md:text-base">Setup, plugins, mods, questions before you buy, or just say hi.</p>
      </div>
      <ChevronsRight className="size-8 shrink-0 text-foreground transition-transform duration-200 group-hover:translate-x-1 md:size-12" strokeWidth={1.75} />
    </a>
  );
}

export function SupportCards() {
  return (
    <section className="section container-px">
      <SectionHead title="Real people, quick replies" sub={`${site.responseTime}. Open a ticket here on the site, or reach us on Discord and email.`} />
      <SupportOptions className="mt-8" />
      <DiscordBanner className="mt-5" />
    </section>
  );
}

export function ClosingBanner({ title, sub }: { title?: ReactNode; sub?: string } = {}) {
  const s = useSettings();
  return (
    <section className="section container-px">
      <div className="relative isolate overflow-hidden rounded-2xl border border-steel bg-graphite px-6 py-12 md:px-14 md:py-14">
        <img src={img.ribbon} alt="" aria-hidden width={322} height={700} loading="lazy" className="pointer-events-none absolute -right-6 -top-24 -z-10 hidden h-[380px] w-auto rotate-[18deg] opacity-90 lg:block" />
        <div className="relative max-w-2xl">
          <h2 className="text-3xl leading-tight md:text-[44px]">{title ?? <>Scalable solutions for complex problems. <span className="text-azure-bright">That’s PlexScale.</span></>}</h2>
          {sub && <p className="mt-4 max-w-xl text-muted-foreground md:text-lg">{sub}</p>}
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/deploy" className={btn({ size: "lg" })}>Get started</Link>
            <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg", variant: "glass" })}>Talk to us</a>
          </div>
        </div>
      </div>
    </section>
  );
}

export function FeatureLines({ items }: { items: { icon: ReactNode; title: string; body: string }[] }) {
  return (
    <section className="section container-px">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((f) => <FeatureCard key={f.title} icon={f.icon} title={f.title} body={f.body} />)}
      </div>
    </section>
  );
}
