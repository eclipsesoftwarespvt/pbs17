import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { useEffect, useState } from "react";
import { btn } from "@/components/ui-px/btn";
import { billingPeriods, cpuLabel, formatINR, periodSuffix, periodTotal, planLines, type Billing, type Plan } from "@/config/plans";
import { cn } from "@/lib/utils";
import { usePlans, useSettings } from "@/hooks/use-settings";
import { isComingSoon } from "@/config/settings";
import { productNames, type ProductKey } from "@/config/plans";
import { ComingSoonNotice, SoonTag } from "@/components/ui-px/ComingSoon";

export function BillingToggle({ value, onChange }: { value: Billing; onChange: (b: Billing) => void }) {
  return (
    <div role="radiogroup" aria-label="Billing period" className="inline-flex max-w-full flex-wrap rounded-lg border border-steel bg-surface p-1">
      {billingPeriods.map((p) => (
        <button
          key={p.key}
          type="button"
          role="radio"
          aria-checked={value === p.key}
          onClick={() => onChange(p.key)}
          className={cn(
            "rounded-md px-3 py-1.5 text-sm font-medium whitespace-nowrap transition-colors duration-150",
            value === p.key ? "bg-graphite text-foreground font-semibold shadow-card ring-1 ring-steel" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {p.label}
          {p.discount > 0 && <span className="ml-1.5 rounded bg-azure-deep px-1.5 py-px text-xs font-semibold text-azure">{Math.round(p.discount * 100)}% off</span>}
        </button>
      ))}
    </div>
  );
}

function Price({ value, className }: { value: number; className?: string }) {
  const [k, setK] = useState(0);
  useEffect(() => setK((x) => x + 1), [value]);
  return <span key={k} className={cn("inline-block animate-tick tabular-nums", className)}>{formatINR(value)}</span>;
}

/** One plan feature line. "Label: value" shows the label muted. */
export function PlanLine({ line }: { line: string }) {
  const i = line.indexOf(":");
  const hasLabel = i > 0 && i < 24;
  return (
    <li className="flex gap-2">
      <Check className="mt-0.5 size-4 shrink-0 text-azure" />
      <span>{hasLabel ? <><span className="text-muted-foreground">{line.slice(0, i + 1)}</span>{line.slice(i + 1)}</> : line}</span>
    </li>
  );
}

function PlanCard({ plan, billing, kind, features, outOfStock, soon }: { plan: Plan; billing: Billing; kind: string; features: string[]; outOfStock?: boolean; soon?: boolean }) {
  const total = periodTotal(plan.monthly, billing);
  return (
    <article className={cn("panel relative flex flex-col p-6 transition-colors duration-150 hover:border-foreground/25", plan.popular && !soon && "border-azure ring-1 ring-azure hover:border-azure")}>
      {plan.popular && !outOfStock && !soon && <span className="absolute -top-3 left-6 rounded-full bg-primary px-2.5 py-0.5 text-xs font-semibold text-primary-foreground">Most popular</span>}
      {soon && <SoonTag className="absolute -top-3 left-6 bg-graphite" />}
      {outOfStock && !soon && <span className="absolute -top-3 left-6 rounded-full border border-destructive/50 bg-graphite px-2.5 py-0.5 text-xs font-semibold text-destructive">Out of stock</span>}
      <p className="text-sm text-muted-foreground">{plan.name.includes("GB") ? "Memory" : plan.name}</p>
      <h3 className="mt-1 text-3xl font-bold">{plan.ramLabel} <span className="text-base font-medium text-muted-foreground">RAM</span></h3>
      <p className="mt-1 text-sm text-muted-foreground">{plan.vcpu ? `${plan.vcpu} vCPU` : cpuLabel(plan)} · {plan.storage} NVMe</p>
      <p className="mt-6 font-display text-3xl font-bold text-foreground">
        <Price value={total} />
        <span className="ml-1 text-sm font-medium text-muted-foreground">{periodSuffix[billing]}</span>
      </p>
      <p className="text-xs text-muted-foreground">GST included</p>
      <ul className="mt-6 space-y-2 border-t border-steel pt-6 text-sm">
        {planLines(plan, features).map((line, i) => <PlanLine key={`${i}-${line}`} line={line} />)}
      </ul>
      {soon || outOfStock ? (
        <button type="button" disabled className={cn(btn({ variant: "secondary" }), "mt-8 w-full")}>{soon ? "Coming soon" : "Out of stock"}</button>
      ) : (
        <Link to="/deploy" search={{ product: kind, plan: plan.id, billing }} className={cn(btn({ variant: plan.popular ? "primary" : "secondary" }), "mt-8 w-full")}>
          Select
        </Link>
      )}
    </article>
  );
}

export function PlanGrid({ kind, features, refundNote, title = "Pick your plan" }: { plans?: Plan[]; kind: string; features: string[]; refundNote?: boolean; title?: string }) {
  const [billing, setBilling] = useState<Billing>("monthly");
  const plans = usePlans(kind);
  const { ordering } = useSettings();
  const soon = isComingSoon({ ordering }, kind);
  const outOfStock = ordering.disabledProducts.includes(kind);
  const paused = !soon && (!ordering.enabled || outOfStock);
  return (
    <section id="plans" className="section container-px">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <h2>{title}</h2>
          <p className="mt-2 text-muted-foreground">All prices in INR, GST included. No auto renew.</p>
        </div>
        <BillingToggle value={billing} onChange={setBilling} />
      </div>
      {soon && <ComingSoonNotice name={productNames[kind as ProductKey] ?? "This product"} />}
      {paused && <p role="status" className={cn("panel mt-8 p-4 text-sm", outOfStock ? "border-destructive/50" : "border-azure/50")}>{outOfStock ? "This product is out of stock right now. Existing services are not affected. Please check back soon." : ordering.pausedMessage || "New orders are paused right now."}</p>}
      <div className={cn("mt-8 grid gap-5 sm:grid-cols-2", plans.length > 4 ? "lg:grid-cols-4" : plans.length === 4 ? "lg:grid-cols-4" : "lg:grid-cols-3")}>
        {plans.map((p) => <PlanCard key={p.id} plan={p} billing={billing} kind={kind} features={features} outOfStock={outOfStock} soon={soon} />)}
      </div>
      {refundNote && <p className="mt-6 text-sm text-muted-foreground">Eligible game hosting can be refunded within 24 hours of payment. Renewals are not refundable.</p>}
    </section>
  );
}
