import { Link } from "@tanstack/react-router";
import { Cpu, HardDrive, ShieldCheck, Undo2 } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { DeployCta, SoonBadge } from "@/components/ui-px/ComingSoon";
import { FaqSection, FeatureLines, PageHero, SectionHead, ClosingBanner } from "@/components/sections/common";
import { PlanGrid } from "@/components/sections/pricing";
import type { QA } from "@/config/faq";
import { softwareDetails, softwareLogos } from "@/config/software";
import { gameMenuImages } from "@/config/images";
import { useSettings } from "@/hooks/use-settings";
import { locationsForProduct, publicLocations } from "@/config/settings";
import { gamePlans, type GameKey } from "@/config/plans";

export function GamePage({ game, name, image, sub, software, faq }: { game: GameKey; name: string; image: string; sub: string; software: string[]; faq: QA[] }) {
  const locations = publicLocations(locationsForProduct(useSettings(), game));
  return (
    <>
      <PageHero eyebrow={`${name} hosting`} title={`${name} servers that keep up`} sub={sub} image={image} imageAlt={`${name} game artwork`} badge={<SoonBadge product={game} />}>
        <DeployCta product={game} />
        <Link to="/" hash="locations" className={btn({ size: "lg", variant: "glass" })}>See locations</Link>
      </PageHero>
      <PlanGrid plans={gamePlans(game)} kind={game} refundNote features={["AMD EPYC 9V74 / 7763, up to 3.70 GHz", "DDoS protection, up to 480 Gbps", `${locations.length} locations to choose from`]} />
      <SoftwareMarquee name={name} game={game} software={software} />
      <FeatureLines items={[
        { icon: <Cpu />, title: "EPYC power", body: "AMD EPYC 9V74, 7763 and 7V12 at up to 3.70 GHz for steady tick rates." },
        { icon: <HardDrive />, title: "NVMe Gen 4", body: "Worlds and maps load fast, saves never stall." },
        { icon: <ShieldCheck />, title: "DDoS protection", body: "L3/L4/L7 mitigation, up to 480 Gbps, always on." },
        { icon: <Undo2 />, title: "24 hour refund", body: "Eligible new game orders can be refunded within 24 hours of payment. Renewals are not refundable." },
      ]} />
      <FaqSection items={faq} />
      <ClosingBanner />
    </>
  );
}

/** Endless, smooth sliding strip of supported software with short descriptions. Pauses on hover. */
function SoftwareMarquee({ name, game, software }: { name: string; game: GameKey; software: string[] }) {
  const copies = Math.max(1, Math.ceil(8 / Math.max(1, software.length)));
  const once = Array.from({ length: copies }, () => software).flat();
  const loop = [...once, ...once];
  return (
    <section className="band section overflow-hidden">
      <div className="container-px">
        <SectionHead eyebrow="Software" title={`Run ${name} your way`} sub="One-click installs from the panel. Switch any time, your files stay put." />
      </div>
      <ul className="sr-only">{software.map((s) => <li key={s}>{s}: {softwareDetails[s]?.blurb}</li>)}</ul>
      <div className="marquee-wrap marquee-mask mt-10" aria-hidden>
        <div className="marquee-track gap-5 py-3" style={{ "--marquee-duration": `${Math.max(28, once.length * 6)}s` } as React.CSSProperties}>
          {loop.map((s, i) => {
            const d = softwareDetails[s];
            const logo = softwareLogos[s] ?? gameMenuImages[game];
            return (
              <div key={`${s}-${i}`} className="software-card flex w-[300px] shrink-0 flex-col rounded-xl p-5">
                <div className="flex items-center gap-3">
                  <span className="grid size-12 shrink-0 place-items-center rounded-lg border border-steel bg-surface p-2"><img src={logo} alt="" width={32} height={32} loading="lazy" className="size-8 object-contain" /></span>
                  <div className="min-w-0">
                    <p className="truncate font-display text-base font-semibold">{s}</p>
                    {d && <span className="mt-0.5 inline-block rounded-full bg-azure-deep px-2 py-px text-[11px] font-semibold uppercase tracking-wide text-azure">{d.tag}</span>}
                  </div>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{d?.blurb ?? "Supported out of the box on every plan."}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
