import { cn } from "@/lib/utils";

/** PlexScale mark as vector shapes, so it stays sharp at any size and keeps tight spacing to the name. */
export function BrandMark({ className }: { className?: string }) {
  return (
    <svg viewBox="377 356.5 1231 1231" aria-hidden="true" focusable="false" className={cn("shrink-0 fill-brand", className)}>
      <rect x="377" y="671" width="272" height="601" rx="136" />
      <rect x="1336" y="671" width="272" height="601" rx="136" />
      <g transform="translate(0 1944) scale(.1 -.1)">
        <path d="M11075 15749 c-66 -4 -172 -18 -235 -32 -64 -14 -165 -31 -225 -37 -61 -7 -146 -23 -190 -36 -44 -13 -116 -33 -160 -45 -1453 -373 -2761 -1600 -3130 -2934 -65 -232 -87 -328 -100 -422 -8 -59 -23 -153 -35 -208 -37 -180 -40 -300 -40 -2200 0 -2054 -4 -1902 65 -2099 225 -633 853 -977 1571 -861 526 85 929 427 1089 922 75 231 68 54 75 2013 6 1765 6 1765 29 1845 12 44 34 127 47 185 89 387 499 869 894 1052 239 111 398 147 890 204 429 49 671 157 905 405 330 350 434 726 344 1244 -34 191 -202 473 -383 642 -334 311 -707 407 -1411 362z" />
        <path d="M11420 12623 c-528 -85 -891 -333 -1097 -748 -134 -268 -125 -98 -144 -2700 -10 -1371 -9 -1368 -70 -1542 -195 -560 -640 -1011 -1134 -1149 -44 -12 -120 -34 -170 -49 -95 -28 -259 -44 -452 -45 -186 0 -524 -68 -678 -136 -848 -373 -1070 -1519 -420 -2169 197 -198 538 -369 785 -396 259 -27 944 -5 1125 36 61 14 152 32 203 40 514 83 1371 471 1787 809 757 615 1179 1203 1468 2041 42 121 83 252 92 290 9 39 27 104 40 146 13 43 31 130 40 195 8 66 26 169 40 230 43 193 45 264 45 2189 0 2140 6 2020 -112 2261 -215 442 -861 776 -1348 697z" />
      </g>
    </svg>
  );
}

/** PlexScale mark and name. The blue mark reads on both white and black surfaces. */
export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <BrandMark className="size-[26px]" />
      <span className="font-display text-[20px] font-semibold leading-none tracking-[-0.01em] text-foreground">PlexScale</span>
    </span>
  );
}
