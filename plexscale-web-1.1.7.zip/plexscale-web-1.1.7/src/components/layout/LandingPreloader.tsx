import { useEffect, useState } from "react";
import { Spinner } from "@/components/ui-px/Spinner";
import { cn } from "@/lib/utils";

/** Hard cap: the page is always revealed within this time, even on slow connections. */
const PRELOADER_MAX_MS = 4000;
// Set after the first full load in this tab, so returning to the home page does not show it again.
let loadedOnce = false;

/** True for images whose top edge sits within the first 1.5 screens — what the visitor sees first. */
function isNearFold(top: number, viewportHeight: number): boolean {
  return top < viewportHeight * 1.5;
}

function waitForImage(el: HTMLImageElement): Promise<void> {
  if (el.loading === "lazy") el.loading = "eager";
  if (el.complete) return Promise.resolve();
  return new Promise((resolve) => {
    el.addEventListener("load", () => resolve(), { once: true });
    el.addEventListener("error", () => resolve(), { once: true });
  });
}

/**
 * Full-screen preloader that stays until the images in the first screens have loaded.
 * Images further down keep loading lazily so they don't slow the reveal. Max 4 seconds.
 */
export function LandingPreloader() {
  const [phase, setPhase] = useState<"loading" | "fading" | "done">(() => (loadedOnce ? "done" : "loading"));

  useEffect(() => {
    if (phase !== "loading") return;
    let cancelled = false;
    const root = document.documentElement;
    root.style.overflow = "hidden";
    const finish = () => {
      if (cancelled || loadedOnce) return;
      loadedOnce = true;
      root.style.overflow = "";
      setPhase("fading");
      window.setTimeout(() => !cancelled && setPhase("done"), 350);
    };
    // Counted from page start (not hydration), so slow script loading can't stretch it.
    const cap = window.setTimeout(finish, Math.max(0, PRELOADER_MAX_MS - performance.now()));
    // Two frames lets late-mounted sections add their images before we collect them.
    const frame = requestAnimationFrame(() => requestAnimationFrame(() => {
      const vh = window.innerHeight;
      const images = Array.from(document.querySelectorAll<HTMLImageElement>("img"))
        .filter((el) => isNearFold(el.getBoundingClientRect().top + window.scrollY, vh));
      const fonts = document.fonts?.ready.then(() => undefined) ?? Promise.resolve();
      void Promise.all([...images.map(waitForImage), fonts]).then(finish);
    }));
    return () => { cancelled = true; cancelAnimationFrame(frame); window.clearTimeout(cap); root.style.overflow = ""; };
    // Runs once per mount; phase only moves forward.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (phase === "done") return null;
  return (
    <>
      <noscript><style>{".px-landing-loader{display:none!important}"}</style></noscript>
      {/* CSS safety net: hides the overlay at the cap even before scripts have run. */}
      <style>{"@keyframes px-loader-out{to{opacity:0;visibility:hidden;pointer-events:none}}.px-landing-loader{animation:px-loader-out .35s ease-out 4.2s forwards}"}</style>
      <div className={cn("px-landing-loader fixed inset-0 z-[200] grid place-items-center bg-background transition-opacity duration-[350ms] ease-out", phase === "fading" && "pointer-events-none opacity-0")} role="status" aria-live="polite">
        <div className="flex flex-col items-center gap-5">
          <Spinner size="lg" className="text-azure" />
          <span className="sr-only">Loading PlexScale</span>
        </div>
      </div>
    </>
  );
}
