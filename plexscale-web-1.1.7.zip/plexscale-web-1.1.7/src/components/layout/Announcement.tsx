import { AlertTriangle, ArrowRight, CheckCircle2, Info, OctagonAlert, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";

const tones = {
  info: { icon: Info, tag: "Update" },
  success: { icon: CheckCircle2, tag: "Good news" },
  warning: { icon: AlertTriangle, tag: "Heads up" },
  danger: { icon: OctagonAlert, tag: "Important" },
} as const;

/** Site-wide alert set in Administrator → Site. Dismissal is remembered per message. */
export function Announcement() {
  const { announcement: a } = useSettings();
  const id = `px-dismiss:${a.message}`;
  const [hidden, setHidden] = useState(false);
  useEffect(() => { setHidden(localStorage.getItem(id) === "1"); }, [id]);
  if (!a.enabled || !a.message || hidden) return null;
  const t = tones[a.tone] ?? tones.info;
  return (
    <div role={a.tone === "danger" ? "alert" : "status"} className={cn("announce animate-fade", `announce-${a.tone}`)}>
      <div className="container-px flex items-center gap-3 py-2.5 text-sm sm:justify-center">
        <span className="announce-icon" aria-hidden><t.icon /></span>
        <p className="min-w-0 flex-1 leading-snug sm:flex-none">
          <span className="announce-tag mr-2 hidden sm:inline">{t.tag}</span>
          <span className="text-foreground/90">{a.message}</span>
        </p>
        {a.linkUrl && a.linkLabel && (
          <a href={a.linkUrl} target="_blank" rel="noopener noreferrer" className="announce-link">{a.linkLabel}<ArrowRight aria-hidden /></a>
        )}
        <button type="button" aria-label="Dismiss alert" onClick={() => { localStorage.setItem(id, "1"); setHidden(true); }} className="ml-auto grid size-7 shrink-0 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-foreground/10 hover:text-foreground sm:ml-2"><X className="size-4" /></button>
      </div>
    </div>
  );
}
