import { Link, useRouterState } from "@tanstack/react-router";
import { House, LogIn, LogOut, ShieldCheck, CreditCard, Wallet, ChevronDown, Gamepad2, Menu, Server, LifeBuoy, UserRound, FileText, Lock, Undo2, Ban, Activity } from "lucide-react";
import { useEffect, useState } from "react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { btn } from "@/components/ui-px/btn";
import { games } from "@/config/products";
import { showsProducts } from "@/config/nav";
import { gameMenuImages } from "@/config/images";
import { Logo } from "@/components/brand/Logo";
import { useSettings } from "@/hooks/use-settings";
import { useCredits } from "@/hooks/use-credits";
import { formatINR } from "@/config/plans";
import { useIsAdmin, useSignOut, useUser } from "@/hooks/use-session";
import { cn } from "@/lib/utils";
import { DiscordIcon } from "@/components/icons/DiscordIcon";
import { LegalIcon } from "@/components/icons/LegalIcon";
import { SoonTag } from "@/components/ui-px/ComingSoon";
import { isComingSoon } from "@/config/settings";

const accountLinks = [
  { to: "/billing", label: "Billing", icon: CreditCard },
  { to: "/support", label: "Support", icon: LifeBuoy },
  { to: "/account", label: "Account", icon: UserRound },
] as const;

/** Every legal document, shown in the Legal menu. */
const legalLinks = [
  { doc: "tos", label: "Terms of Service", icon: FileText },
  { doc: "privacy", label: "Privacy Policy", icon: Lock },
  { doc: "refund", label: "Refund Policy", icon: Undo2 },
  { doc: "acceptable-use", label: "Acceptable Use", icon: Ban },
  { doc: "sla", label: "Service Level Agreement", icon: Activity },
] as const;

const productLinks = [
  { to: "/vps", key: "vps", label: "VPS", icon: Server },
  { to: "/bot-hosting", key: "bot", label: "Bot Hosting", icon: DiscordIcon },
] as const;

function Marker() {
  return <span aria-hidden className="absolute -bottom-px left-3 right-3 h-0.5 rounded-full bg-azure" />;
}

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => setOpen(false), [path]);
  const s = useSettings();
  const { user } = useUser();
  const credits = useCredits(Boolean(user));
  const isAdmin = useIsAdmin(user?.id);
  const signOut = useSignOut();
  const products = showsProducts(path);
  const panelLinks = [
    { href: s.gamePanelUrl, label: "Game Panel", icon: Gamepad2 },
    { href: s.vpsPanelUrl, label: "VPS Panel", icon: Server },
  ];
  const item = "cursor-pointer px-3 py-3 focus:bg-accent";

  return (
    <header className={cn("sticky top-0 z-50 h-16 border-b bg-ink transition-[border-color,box-shadow] duration-200", scrolled ? "border-steel shadow-card" : "border-transparent")}>
      <nav aria-label="Main" className={cn("container-px relative flex h-full items-center justify-between gap-4", products && "lg:grid lg:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] lg:gap-3")}>
        <Link to="/" aria-label="PlexScale home" className="flex shrink-0 items-center justify-self-start">
          <Logo />
        </Link>

        {products && (
          <ul className="hidden h-full items-center justify-center gap-1 lg:flex">
            <li className="relative flex h-full items-center">
              <Link to="/" className="flex h-10 items-center gap-1.5 rounded-md px-3 text-sm font-medium leading-none text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">
                <House className="size-4" /> Home
              </Link>
              {path === "/" && <Marker />}
            </li>
            <li className="relative flex h-full items-center">
              <DropdownMenu modal={false}>
                <DropdownMenuTrigger className="group flex h-10 items-center gap-1.5 rounded-md px-3 text-sm font-medium leading-none text-muted-foreground transition-colors hover:bg-accent hover:text-foreground data-[state=open]:text-foreground">
                  <Gamepad2 className="size-4" /> Games <ChevronDown className="size-4 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" sideOffset={8} className="w-64 border-steel bg-popover p-2 shadow-lift duration-200">
                  {games.map((g) => (
                    <DropdownMenuItem key={g.key} asChild className="cursor-pointer rounded-md px-3 py-3 focus:bg-accent">
                      <Link to={g.to} className="flex items-center gap-3"><img src={gameMenuImages[g.key]} alt="" width={32} height={32} loading="lazy" className="size-8 shrink-0 rounded-sm object-contain" /><span className="flex-1">{g.name}</span>{isComingSoon(s, g.key) && <SoonTag compact />}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </li>
            {productLinks.map((l) => (
              <li key={l.to} className="relative flex h-full items-center">
                <Link to={l.to} className="flex h-10 items-center gap-1.5 rounded-md px-3 text-sm font-medium leading-none text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">
                  <l.icon className="size-4" /> {l.label}{isComingSoon(s, l.key) && <SoonTag compact />}
                </Link>
                {path.startsWith(l.to) && <Marker />}
              </li>
            ))}
            <li className="relative flex h-full items-center">
              <DropdownMenu modal={false}>
                <DropdownMenuTrigger className="group flex h-10 items-center gap-1.5 rounded-md px-3 text-sm font-medium leading-none text-muted-foreground transition-colors hover:bg-accent hover:text-foreground data-[state=open]:text-foreground">
                  <LegalIcon className="size-4" /> Legal <ChevronDown className="size-4 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" sideOffset={8} className="w-64 border-steel bg-popover p-2 shadow-lift duration-200">
                  {legalLinks.map((l) => (
                    <DropdownMenuItem key={l.doc} asChild className="cursor-pointer rounded-md px-3 py-2.5 focus:bg-accent">
                      <Link to="/legal/$doc" params={{ doc: l.doc }} className="flex items-center gap-3"><l.icon className="size-4 text-azure" />{l.label}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              {path.startsWith("/legal") && <Marker />}
            </li>
          </ul>
        )}

        <div className="hidden items-center justify-self-end gap-1 lg:flex xl:gap-2">
          {user ? (
            <DropdownMenu modal={false}>
              <DropdownMenuTrigger className={cn(btn(), "group outline-none active:scale-100 data-[state=open]:bg-primary-hover active:bg-primary")}><UserRound /> Manage <ChevronDown className="transition-transform duration-200 group-data-[state=open]:rotate-180" /></DropdownMenuTrigger>
              <DropdownMenuContent align="end" sideOffset={8} className="w-56 border-steel bg-popover p-2 shadow-lift duration-200">
                {credits.data && (
                  <>
                    <DropdownMenuItem asChild className={item}><Link to="/billing" hash="credits" className="flex items-center gap-3"><Wallet className="size-4 text-azure" /><span className="flex-1">Credits</span><span className="font-semibold tabular-nums text-foreground">{formatINR(credits.data.balance)}</span></Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-steel" />
                  </>
                )}
                {accountLinks.map(({ to, label, icon: Icon }) => (
                  <DropdownMenuItem key={to} asChild className={item}><Link to={to} className="flex items-center gap-3"><Icon className="size-4 text-azure" />{label}</Link></DropdownMenuItem>
                ))}
                <DropdownMenuSeparator className="bg-steel" />
                {panelLinks.map(({ href, label, icon: Icon }) => (
                  <DropdownMenuItem key={label} asChild className={item}><a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3"><Icon className="size-4 text-azure" />{label}</a></DropdownMenuItem>
                ))}
                {isAdmin && <DropdownMenuItem asChild className={item}><Link to="/administrator" className="flex items-center gap-3"><ShieldCheck className="size-4 text-azure" />Administrator</Link></DropdownMenuItem>}
                <DropdownMenuSeparator className="bg-steel" />
                <DropdownMenuItem onSelect={() => void signOut()} className={cn(item, "gap-3")}><LogOut className="size-4 text-azure" />Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link to="/auth" className={btn()}><LogIn /> Sign in</Link>
          )}
        </div>

        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger aria-label="Open menu" className={cn(btn({ variant: "ghost" }), "w-10 px-0 lg:hidden")}>
            <Menu className="!size-5" />
          </SheetTrigger>
          <SheetContent side="right" className="flex h-dvh w-[300px] flex-col overflow-y-auto overscroll-contain border-steel bg-popover px-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-[max(1.5rem,env(safe-area-inset-top))] pr-[max(1.5rem,env(safe-area-inset-right))]">
            <SheetTitle className="sr-only">Menu</SheetTitle>
            <div className="mt-8 flex flex-col gap-1">
              {products && (
                <>
                  <Link to="/" className="mb-3 flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><House className="size-4 text-azure" />Home</Link>
                  <p className="eyebrow mb-2">Games</p>
                  {games.map((g) => <Link key={g.key} to={g.to} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><img src={gameMenuImages[g.key]} alt="" width={28} height={28} loading="lazy" className="size-7 shrink-0 rounded-sm object-contain" /><span className="flex-1">{g.name}</span>{isComingSoon(s, g.key) && <SoonTag compact />}</Link>)}
                  {productLinks.map((l) => <Link key={l.to} to={l.to} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><l.icon className="size-4 text-azure" /><span className="flex-1">{l.label}</span>{isComingSoon(s, l.key) && <SoonTag compact />}</Link>)}
                  <p className="eyebrow mb-2 mt-4 flex items-center gap-2"><LegalIcon className="size-3.5" />Legal</p>
                  {legalLinks.map((l) => <Link key={l.doc} to="/legal/$doc" params={{ doc: l.doc }} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><l.icon className="size-4 text-azure" />{l.label}</Link>)}
                </>
              )}
              {user ? (
                <>
                  <p className="eyebrow mb-2 mt-4">Manage</p>
                  {accountLinks.map(({ to, label, icon: Icon }) => <Link key={to} to={to} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><Icon className="size-4 text-azure" />{label}</Link>)}
                  {panelLinks.map(({ href, label, icon: Icon }) => <a key={label} href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><Icon className="size-4 text-azure" />{label}</a>)}
                  {isAdmin && <Link to="/administrator" className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><ShieldCheck className="size-4 text-azure" />Administrator</Link>}
                  <button type="button" onClick={() => void signOut()} className="flex items-center gap-3 rounded-md px-2 py-2 text-left text-foreground hover:bg-accent"><LogOut className="size-4 text-azure" />Sign out</button>
                </>
              ) : (
                <Link to="/auth" className={cn(btn(), "mt-4")}><LogIn />Sign in</Link>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}
