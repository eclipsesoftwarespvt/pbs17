import { Link } from "@tanstack/react-router";
import { Activity, Check, ExternalLink } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { DiscordIcon } from "@/components/icons/DiscordIcon";
import { btn } from "@/components/ui-px/btn";
import { Spinner } from "@/components/ui-px/Spinner";
import { img } from "@/config/images";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";

/** Shown on every page to everyone except administrators while maintenance mode is on. Same layout as the homepage hero. */
export function MaintenanceScreen({ checking }: { checking?: boolean }) {
  const s = useSettings();
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="border-b border-steel">
        <div className="container-px flex h-16 items-center justify-between">
          <Logo />
          <a href={site.statusUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-full border border-steel px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground">
            <Activity className="size-3.5 text-ok" />System status<ExternalLink className="size-3" />
          </a>
        </div>
      </header>

      <main className="flex flex-1 items-center">
        <div className="container-px grid items-center gap-10 py-14 lg:grid-cols-12 lg:gap-6 lg:py-20">
          <div className="animate-rise lg:col-span-7">
            <span className="status-chip" role="status">
              {checking ? <Spinner size="xs" className="text-azure" /> : <span className="status-dot status-dot-warn" aria-hidden />}
              <strong>{checking ? "Checking access" : "Scheduled maintenance"}</strong>
              <span className="hidden sm:inline">in progress</span>
            </span>
            <h1 className="mt-6 text-[38px] leading-[1.06] md:text-[52px]">{s.maintenance.title || "We’ll be right back"}</h1>
            <p className="measure mt-5 text-lg text-muted-foreground md:leading-relaxed">{s.maintenance.message || "PlexScale is undergoing scheduled maintenance."}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href={site.statusUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg" })}><Activity />View live status</a>
              <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg", variant: "glass" })}><DiscordIcon className="size-4" />Updates on Discord</a>
            </div>
            <ul className="mt-8 grid gap-2 text-sm text-muted-foreground">
              {["Your account and services are safe", "Live progress on our status page", "Support stays open on Discord"].map((t) => (
                <li key={t} className="flex items-center gap-2"><Check className="size-4 text-azure-bright" />{t}</li>
              ))}
            </ul>
          </div>
          <div className="animate-rise [animation-delay:80ms] lg:col-span-5">
            <div className="relative mx-auto w-full max-w-[220px] sm:max-w-[340px] lg:max-w-[440px]">
              <img src={img.heroStackLit} alt="PlexScale server nodes with every status light on" width={760} height={760} fetchPriority="high" className="block w-full" />
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-steel">
        <div className="container-px flex flex-col gap-2 py-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>{site.copyright}</p>
          <p>Staff member? <Link to="/auth" className="font-semibold text-azure-bright hover:underline">Sign in</Link></p>
        </div>
      </footer>
    </div>
  );
}
