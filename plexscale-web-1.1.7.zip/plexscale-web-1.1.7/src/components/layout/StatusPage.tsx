import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import type { ReactNode } from "react";
import { img } from "@/config/images";
import { cn } from "@/lib/utils";

const quickLinks = [
  { label: "Minecraft hosting", to: "/minecraft" },
  { label: "VPS", to: "/vps" },
  { label: "Bot hosting", to: "/bot-hosting" },
  { label: "Support", to: "/contact" },
] as const;

/** Full-width message page for 404s and errors, laid out like the homepage hero. */
export function StatusPage({ code, chip, tone = "info", title, body, actions, showLinks = true, fullscreen }: { fullscreen?: boolean; code: string; chip: string; tone?: "info" | "bad" | "warn"; title: string; body: ReactNode; actions: ReactNode; showLinks?: boolean }) {
  return (
    <section className={cn(fullscreen ? "flex min-h-screen items-center" : "border-b border-steel")}>
      <div className="container-px grid min-h-[70vh] w-full items-center gap-10 py-14 lg:grid-cols-12 lg:gap-12 lg:py-20">
        <div className="animate-rise lg:col-span-7">
          <span className="status-chip"><span className={cn("status-dot", tone === "bad" && "status-dot-bad", tone === "warn" && "status-dot-warn")} aria-hidden /><strong>{chip}</strong></span>
          <h1 className="mt-6 text-[36px] leading-[1.06] md:text-[52px]">{title}</h1>
          <p className="measure mt-5 text-lg text-muted-foreground">{body}</p>
          <div className="mt-8 flex flex-wrap gap-3">{actions}</div>
          {showLinks && (
            <div className="mt-10 border-t border-steel pt-6">
              <p className="text-sm text-muted-foreground">Popular pages</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {quickLinks.map((l) => (
                  <li key={l.to}><Link to={l.to} className="group inline-flex items-center gap-1.5 rounded-full border border-steel bg-graphite px-3.5 py-1.5 text-sm text-foreground transition-colors hover:border-azure/60">{l.label}<ArrowRight className="size-3.5 text-azure-bright transition-transform group-hover:translate-x-0.5" /></Link></li>
                ))}
              </ul>
            </div>
          )}
        </div>
        <div aria-hidden className="animate-rise [animation-delay:80ms] lg:col-span-5">
          <div className="code-tile brand-banner flex aspect-[5/4] items-end p-8 md:p-10">
            <img src={img.ribbon} alt="" width={322} height={700} className="pointer-events-none absolute -right-4 -top-20 -z-10 h-[125%] w-auto rotate-[18deg] opacity-90" />
            <span className="code-tile-num">{code}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
