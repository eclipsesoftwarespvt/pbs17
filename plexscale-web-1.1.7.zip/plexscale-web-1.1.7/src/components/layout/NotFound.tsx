import { Link } from "@tanstack/react-router";
import { btn } from "@/components/ui-px/btn";
import { StatusPage } from "@/components/layout/StatusPage";

export function NotFound() {
  return (
    <StatusPage
      code="404"
      chip="Page not found"
      title="This page doesn’t exist"
      body="The link may be old or mistyped. Your account and services are unchanged."
      actions={<>
        <Link to="/" className={btn({ size: "lg" })}>Return home</Link>
        <Link to="/contact" className={btn({ size: "lg", variant: "glass" })}>Contact support</Link>
      </>}
    />
  );
}
