import { Link } from "@tanstack/react-router";
import { Activity, ExternalLink } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { site } from "@/config/site";
import { games } from "@/config/products";
import { isComingSoon } from "@/config/settings";
import { useSettings } from "@/hooks/use-settings";
import { TrustpilotMark } from "@/components/layout/Trustpilot";
import { SoonTag } from "@/components/ui-px/ComingSoon";

type FooterLink = { label: string; to?: string; hash?: string; href?: string; trustpilot?: boolean; product?: string };

const cols: { title: string; links: FooterLink[] }[] = [
  { title: "Services", links: [{ label: "VPS", to: "/vps", product: "vps" }, { label: "Bot Hosting", to: "/bot-hosting", product: "bot" }, { label: "Locations", to: "/", hash: "locations" }, { label: "Status", href: site.statusUrl }, { label: "Trustpilot", href: site.trustpilotUrl, trustpilot: true }] },
  { title: "Company", links: [{ label: "About", to: "/about" }, { label: "Contact", to: "/contact" }, { label: "Support", to: "/support" }, { label: "Queries", to: "/queries" }, { label: "Billing", to: "/billing" }] },
];

const legal = [["Terms", "tos"], ["Privacy", "privacy"], ["Refunds", "refund"], ["Acceptable Use", "acceptable-use"], ["SLA", "sla"]] as const;
const linkCls = "inline-flex items-center gap-1.5 text-muted-foreground transition-colors hover:text-foreground";
const heading = "font-display text-sm font-semibold text-foreground";

function FooterItem({ l, soon }: { l: FooterLink; soon: boolean }) {
  const tag = soon && <SoonTag compact />;
  if (l.href) return <a href={l.href} target="_blank" rel="noopener noreferrer" className={linkCls}>{l.trustpilot && <TrustpilotMark className="size-3.5" />}{l.label}</a>;
  if (l.hash) return <Link to="/" hash={l.hash} className={linkCls}>{l.label}</Link>;
  return <Link to={l.to as "/"} className={linkCls}>{l.label}{tag}</Link>;
}

export function Footer() {
  const s = useSettings();
  return (
    <footer className="border-t border-steel bg-surface">
      <div className="container-px grid grid-cols-2 gap-x-6 gap-y-10 py-12 md:grid-cols-12 md:gap-x-10 md:py-14">
        <div className="col-span-2 md:col-span-4">
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">{site.blurb}</p>
          <a href={site.statusUrl} target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-full border border-steel px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground">
            <Activity className="size-3.5 text-ok" /> System status <ExternalLink className="size-3" />
          </a>
        </div>
        <div className="col-span-2 md:col-span-4">
          <h2 className={heading}>Games</h2>
          <ul className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2.5 text-sm">
            {games.map((g) => (
              <li key={g.key}><Link to={g.to} className={linkCls}>{g.name}{isComingSoon(s, g.key) && <SoonTag compact />}</Link></li>
            ))}
          </ul>
        </div>
        {cols.map((c) => (
          <div key={c.title} className="md:col-span-2">
            <h2 className={heading}>{c.title}</h2>
            <ul className="mt-4 space-y-2.5 text-sm">
              {c.links.map((l) => <li key={l.label}><FooterItem l={l} soon={Boolean(l.product && isComingSoon(s, l.product))} /></li>)}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-steel">
        <div className="container-px flex flex-col gap-3 py-5 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p>{site.copyright}</p>
          <ul className="flex flex-wrap gap-x-4 gap-y-2">
            {legal.map(([l, d]) => (
              <li key={d}><Link to="/legal/$doc" params={{ doc: d }} className="hover:text-foreground">{l}</Link></li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}
