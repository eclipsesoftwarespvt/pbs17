import { Toaster as Sonner } from "sonner";
import { AlertTriangle, Info, X } from "lucide-react";
import { SuccessTick } from "@/components/ui-px/SuccessTick";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      className="toaster group"
      theme="dark"
      position="top-center"
      gap={10}
      icons={{
        success: <SuccessTick size="sm" />,
        error: <span className="px-toast-icon px-toast-icon-error"><X /></span>,
        info: <span className="px-toast-icon px-toast-icon-info"><Info /></span>,
        warning: <span className="px-toast-icon px-toast-icon-warn"><AlertTriangle /></span>,
      }}
      toastOptions={{
        classNames: {
          toast: "px-toast group toast",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  );
};

export { Toaster };
