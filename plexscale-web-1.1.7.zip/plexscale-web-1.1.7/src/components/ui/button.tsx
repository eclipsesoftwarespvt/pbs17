import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { btn, type BtnProps, type BtnVariant } from "@/components/ui-px/btn";
import { cn } from "@/lib/utils";

/** shadcn-style names map onto the single site button style, so every button looks and behaves the same. */
const variantAlias = {
  default: "primary",
  outline: "secondary",
  destructive: "danger",
} as const satisfies Record<string, BtnVariant>;

type Variant = BtnVariant | keyof typeof variantAlias;
type Size = NonNullable<BtnProps["size"]> | "default";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant | null;
  size?: Size | null;
  asChild?: boolean;
}

const resolveVariant = (v: Variant | null | undefined): BtnVariant => (v ? ((variantAlias as Record<string, BtnVariant>)[v] ?? (v as BtnVariant)) : "primary");
const resolveSize = (s: Size | null | undefined): NonNullable<BtnProps["size"]> => (!s || s === "default" ? "md" : s);

/** Class names for a button-looking element (links, labels). */
function buttonVariants({ variant, size, className }: { variant?: Variant | null | undefined; size?: Size | null | undefined; className?: string | undefined } = {}) {
  return cn(btn({ variant: resolveVariant(variant), size: resolveSize(size) }), className);
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, asChild = false, type, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";
  return <Comp ref={ref} {...(asChild ? {} : { type: type ?? "button" })} className={buttonVariants({ variant, size, className })} {...props} />;
});
Button.displayName = "Button";

export { Button };
