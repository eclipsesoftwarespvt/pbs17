import { useSuspenseQuery } from "@tanstack/react-query";
import { effectivePlans, type Plan } from "@/config/plans";
import { settingsQuery } from "@/lib/settings.functions";

/** Live site settings (links, banner, status, plan changes). Preloaded by the root route. */
export function useSettings() {
  return useSuspenseQuery(settingsQuery).data;
}

export function useLocations() {
  return useSettings().locations;
}

/** Plans for a product with admin price/spec changes applied and hidden plans removed. */
export function usePlans(product: string): Plan[] {
  const s = useSettings();
  return effectivePlans(product, s.plans);
}
