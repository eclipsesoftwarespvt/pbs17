export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_email_grants: {
        Row: {
          created_at: string
          email: string
        }
        Insert: {
          created_at?: string
          email: string
        }
        Update: {
          created_at?: string
          email?: string
        }
        Relationships: []
      }
      audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          details: Json
          id: string
          ip: string | null
          scope: string
          target: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          id?: string
          ip?: string | null
          scope?: string
          target?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          id?: string
          ip?: string | null
          scope?: string
          target?: string | null
        }
        Relationships: []
      }
      coupons: {
        Row: {
          active: boolean
          code: string
          created_at: string
          created_by: string | null
          expires_at: string | null
          id: string
          kind: string
          max_discount: number | null
          max_uses: number | null
          min_amount: number
          note: string | null
          per_user_limit: number
          products: string[]
          starts_at: string | null
          updated_at: string
          value: number
        }
        Insert: {
          active?: boolean
          code: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          kind: string
          max_discount?: number | null
          max_uses?: number | null
          min_amount?: number
          note?: string | null
          per_user_limit?: number
          products?: string[]
          starts_at?: string | null
          updated_at?: string
          value: number
        }
        Update: {
          active?: boolean
          code?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          kind?: string
          max_discount?: number | null
          max_uses?: number | null
          min_amount?: number
          note?: string | null
          per_user_limit?: number
          products?: string[]
          starts_at?: string | null
          updated_at?: string
          value?: number
        }
        Relationships: []
      }
      credit_transactions: {
        Row: {
          amount: number
          balance_after: number
          created_at: string
          created_by: string | null
          id: string
          kind: string
          note: string | null
          order_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          balance_after: number
          created_at?: string
          created_by?: string | null
          id?: string
          kind: string
          note?: string | null
          order_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          balance_after?: number
          created_at?: string
          created_by?: string | null
          id?: string
          kind?: string
          note?: string | null
          order_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_transactions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_wallets: {
        Row: {
          balance: number
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      email_events: {
        Row: {
          created_at: string
          dedupe_key: string
          error: string | null
          id: string
          kind: string
          order_id: string | null
          recipient: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          dedupe_key: string
          error?: string | null
          id?: string
          kind: string
          order_id?: string | null
          recipient?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          dedupe_key?: string
          error?: string | null
          id?: string
          kind?: string
          order_id?: string | null
          recipient?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      email_settings: {
        Row: {
          data: Json
          id: number
          updated_at: string
        }
        Insert: {
          data?: Json
          id?: number
          updated_at?: string
        }
        Update: {
          data?: Json
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount: number
          data: Json
          id: string
          issued_at: string
          number: number
          order_id: string
          user_id: string
        }
        Insert: {
          amount: number
          data?: Json
          id?: string
          issued_at?: string
          number?: never
          order_id: string
          user_id: string
        }
        Update: {
          amount?: number
          data?: Json
          id?: string
          issued_at?: string
          number?: never
          order_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          amount: number
          billing: string
          config: Json
          coupon_id: string | null
          cpu_percent: number | null
          created_at: string
          description: string
          discount: number
          disk_mb: number | null
          id: string
          kind: string
          location: string
          paid_at: string | null
          paid_with: string
          parent_order_id: string | null
          plan_id: string
          plan_name: string
          plexus_machine_id: string | null
          product: string
          provision_attempts: number
          provision_error: string | null
          ptero_identifier: string | null
          ptero_server_id: number | null
          ram_mb: number | null
          razorpay_order_id: string | null
          razorpay_payment_id: string | null
          refunded_at: string | null
          renews_at: string | null
          server_deleted_at: string | null
          server_name: string
          software: string | null
          status: string
          updated_at: string
          user_id: string
          version: string | null
        }
        Insert: {
          amount: number
          billing: string
          config?: Json
          coupon_id?: string | null
          cpu_percent?: number | null
          created_at?: string
          description?: string
          discount?: number
          disk_mb?: number | null
          id?: string
          kind?: string
          location: string
          paid_at?: string | null
          paid_with?: string
          parent_order_id?: string | null
          plan_id: string
          plan_name: string
          plexus_machine_id?: string | null
          product: string
          provision_attempts?: number
          provision_error?: string | null
          ptero_identifier?: string | null
          ptero_server_id?: number | null
          ram_mb?: number | null
          razorpay_order_id?: string | null
          razorpay_payment_id?: string | null
          refunded_at?: string | null
          renews_at?: string | null
          server_deleted_at?: string | null
          server_name?: string
          software?: string | null
          status?: string
          updated_at?: string
          user_id: string
          version?: string | null
        }
        Update: {
          amount?: number
          billing?: string
          config?: Json
          coupon_id?: string | null
          cpu_percent?: number | null
          created_at?: string
          description?: string
          discount?: number
          disk_mb?: number | null
          id?: string
          kind?: string
          location?: string
          paid_at?: string | null
          paid_with?: string
          parent_order_id?: string | null
          plan_id?: string
          plan_name?: string
          plexus_machine_id?: string | null
          product?: string
          provision_attempts?: number
          provision_error?: string | null
          ptero_identifier?: string | null
          ptero_server_id?: number | null
          ram_mb?: number | null
          razorpay_order_id?: string | null
          razorpay_payment_id?: string | null
          refunded_at?: string | null
          renews_at?: string | null
          server_deleted_at?: string | null
          server_name?: string
          software?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "orders_coupon_id_fkey"
            columns: ["coupon_id"]
            isOneToOne: false
            referencedRelation: "coupons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_parent_order_id_fkey"
            columns: ["parent_order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      panel_alerts: {
        Row: {
          action: string
          count: number
          created_at: string
          http_status: number | null
          id: string
          last_seen_at: string
          order_id: string | null
          panel_code: string | null
          panel_detail: string | null
          product: string | null
          raw: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
          support_id: string
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          count?: number
          created_at?: string
          http_status?: number | null
          id?: string
          last_seen_at?: string
          order_id?: string | null
          panel_code?: string | null
          panel_detail?: string | null
          product?: string | null
          raw?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          support_id?: string
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          count?: number
          created_at?: string
          http_status?: number | null
          id?: string
          last_seen_at?: string
          order_id?: string | null
          panel_code?: string | null
          panel_detail?: string | null
          product?: string | null
          raw?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          support_id?: string
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "panel_alerts_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      panel_settings: {
        Row: {
          data: Json
          id: number
          updated_at: string
        }
        Insert: {
          data?: Json
          id?: number
          updated_at?: string
        }
        Update: {
          data?: Json
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
      plexus_accounts: {
        Row: {
          account_id: number
          created_at: string
          user_id: string
        }
        Insert: {
          account_id: number
          created_at?: string
          user_id: string
        }
        Update: {
          account_id?: number
          created_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          billing_address: string | null
          billing_name: string | null
          billing_phone: string | null
          created_at: string
          display_name: string | null
          email: string | null
          gstin: string | null
          id: string
          updated_at: string
          welcome_sent_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          billing_address?: string | null
          billing_name?: string | null
          billing_phone?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          gstin?: string | null
          id: string
          updated_at?: string
          welcome_sent_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          billing_address?: string | null
          billing_name?: string | null
          billing_phone?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          gstin?: string | null
          id?: string
          updated_at?: string
          welcome_sent_at?: string | null
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          count: number
          key: string
          window_start: string
        }
        Insert: {
          count?: number
          key: string
          window_start: string
        }
        Update: {
          count?: number
          key?: string
          window_start?: string
        }
        Relationships: []
      }
      refunds: {
        Row: {
          admin_note: string | null
          created_at: string
          id: string
          order_id: string
          reason: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          created_at?: string
          id?: string
          order_id: string
          reason: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          created_at?: string
          id?: string
          order_id?: string
          reason?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "refunds_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      site_settings: {
        Row: {
          data: Json
          id: number
          updated_at: string
        }
        Insert: {
          data?: Json
          id?: number
          updated_at?: string
        }
        Update: {
          data?: Json
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
      support_tickets: {
        Row: {
          category: string
          created_at: string
          id: string
          last_message_at: string
          number: number
          order_id: string | null
          priority: string
          staff_last_read_at: string | null
          status: string
          subject: string
          updated_at: string
          user_id: string
          user_last_read_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          last_message_at?: string
          number?: never
          order_id?: string | null
          priority?: string
          staff_last_read_at?: string | null
          status?: string
          subject: string
          updated_at?: string
          user_id: string
          user_last_read_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          last_message_at?: string
          number?: never
          order_id?: string | null
          priority?: string
          staff_last_read_at?: string | null
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
          user_last_read_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_tickets_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      ticket_messages: {
        Row: {
          author_id: string | null
          body: string
          created_at: string
          id: string
          is_internal: boolean
          is_staff: boolean
          ticket_id: string
        }
        Insert: {
          author_id?: string | null
          body: string
          created_at?: string
          id?: string
          is_internal?: boolean
          is_staff?: boolean
          ticket_id: string
        }
        Update: {
          author_id?: string | null
          body?: string
          created_at?: string
          id?: string
          is_internal?: boolean
          is_staff?: boolean
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ticket_messages_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      webhook_events: {
        Row: {
          event: string
          event_id: string
          received_at: string
        }
        Insert: {
          event: string
          event_id: string
          received_at?: string
        }
        Update: {
          event?: string
          event_id?: string
          received_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_adjust_credits: {
        Args: { _amount: number; _by: string; _note: string; _user_id: string }
        Returns: number
      }
      apply_coupon: {
        Args: { _code: string; _order_id: string }
        Returns: {
          discount: number
          new_amount: number
        }[]
      }
      apply_renewal: {
        Args: { _order_id: string; _payment_id: string }
        Returns: string
      }
      create_topup_order: {
        Args: { _amount: number; _max_balance: number; _max_open: number; _user_id: string }
        Returns: string
      }
      credit_topup: {
        Args: { _order_id: string; _payment_id: string }
        Returns: number
      }
      extend_service: {
        Args: { _months: number; _order_id: string }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hit_rate_limit: {
        Args: { _key: string; _limit: number; _window_seconds: number }
        Returns: boolean
      }
      random_alert_key: { Args: never; Returns: string }
      record_panel_alert: {
        Args: {
          _action: string
          _http_status: number
          _order_id: string
          _panel_code: string
          _panel_detail: string
          _product: string
          _raw: string
          _support_id: string
          _user_email: string
          _user_id: string
        }
        Returns: string
      }
      record_panel_alert_v2: {
        Args: {
          _action: string
          _http_status: number
          _order_id: string
          _panel_code: string
          _panel_detail: string
          _product: string
          _raw: string
          _user_email: string
          _user_id: string
        }
        Returns: string
      }
      refund_order_to_credits: {
        Args: { _by: string; _note: string; _order_id: string }
        Returns: number
      }
      revoke_admin_access: {
        Args: { _user_id: string }
        Returns: undefined
      }
      revive_paid_order: {
        Args: { _order_id: string; _payment_id: string; _renews_at: string }
        Returns: string
      }
      set_maintenance: { Args: { _on: boolean }; Returns: boolean }
      spend_credits: { Args: { _order_id: string }; Returns: string }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
