#!/usr/bin/env node
// Applies pending migrations from db/migrations to DATABASE_URL using the checksum ledger.
//
//   node scripts/migrate.mjs              apply pending migrations (one transaction)
//   node scripts/migrate.mjs --status     show applied / pending, change nothing (exit 3 when a check fails)
//   node scripts/migrate.mjs --dry-run    run every check, apply nothing
//   node scripts/migrate.mjs --baseline 0007
//                                         adopt a database migrated by the old tooling (records 0000..0007
//                                         as applied without running them, then applies the rest)
//
// DATABASE_URL is the only connection setting. It must point at
// the database as the `postgres` role, which owns the application schema.
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import postgres from "postgres";
import { loadMigrations, migrate, MigrationError, status } from "./lib/migrator.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const version = readFileSync(join(root, "VERSION"), "utf8").trim();
const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const baselineAt = args.indexOf("--baseline");
const baseline = baselineAt >= 0 ? args[baselineAt + 1] : undefined;
if (baselineAt >= 0 && !/^\d{4}$/.test(baseline ?? "")) {
  console.error("--baseline needs a migration id such as 0007");
  process.exit(2);
}

const url = process.env.DATABASE_URL;
if (!url) {
  console.error("DATABASE_URL is not set.");
  process.exit(2);
}

const sql = postgres(url, { max: 1, prepare: false, connect_timeout: 15, idle_timeout: 5, onnotice: () => {} });
const adapter = {
  transaction: (fn) => sql.begin((tx) => fn({
    query: (text, params = []) => tx.unsafe(text, params),
    exec: (text) => tx.unsafe(text).simple(),
  })),
};

let code = 0;
try {
  const migrations = loadMigrations(join(root, "db", "migrations"));
  if (flag("--status")) {
    const s = await status(adapter, migrations);
    console.log(JSON.stringify({ version, applied: s.applied, pending: s.pending.map((m) => m.name), problems: s.problems, schemaPresent: s.schemaPresent, ledgerPresent: s.ledgerPresent }, null, 2));
    if (s.problems.length) code = 3;
  } else {
    const r = await migrate(adapter, migrations, { appVersion: version, dryRun: flag("--dry-run"), ...(baseline ? { baseline } : {}) });
    if (r.baselined.length) console.log(`Recorded as already applied: ${r.baselined.join(", ")}`);
    if (r.dryRun) console.log(r.pending.length ? `Would apply: ${r.pending.join(", ")}` : "Nothing to apply.");
    else console.log(r.applied.length ? `Applied: ${r.applied.join(", ")}` : "Database is up to date.");
  }
} catch (e) {
  if (e instanceof MigrationError) {
    console.error(e.message);
    for (const p of e.problems) console.error(`  - ${p}`);
    code = 3;
  } else {
    console.error(`Migration failed: ${e instanceof Error ? e.message : String(e)}`);
    code = 1;
  }
} finally {
  await sql.end({ timeout: 5 });
}
process.exit(code);
