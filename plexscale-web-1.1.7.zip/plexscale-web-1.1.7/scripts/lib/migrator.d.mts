export interface Migration { id: string; name: string; sql: string; checksum: string }
export interface LedgerRow { id: string; name: string; checksum: string }
export interface Tx { query(sql: string, params?: unknown[]): Promise<Record<string, unknown>[]>; exec(sql: string): Promise<unknown> }
export interface Adapter { transaction<T>(fn: (tx: Tx) => Promise<T>): Promise<T> }
export class MigrationError extends Error { problems: string[] }
export function loadMigrations(dir: string): Migration[];
export function status(adapter: Adapter, migrations: Migration[]): Promise<{ applied: number; pending: Migration[]; problems: string[]; ledgerPresent: boolean; schemaPresent: boolean }>;
export function migrate(adapter: Adapter, migrations: Migration[], opts: { appVersion: string; dryRun?: boolean; baseline?: string }): Promise<{ applied: string[]; baselined: string[]; pending: string[]; dryRun: boolean }>;
